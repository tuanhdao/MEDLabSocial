﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2021.2.3),
    on September 19, 2022, at 12:15
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, parallel
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2021.2.3'
expName = 'trigger_test'  # from the Builder filename that created this script
expInfo = {'participant': '', 'session': '001'}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Dropbox\\Reprogrammed IG\\trigger_test_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=[1280, 1024], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Setup eyetracking
ioDevice = ioConfig = ioSession = ioServer = eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "Player_profiles_voting_style"
Player_profiles_voting_styleClock = core.Clock()
border_2 = visual.Rect(
    win=win, name='border_2',
    width=(0.21, 0.31)[0], height=(0.21, 0.31)[1],
    ori=0.0, pos=(-0.4, 0.2),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=0.0, interpolate=True)
like_real_button_1 = visual.Rect(
    win=win, name='like_real_button_1',
    width=(0.21, 0.07)[0], height=(0.21, 0.07)[1],
    ori=0.0, pos=(-0.4, -0.3),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-1.0, interpolate=True)
like_real_text_1 = visual.TextStim(win=win, name='like_real_text_1',
    text='Like ',
    font='Arial',
    pos=(-0.4, -0.3), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
dislike_real_button_1 = visual.Rect(
    win=win, name='dislike_real_button_1',
    width=(0.21, 0.07)[0], height=(0.21, 0.07)[1],
    ori=0.0, pos=(0.39, -0.3),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-3.0, interpolate=True)
dislike_real_text_1 = visual.TextStim(win=win, name='dislike_real_text_1',
    text='Dislike ',
    font='Arial',
    pos=(0.4, -0.3), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
click_real_1 = event.Mouse(win=win)
x, y = [None, None]
click_real_1.mouseClock = core.Clock()
accept_trig = parallel.ParallelPort(address='0xE010')
mouse = event.Mouse()

# Initialize components for Routine "fixatiioon"
fixatiioonClock = core.Clock()
text = visual.TextStim(win=win, name='text',
    text='Any text\n\nincluding line breaks',
    font='Open Sans',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "Cop_vote"
Cop_voteClock = core.Clock()
vote_image = visual.ImageStim(
    win=win,
    name='vote_image', 
    image='sin', mask=None,
    ori=0.0, pos=(0, 0), size=(0.4, 0.4),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
feedback = parallel.ParallelPort(address='0x0378')

# Initialize components for Routine "trial"
trialClock = core.Clock()

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "Player_profiles_voting_style"-------
continueRoutine = True
# update component parameters for each repeat
# setup some python lists for storing info about the click_real_1
click_real_1.clicked_name = []
gotValidClick = False  # until a click is received
# keep track of which components have finished
Player_profiles_voting_styleComponents = [border_2, like_real_button_1, like_real_text_1, dislike_real_button_1, dislike_real_text_1, click_real_1, accept_trig]
for thisComponent in Player_profiles_voting_styleComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Player_profiles_voting_styleClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Player_profiles_voting_style"-------
while continueRoutine:
    # get current time
    t = Player_profiles_voting_styleClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Player_profiles_voting_styleClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *border_2* updates
    if border_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        border_2.frameNStart = frameN  # exact frame index
        border_2.tStart = t  # local t and not account for scr refresh
        border_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(border_2, 'tStartRefresh')  # time at next scr refresh
        border_2.setAutoDraw(True)
    
    # *like_real_button_1* updates
    if like_real_button_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        like_real_button_1.frameNStart = frameN  # exact frame index
        like_real_button_1.tStart = t  # local t and not account for scr refresh
        like_real_button_1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(like_real_button_1, 'tStartRefresh')  # time at next scr refresh
        like_real_button_1.setAutoDraw(True)
    
    # *like_real_text_1* updates
    if like_real_text_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        like_real_text_1.frameNStart = frameN  # exact frame index
        like_real_text_1.tStart = t  # local t and not account for scr refresh
        like_real_text_1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(like_real_text_1, 'tStartRefresh')  # time at next scr refresh
        like_real_text_1.setAutoDraw(True)
    
    # *dislike_real_button_1* updates
    if dislike_real_button_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        dislike_real_button_1.frameNStart = frameN  # exact frame index
        dislike_real_button_1.tStart = t  # local t and not account for scr refresh
        dislike_real_button_1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(dislike_real_button_1, 'tStartRefresh')  # time at next scr refresh
        dislike_real_button_1.setAutoDraw(True)
    
    # *dislike_real_text_1* updates
    if dislike_real_text_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        dislike_real_text_1.frameNStart = frameN  # exact frame index
        dislike_real_text_1.tStart = t  # local t and not account for scr refresh
        dislike_real_text_1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(dislike_real_text_1, 'tStartRefresh')  # time at next scr refresh
        dislike_real_text_1.setAutoDraw(True)
    # *click_real_1* updates
    if click_real_1.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        click_real_1.frameNStart = frameN  # exact frame index
        click_real_1.tStart = t  # local t and not account for scr refresh
        click_real_1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(click_real_1, 'tStartRefresh')  # time at next scr refresh
        click_real_1.status = STARTED
        click_real_1.mouseClock.reset()
        prevButtonState = click_real_1.getPressed()  # if button is down already this ISN'T a new click
    if click_real_1.status == STARTED:  # only update if started and not finished!
        buttons = click_real_1.getPressed()
        if buttons != prevButtonState:  # button state changed?
            prevButtonState = buttons
            if sum(buttons) > 0:  # state changed to a new click
                # check if the mouse was inside our 'clickable' objects
                gotValidClick = False
                try:
                    iter([like_real_button_1, dislike_real_button_1])
                    clickableList = [like_real_button_1, dislike_real_button_1]
                except:
                    clickableList = [[like_real_button_1, dislike_real_button_1]]
                for obj in clickableList:
                    if obj.contains(click_real_1):
                        gotValidClick = True
                        click_real_1.clicked_name.append(obj.name)
                if gotValidClick:  # abort routine on response
                    continueRoutine = False
    # *accept_trig* updates
    if accept_trig.status == NOT_STARTED and gotValidClick == True:
        # keep track of start time/frame for later
        accept_trig.frameNStart = frameN  # exact frame index
        accept_trig.tStart = t  # local t and not account for scr refresh
        accept_trig.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(accept_trig, 'tStartRefresh')  # time at next scr refresh
        accept_trig.status = STARTED
        win.callOnFlip(accept_trig.setData, int(10))
    if accept_trig.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > accept_trig.tStartRefresh + 0.01-frameTolerance:
            # keep track of stop time/frame for later
            accept_trig.tStop = t  # not accounting for scr refresh
            accept_trig.frameNStop = frameN  # exact frame index
            win.timeOnFlip(accept_trig, 'tStopRefresh')  # time at next scr refresh
            accept_trig.status = FINISHED
            win.callOnFlip(accept_trig.setData, int(0))
    if mouse.isPressedIn(like_real_button_1):
        win.callOnFlip(accept_trig.setData, 1)
    elif mouse.isPressedIn(dislike_real_button_1):
        win.callOnFlip(accept_trig.setData, 2)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Player_profiles_voting_styleComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Player_profiles_voting_style"-------
for thisComponent in Player_profiles_voting_styleComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('border_2.started', border_2.tStartRefresh)
thisExp.addData('border_2.stopped', border_2.tStopRefresh)
thisExp.addData('like_real_button_1.started', like_real_button_1.tStartRefresh)
thisExp.addData('like_real_button_1.stopped', like_real_button_1.tStopRefresh)
thisExp.addData('like_real_text_1.started', like_real_text_1.tStartRefresh)
thisExp.addData('like_real_text_1.stopped', like_real_text_1.tStopRefresh)
thisExp.addData('dislike_real_button_1.started', dislike_real_button_1.tStartRefresh)
thisExp.addData('dislike_real_button_1.stopped', dislike_real_button_1.tStopRefresh)
thisExp.addData('dislike_real_text_1.started', dislike_real_text_1.tStartRefresh)
thisExp.addData('dislike_real_text_1.stopped', dislike_real_text_1.tStopRefresh)
# store data for thisExp (ExperimentHandler)
x, y = click_real_1.getPos()
buttons = click_real_1.getPressed()
if sum(buttons):
    # check if the mouse was inside our 'clickable' objects
    gotValidClick = False
    try:
        iter([like_real_button_1, dislike_real_button_1])
        clickableList = [like_real_button_1, dislike_real_button_1]
    except:
        clickableList = [[like_real_button_1, dislike_real_button_1]]
    for obj in clickableList:
        if obj.contains(click_real_1):
            gotValidClick = True
            click_real_1.clicked_name.append(obj.name)
thisExp.addData('click_real_1.x', x)
thisExp.addData('click_real_1.y', y)
thisExp.addData('click_real_1.leftButton', buttons[0])
thisExp.addData('click_real_1.midButton', buttons[1])
thisExp.addData('click_real_1.rightButton', buttons[2])
if len(click_real_1.clicked_name):
    thisExp.addData('click_real_1.clicked_name', click_real_1.clicked_name[0])
thisExp.addData('click_real_1.started', click_real_1.tStart)
thisExp.addData('click_real_1.stopped', click_real_1.tStop)
thisExp.nextEntry()
if accept_trig.status == STARTED:
    win.callOnFlip(accept_trig.setData, int(0))
thisExp.addData('accept_trig.started', accept_trig.tStart)
thisExp.addData('accept_trig.stopped', accept_trig.tStop)
# the Routine "Player_profiles_voting_style" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "fixatiioon"-------
continueRoutine = True
routineTimer.add(2.000000)
# update component parameters for each repeat
# keep track of which components have finished
fixatiioonComponents = [text]
for thisComponent in fixatiioonComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
fixatiioonClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "fixatiioon"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = fixatiioonClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=fixatiioonClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text* updates
    if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text.frameNStart = frameN  # exact frame index
        text.tStart = t  # local t and not account for scr refresh
        text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
        text.setAutoDraw(True)
    if text.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > text.tStartRefresh + 2-frameTolerance:
            # keep track of stop time/frame for later
            text.tStop = t  # not accounting for scr refresh
            text.frameNStop = frameN  # exact frame index
            win.timeOnFlip(text, 'tStopRefresh')  # time at next scr refresh
            text.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in fixatiioonComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "fixatiioon"-------
for thisComponent in fixatiioonComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('text.started', text.tStartRefresh)
thisExp.addData('text.stopped', text.tStopRefresh)

# ------Prepare to start Routine "Cop_vote"-------
continueRoutine = True
routineTimer.add(2.000000)
# update component parameters for each repeat
vote_image.setImage('images/Like.png')


    
    
    
    
# keep track of which components have finished
Cop_voteComponents = [vote_image, feedback]
for thisComponent in Cop_voteComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Cop_voteClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Cop_vote"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = Cop_voteClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Cop_voteClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *vote_image* updates
    if vote_image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        vote_image.frameNStart = frameN  # exact frame index
        vote_image.tStart = t  # local t and not account for scr refresh
        vote_image.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(vote_image, 'tStartRefresh')  # time at next scr refresh
        vote_image.setAutoDraw(True)
    if vote_image.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > vote_image.tStartRefresh + 2.0-frameTolerance:
            # keep track of stop time/frame for later
            vote_image.tStop = t  # not accounting for scr refresh
            vote_image.frameNStop = frameN  # exact frame index
            win.timeOnFlip(vote_image, 'tStopRefresh')  # time at next scr refresh
            vote_image.setAutoDraw(False)
    if vote_image == 'images\Like.png' and vote_image.status == STARTED:
        win.callOnFlip(p_port.setData, 3)
    
    # *feedback* updates
    if feedback.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        feedback.frameNStart = frameN  # exact frame index
        feedback.tStart = t  # local t and not account for scr refresh
        feedback.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(feedback, 'tStartRefresh')  # time at next scr refresh
        feedback.status = STARTED
        win.callOnFlip(feedback.setData, int(20))
    if feedback.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > feedback.tStartRefresh + 0.01-frameTolerance:
            # keep track of stop time/frame for later
            feedback.tStop = t  # not accounting for scr refresh
            feedback.frameNStop = frameN  # exact frame index
            win.timeOnFlip(feedback, 'tStopRefresh')  # time at next scr refresh
            feedback.status = FINISHED
            win.callOnFlip(feedback.setData, int(0))
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Cop_voteComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Cop_vote"-------
for thisComponent in Cop_voteComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('vote_image.started', vote_image.tStartRefresh)
thisExp.addData('vote_image.stopped', vote_image.tStopRefresh)
if feedback.status == STARTED:
    win.callOnFlip(feedback.setData, int(0))
thisExp.addData('feedback.started', feedback.tStart)
thisExp.addData('feedback.stopped', feedback.tStop)

# ------Prepare to start Routine "trial"-------
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
trialComponents = []
for thisComponent in trialComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
trialClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "trial"-------
while continueRoutine:
    # get current time
    t = trialClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=trialClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in trialComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "trial"-------
for thisComponent in trialComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "trial" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
