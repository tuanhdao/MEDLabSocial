﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2021.2.3),
    on June 23, 2022, at 19:07
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2021.2.3'
expName = 'Test_anh'  # from the Builder filename that created this script
expInfo = {'participant': ''}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\tuanh\\OneDrive - Vanderbilt\\Desktop\\Reprogrammed IG\\Test_anh_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=[1536, 864], fullscr=False, screen=0, 
    winType='pyglet', allowGUI=True, allowStencil=False,
    monitor='testMonitor', color='black', colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Setup eyetracking
ioDevice = ioConfig = ioSession = ioServer = eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "Welcome"
WelcomeClock = core.Clock()
background_image1 = visual.ImageStim(
    win=win,
    name='background_image1', 
    image='537EB5D1-3996-4E6A-B61A-D87B05390738.jpg', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=1.0,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
background_polygon = visual.Rect(
    win=win, name='background_polygon',
    width=(1, 0.25)[0], height=(1, 0.25)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor=None, fillColor='white',
    opacity=0.8, depth=-1.0, interpolate=True)
Welcome_text = visual.TextStim(win=win, name='Welcome_text',
    text='Welcome!',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "Introduction_1"
Introduction_1Clock = core.Clock()
image = visual.ImageStim(
    win=win,
    name='image', 
    image='IMG_9577.JPG', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
polygon_2 = visual.Rect(
    win=win, name='polygon_2',
    width=(1.5, 0.75)[0], height=(1.5, 0.75)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=0.8, depth=-1.0, interpolate=True)
text = visual.TextStim(win=win, name='text',
    text='',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
key_resp = keyboard.Keyboard()
trialList=data.importConditions('Trials.xlsx')

# Initialize components for Routine "Introduction_2"
Introduction_2Clock = core.Clock()
image_2 = visual.ImageStim(
    win=win,
    name='image_2', 
    image='IMG_9577.JPG', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
polygon_3 = visual.Rect(
    win=win, name='polygon_3',
    width=(1.5, 0.75)[0], height=(1.5, 0.75)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=0.8, depth=-1.0, interpolate=True)
key_resp_2 = keyboard.Keyboard()
text_2 = visual.TextStim(win=win, name='text_2',
    text="As you travel along the islands, you'll get to know more and more about the other players. After each round, you'll vote for who you would like to continue on to the Big Island with you and who you would like to send home. But the other players will also be voting on you! \n\nPress any key to continue. ",
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);

# Initialize components for Routine "Participant_name"
Participant_nameClock = core.Clock()
name_question = visual.TextStim(win=win, name='name_question',
    text='What is your name?',
    font='Arial',
    pos=(0, 0.2), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
name_enter = visual.TextBox2(
     win, text=None, font='Arial',
     pos=(0, 0),     letterHeight=0.05,
     size=(None, None), borderWidth=2.0,
     color='white', colorSpace='rgb',
     opacity=1.0,
     bold=False, italic=False,
     lineSpacing=1.0,
     padding=0.0,
     anchor='center',
     fillColor=None, borderColor=None,
     flipHoriz=False, flipVert=False,
     editable=True,
     name='name_enter',
     autoLog=True,
)
button1 = visual.Rect(
    win=win, name='button1',
    width=(0.5, 0.1)[0], height=(0.5, 0.1)[1],
    ori=0.0, pos=(0, -0.2),
    lineWidth=1.0,     colorSpace='rgb',  lineColor=None, fillColor='white',
    opacity=None, depth=-2.0, interpolate=True)
submit1 = visual.TextStim(win=win, name='submit1',
    text='Click here to submit',
    font='Arial',
    pos=(0, -0.2), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);
mouse1 = event.Mouse(win=win)
x, y = [None, None]
mouse1.mouseClock = core.Clock()
# Set experiment start values for variable component ptp_name
ptp_name = name_enter.text
ptp_nameContainer = []

# Initialize components for Routine "Participant_age"
Participant_ageClock = core.Clock()
age_question = visual.TextStim(win=win, name='age_question',
    text='How old are you? ',
    font='Arial',
    pos=(0, 0.2), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
age_enter = visual.TextBox2(
     win, text=None, font='Arial',
     pos=(0, 0),     letterHeight=0.05,
     size=(None, None), borderWidth=2.0,
     color='white', colorSpace='rgb',
     opacity=None,
     bold=False, italic=False,
     lineSpacing=1.0,
     padding=0.0,
     anchor='center',
     fillColor=None, borderColor=None,
     flipHoriz=False, flipVert=False,
     editable=True,
     name='age_enter',
     autoLog=True,
)
mouse2 = event.Mouse(win=win)
x, y = [None, None]
mouse2.mouseClock = core.Clock()
button2 = visual.Rect(
    win=win, name='button2',
    width=(0.5, 0.1)[0], height=(0.5, 0.1)[1],
    ori=0.0, pos=(0, -0.2),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-3.0, interpolate=True)
submit2 = visual.TextStim(win=win, name='submit2',
    text='Click here to submit',
    font='Arial',
    pos=(0, -0.2), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
reminder = visual.TextStim(win=win, name='reminder',
    text='Please only enter a number.',
    font='Arial',
    pos=(0, 0.1), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-5.0);
# Set experiment start values for variable component ptp_age
ptp_age = age_enter.text
ptp_ageContainer = []

# Initialize components for Routine "Participant_hometown"
Participant_hometownClock = core.Clock()
hometown_question = visual.TextStim(win=win, name='hometown_question',
    text='What is your hometown?',
    font='Arial',
    pos=(0, 0.2), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
hometown_enter = visual.TextBox2(
     win, text=None, font='Arial',
     pos=(0, 0),     letterHeight=0.05,
     size=(None, None), borderWidth=2.0,
     color='white', colorSpace='rgb',
     opacity=None,
     bold=False, italic=False,
     lineSpacing=1.0,
     padding=0.0,
     anchor='center',
     fillColor=None, borderColor=None,
     flipHoriz=False, flipVert=False,
     editable=True,
     name='hometown_enter',
     autoLog=True,
)
mouse3 = event.Mouse(win=win)
x, y = [None, None]
mouse3.mouseClock = core.Clock()
button3 = visual.Rect(
    win=win, name='button3',
    width=(0.5, 0.1)[0], height=(0.5, 0.1)[1],
    ori=0.0, pos=(0, -0.2),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-3.0, interpolate=True)
submit3 = visual.TextStim(win=win, name='submit3',
    text='Click here to submit',
    font='Arial',
    pos=(0, -0.2), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
# Set experiment start values for variable component ptp_hometown
ptp_hometown = hometown_enter.text
ptp_hometownContainer = []

# Initialize components for Routine "Participant_interest"
Participant_interestClock = core.Clock()
interest_question = visual.TextStim(win=win, name='interest_question',
    text='What are some things you are interested in?',
    font='Arial',
    pos=(0, 0.2), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
interest_enter = visual.TextBox2(
     win, text=None, font='Arial',
     pos=(0, 0),     letterHeight=0.05,
     size=(None, None), borderWidth=2.0,
     color='white', colorSpace='rgb',
     opacity=None,
     bold=False, italic=False,
     lineSpacing=1.0,
     padding=0.0,
     anchor='center',
     fillColor=None, borderColor=None,
     flipHoriz=False, flipVert=False,
     editable=True,
     name='interest_enter',
     autoLog=True,
)
mouse4 = event.Mouse(win=win)
x, y = [None, None]
mouse4.mouseClock = core.Clock()
button4 = visual.Rect(
    win=win, name='button4',
    width=(0.5, 0.1)[0], height=(0.5, 0.1)[1],
    ori=0.0, pos=(0, -0.2),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-3.0, interpolate=True)
submit4 = visual.TextStim(win=win, name='submit4',
    text='Click here to submit',
    font='Arial',
    pos=(0, -0.2), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
# Set experiment start values for variable component ptp_interest
ptp_interest = interest_enter.text
ptp_interestContainer = []

# Initialize components for Routine "Participant_profile"
Participant_profileClock = core.Clock()
image_4 = visual.ImageStim(
    win=win,
    name='image_4', 
    image='537EB5D1-3996-4E6A-B61A-D87B05390738.jpg', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
border4 = visual.Rect(
    win=win, name='border4',
    width=(1.5, 0.75)[0], height=(1.5, 0.75)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=0.9, depth=-1.0, interpolate=True)
border = visual.Rect(
    win=win, name='border',
    width=(0.22, 0.32)[0], height=(0.22, 0.32)[1],
    ori=0.0, pos=(-0.5, 0.15),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='black',
    opacity=None, depth=-2.0, interpolate=True)
subject_image = visual.ImageStim(
    win=win,
    name='subject_image', 
    image='subject.jpg', mask=None,
    ori=0.0, pos=(0, 0.15), size=(0.2, 0.3),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-3.0)
part_response = visual.TextStim(win=win, name='part_response',
    text='',
    font='Open Sans',
    pos=(0.2, -0.2), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
part_prompts = visual.TextStim(win=win, name='part_prompts',
    text='Age:\nHometown:\nInterests:',
    font='Arial',
    pos=(-0.11, -0.2), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);
part_name = visual.TextStim(win=win, name='part_name',
    text='',
    font='Arial',
    pos=(-0.105, -0.1), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-7.0);

# Initialize components for Routine "Introduction_3"
Introduction_3Clock = core.Clock()
image_3 = visual.ImageStim(
    win=win,
    name='image_3', 
    image='IMG_9577.JPG', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
polygon = visual.Rect(
    win=win, name='polygon',
    width=(1.5, 0.75)[0], height=(1.5, 0.75)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=0.8, depth=-1.0, interpolate=True)
text_3 = visual.TextStim(win=win, name='text_3',
    text='',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
key_resp_3 = keyboard.Keyboard()

# Initialize components for Routine "Player_profiles_voting_style"
Player_profiles_voting_styleClock = core.Clock()
border_2 = visual.Rect(
    win=win, name='border_2',
    width=(0.21, 0.31)[0], height=(0.21, 0.31)[1],
    ori=0.0, pos=(-0.4, 0.2),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=0.0, interpolate=True)
coplayer_image = visual.ImageStim(
    win=win,
    name='coplayer_image', 
    image='sin', mask=None,
    ori=0.0, pos=(-0.4, 0.2), size=(0.2, 0.3),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)
cop_prompts = visual.TextBox2(
     win, text='Name:\nAge:\nHometown:\nInterests:', font='Arial',
     pos=(-0.15, 0.25),     letterHeight=0.03,
     size=(None, None), borderWidth=2.0,
     color='white', colorSpace='rgb',
     opacity=None,
     bold=True, italic=False,
     lineSpacing=1.0,
     padding=0.0,
     anchor='center',
     fillColor=None, borderColor=None,
     flipHoriz=False, flipVert=False,
     editable=False,
     name='cop_prompts',
     autoLog=True,
)
cop_response = visual.TextStim(win=win, name='cop_response',
    text='',
    font='Open Sans',
    pos=(0.45, 0.25), height=0.03, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);
cop_age_st = str()
button_5 = visual.Rect(
    win=win, name='button_5',
    width=(0.5, 0.1)[0], height=(0.5, 0.1)[1],
    ori=0.0, pos=(0, -0.2),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-5.0, interpolate=True)
mouse = event.Mouse(win=win)
x, y = [None, None]
mouse.mouseClock = core.Clock()
continue_button = visual.TextStim(win=win, name='continue_button',
    text='Click here to continue',
    font='Arial',
    pos=(0, -0.2), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-7.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "Welcome"-------
continueRoutine = True
routineTimer.add(2.000000)
# update component parameters for each repeat
# keep track of which components have finished
WelcomeComponents = [background_image1, background_polygon, Welcome_text]
for thisComponent in WelcomeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
WelcomeClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Welcome"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = WelcomeClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=WelcomeClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *background_image1* updates
    if background_image1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        background_image1.frameNStart = frameN  # exact frame index
        background_image1.tStart = t  # local t and not account for scr refresh
        background_image1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(background_image1, 'tStartRefresh')  # time at next scr refresh
        background_image1.setAutoDraw(True)
    if background_image1.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > background_image1.tStartRefresh + 2.0-frameTolerance:
            # keep track of stop time/frame for later
            background_image1.tStop = t  # not accounting for scr refresh
            background_image1.frameNStop = frameN  # exact frame index
            win.timeOnFlip(background_image1, 'tStopRefresh')  # time at next scr refresh
            background_image1.setAutoDraw(False)
    
    # *background_polygon* updates
    if background_polygon.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        background_polygon.frameNStart = frameN  # exact frame index
        background_polygon.tStart = t  # local t and not account for scr refresh
        background_polygon.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(background_polygon, 'tStartRefresh')  # time at next scr refresh
        background_polygon.setAutoDraw(True)
    if background_polygon.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > background_polygon.tStartRefresh + 2.0-frameTolerance:
            # keep track of stop time/frame for later
            background_polygon.tStop = t  # not accounting for scr refresh
            background_polygon.frameNStop = frameN  # exact frame index
            win.timeOnFlip(background_polygon, 'tStopRefresh')  # time at next scr refresh
            background_polygon.setAutoDraw(False)
    
    # *Welcome_text* updates
    if Welcome_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        Welcome_text.frameNStart = frameN  # exact frame index
        Welcome_text.tStart = t  # local t and not account for scr refresh
        Welcome_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(Welcome_text, 'tStartRefresh')  # time at next scr refresh
        Welcome_text.setAutoDraw(True)
    if Welcome_text.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > Welcome_text.tStartRefresh + 2.0-frameTolerance:
            # keep track of stop time/frame for later
            Welcome_text.tStop = t  # not accounting for scr refresh
            Welcome_text.frameNStop = frameN  # exact frame index
            win.timeOnFlip(Welcome_text, 'tStopRefresh')  # time at next scr refresh
            Welcome_text.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in WelcomeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Welcome"-------
for thisComponent in WelcomeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('background_image1.started', background_image1.tStartRefresh)
thisExp.addData('background_image1.stopped', background_image1.tStopRefresh)
thisExp.addData('background_polygon.started', background_polygon.tStartRefresh)
thisExp.addData('background_polygon.stopped', background_polygon.tStopRefresh)
thisExp.addData('Welcome_text.started', Welcome_text.tStartRefresh)
thisExp.addData('Welcome_text.stopped', Welcome_text.tStopRefresh)

# ------Prepare to start Routine "Introduction_1"-------
continueRoutine = True
# update component parameters for each repeat
text.setText("Let's pretend you've just landed on the Hawaiian Island of Niihau to begin a summer vacation with a group of 12 other young adults. But the journey isn't over yet! First, you must make your way along the islands to get to the Big Island of Hawaii. Once there, your vacation will begin! \n\nPress any key to continue.")
key_resp.keys = []
key_resp.rt = []
_key_resp_allKeys = []
# keep track of which components have finished
Introduction_1Components = [image, polygon_2, text, key_resp]
for thisComponent in Introduction_1Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Introduction_1Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Introduction_1"-------
while continueRoutine:
    # get current time
    t = Introduction_1Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Introduction_1Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image* updates
    if image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image.frameNStart = frameN  # exact frame index
        image.tStart = t  # local t and not account for scr refresh
        image.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image, 'tStartRefresh')  # time at next scr refresh
        image.setAutoDraw(True)
    
    # *polygon_2* updates
    if polygon_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        polygon_2.frameNStart = frameN  # exact frame index
        polygon_2.tStart = t  # local t and not account for scr refresh
        polygon_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(polygon_2, 'tStartRefresh')  # time at next scr refresh
        polygon_2.setAutoDraw(True)
    
    # *text* updates
    if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text.frameNStart = frameN  # exact frame index
        text.tStart = t  # local t and not account for scr refresh
        text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
        text.setAutoDraw(True)
    
    # *key_resp* updates
    waitOnFlip = False
    if key_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp.frameNStart = frameN  # exact frame index
        key_resp.tStart = t  # local t and not account for scr refresh
        key_resp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
        key_resp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp.status == STARTED and not waitOnFlip:
        theseKeys = key_resp.getKeys(keyList=None, waitRelease=False)
        _key_resp_allKeys.extend(theseKeys)
        if len(_key_resp_allKeys):
            key_resp.keys = _key_resp_allKeys[-1].name  # just the last key pressed
            key_resp.rt = _key_resp_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Introduction_1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Introduction_1"-------
for thisComponent in Introduction_1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image.started', image.tStartRefresh)
thisExp.addData('image.stopped', image.tStopRefresh)
thisExp.addData('polygon_2.started', polygon_2.tStartRefresh)
thisExp.addData('polygon_2.stopped', polygon_2.tStopRefresh)
thisExp.addData('text.started', text.tStartRefresh)
thisExp.addData('text.stopped', text.tStopRefresh)
# check responses
if key_resp.keys in ['', [], None]:  # No response was made
    key_resp.keys = None
thisExp.addData('key_resp.keys',key_resp.keys)
if key_resp.keys != None:  # we had a response
    thisExp.addData('key_resp.rt', key_resp.rt)
thisExp.addData('key_resp.started', key_resp.tStartRefresh)
thisExp.addData('key_resp.stopped', key_resp.tStopRefresh)
thisExp.nextEntry()
# the Routine "Introduction_1" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Introduction_2"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_2.keys = []
key_resp_2.rt = []
_key_resp_2_allKeys = []
# keep track of which components have finished
Introduction_2Components = [image_2, polygon_3, key_resp_2, text_2]
for thisComponent in Introduction_2Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Introduction_2Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Introduction_2"-------
while continueRoutine:
    # get current time
    t = Introduction_2Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Introduction_2Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_2* updates
    if image_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_2.frameNStart = frameN  # exact frame index
        image_2.tStart = t  # local t and not account for scr refresh
        image_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_2, 'tStartRefresh')  # time at next scr refresh
        image_2.setAutoDraw(True)
    
    # *polygon_3* updates
    if polygon_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        polygon_3.frameNStart = frameN  # exact frame index
        polygon_3.tStart = t  # local t and not account for scr refresh
        polygon_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(polygon_3, 'tStartRefresh')  # time at next scr refresh
        polygon_3.setAutoDraw(True)
    
    # *key_resp_2* updates
    waitOnFlip = False
    if key_resp_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_2.frameNStart = frameN  # exact frame index
        key_resp_2.tStart = t  # local t and not account for scr refresh
        key_resp_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_2, 'tStartRefresh')  # time at next scr refresh
        key_resp_2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_2.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_2.getKeys(keyList=None, waitRelease=False)
        _key_resp_2_allKeys.extend(theseKeys)
        if len(_key_resp_2_allKeys):
            key_resp_2.keys = _key_resp_2_allKeys[-1].name  # just the last key pressed
            key_resp_2.rt = _key_resp_2_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *text_2* updates
    if text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_2.frameNStart = frameN  # exact frame index
        text_2.tStart = t  # local t and not account for scr refresh
        text_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_2, 'tStartRefresh')  # time at next scr refresh
        text_2.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Introduction_2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Introduction_2"-------
for thisComponent in Introduction_2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image_2.started', image_2.tStartRefresh)
thisExp.addData('image_2.stopped', image_2.tStopRefresh)
thisExp.addData('polygon_3.started', polygon_3.tStartRefresh)
thisExp.addData('polygon_3.stopped', polygon_3.tStopRefresh)
# check responses
if key_resp_2.keys in ['', [], None]:  # No response was made
    key_resp_2.keys = None
thisExp.addData('key_resp_2.keys',key_resp_2.keys)
if key_resp_2.keys != None:  # we had a response
    thisExp.addData('key_resp_2.rt', key_resp_2.rt)
thisExp.addData('key_resp_2.started', key_resp_2.tStartRefresh)
thisExp.addData('key_resp_2.stopped', key_resp_2.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('text_2.started', text_2.tStartRefresh)
thisExp.addData('text_2.stopped', text_2.tStopRefresh)
# the Routine "Introduction_2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Participant_name"-------
continueRoutine = True
# update component parameters for each repeat
name_enter.reset()
name_enter.setText('')
# setup some python lists for storing info about the mouse1
mouse1.clicked_name = []
gotValidClick = False  # until a click is received
ptp_name = name_enter.text  # Set routine start values for ptp_name
thisExp.addData('ptp_name.routineStartVal', ptp_name)  # Save exp start value
# keep track of which components have finished
Participant_nameComponents = [name_question, name_enter, button1, submit1, mouse1]
for thisComponent in Participant_nameComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Participant_nameClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Participant_name"-------
while continueRoutine:
    # get current time
    t = Participant_nameClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Participant_nameClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *name_question* updates
    if name_question.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        name_question.frameNStart = frameN  # exact frame index
        name_question.tStart = t  # local t and not account for scr refresh
        name_question.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(name_question, 'tStartRefresh')  # time at next scr refresh
        name_question.setAutoDraw(True)
    
    # *name_enter* updates
    if name_enter.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        name_enter.frameNStart = frameN  # exact frame index
        name_enter.tStart = t  # local t and not account for scr refresh
        name_enter.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(name_enter, 'tStartRefresh')  # time at next scr refresh
        name_enter.setAutoDraw(True)
    
    # *button1* updates
    if button1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        button1.frameNStart = frameN  # exact frame index
        button1.tStart = t  # local t and not account for scr refresh
        button1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(button1, 'tStartRefresh')  # time at next scr refresh
        button1.setAutoDraw(True)
    
    # *submit1* updates
    if submit1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        submit1.frameNStart = frameN  # exact frame index
        submit1.tStart = t  # local t and not account for scr refresh
        submit1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(submit1, 'tStartRefresh')  # time at next scr refresh
        submit1.setAutoDraw(True)
    # *mouse1* updates
    if mouse1.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        mouse1.frameNStart = frameN  # exact frame index
        mouse1.tStart = t  # local t and not account for scr refresh
        mouse1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(mouse1, 'tStartRefresh')  # time at next scr refresh
        mouse1.status = STARTED
        mouse1.mouseClock.reset()
        prevButtonState = mouse1.getPressed()  # if button is down already this ISN'T a new click
    if mouse1.status == STARTED:  # only update if started and not finished!
        buttons = mouse1.getPressed()
        if buttons != prevButtonState:  # button state changed?
            prevButtonState = buttons
            if sum(buttons) > 0:  # state changed to a new click
                # check if the mouse was inside our 'clickable' objects
                gotValidClick = False
                try:
                    iter(button1)
                    clickableList = button1
                except:
                    clickableList = [button1]
                for obj in clickableList:
                    if obj.contains(mouse1):
                        gotValidClick = True
                        mouse1.clicked_name.append(obj.name)
                if gotValidClick:  # abort routine on response
                    continueRoutine = False
    ptp_name = name_enter.text  # Set frame start values for ptp_name
    ptp_nameContainer.append(ptp_name)  # Save frame values
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Participant_nameComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Participant_name"-------
for thisComponent in Participant_nameComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('name_question.started', name_question.tStartRefresh)
thisExp.addData('name_question.stopped', name_question.tStopRefresh)
thisExp.addData('name_enter.text',name_enter.text)
thisExp.addData('name_enter.started', name_enter.tStartRefresh)
thisExp.addData('name_enter.stopped', name_enter.tStopRefresh)
thisExp.addData('button1.started', button1.tStartRefresh)
thisExp.addData('button1.stopped', button1.tStopRefresh)
thisExp.addData('submit1.started', submit1.tStartRefresh)
thisExp.addData('submit1.stopped', submit1.tStopRefresh)
# store data for thisExp (ExperimentHandler)
x, y = mouse1.getPos()
buttons = mouse1.getPressed()
if sum(buttons):
    # check if the mouse was inside our 'clickable' objects
    gotValidClick = False
    try:
        iter(button1)
        clickableList = button1
    except:
        clickableList = [button1]
    for obj in clickableList:
        if obj.contains(mouse1):
            gotValidClick = True
            mouse1.clicked_name.append(obj.name)
thisExp.addData('mouse1.x', x)
thisExp.addData('mouse1.y', y)
thisExp.addData('mouse1.leftButton', buttons[0])
thisExp.addData('mouse1.midButton', buttons[1])
thisExp.addData('mouse1.rightButton', buttons[2])
if len(mouse1.clicked_name):
    thisExp.addData('mouse1.clicked_name', mouse1.clicked_name[0])
thisExp.addData('mouse1.started', mouse1.tStart)
thisExp.addData('mouse1.stopped', mouse1.tStop)
thisExp.nextEntry()
thisExp.addData('ptp_name.expStartVal', name_enter.text)  # Save exp start value
thisExp.addData('ptp_name.routineEndVal', ptp_name)  # Save end routine value
thisExp.addData('ptp_name.frameStartVal', ptp_nameContainer[0])  # Save start frame value
if ptp_name.isalpha() and (ptp_name.islower() or (len(ptp_name) > 2 and ptp_name.isupper())):
    ptp_name = strip(ptp_name.lower().capitalize())
# the Routine "Participant_name" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Participant_age"-------
continueRoutine = True
# update component parameters for each repeat
age_enter.reset()
age_enter.setText('')
# setup some python lists for storing info about the mouse2
mouse2.clicked_name = []
gotValidClick = False  # until a click is received
ptp_age = age_enter.text  # Set routine start values for ptp_age
# keep track of which components have finished
Participant_ageComponents = [age_question, age_enter, mouse2, button2, submit2, reminder]
for thisComponent in Participant_ageComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Participant_ageClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Participant_age"-------
while continueRoutine:
    # get current time
    t = Participant_ageClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Participant_ageClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *age_question* updates
    if age_question.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        age_question.frameNStart = frameN  # exact frame index
        age_question.tStart = t  # local t and not account for scr refresh
        age_question.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(age_question, 'tStartRefresh')  # time at next scr refresh
        age_question.setAutoDraw(True)
    
    # *age_enter* updates
    if age_enter.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        age_enter.frameNStart = frameN  # exact frame index
        age_enter.tStart = t  # local t and not account for scr refresh
        age_enter.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(age_enter, 'tStartRefresh')  # time at next scr refresh
        age_enter.setAutoDraw(True)
    # *mouse2* updates
    if mouse2.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        mouse2.frameNStart = frameN  # exact frame index
        mouse2.tStart = t  # local t and not account for scr refresh
        mouse2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(mouse2, 'tStartRefresh')  # time at next scr refresh
        mouse2.status = STARTED
        mouse2.mouseClock.reset()
        prevButtonState = mouse2.getPressed()  # if button is down already this ISN'T a new click
    if mouse2.status == STARTED:  # only update if started and not finished!
        buttons = mouse2.getPressed()
        if buttons != prevButtonState:  # button state changed?
            prevButtonState = buttons
            if sum(buttons) > 0:  # state changed to a new click
                # check if the mouse was inside our 'clickable' objects
                gotValidClick = False
                try:
                    iter(button2)
                    clickableList = button2
                except:
                    clickableList = [button2]
                for obj in clickableList:
                    if obj.contains(mouse2):
                        gotValidClick = True
                        mouse2.clicked_name.append(obj.name)
                if gotValidClick:  # abort routine on response
                    continueRoutine = False
    
    # *button2* updates
    if button2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        button2.frameNStart = frameN  # exact frame index
        button2.tStart = t  # local t and not account for scr refresh
        button2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(button2, 'tStartRefresh')  # time at next scr refresh
        button2.setAutoDraw(True)
    
    # *submit2* updates
    if submit2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        submit2.frameNStart = frameN  # exact frame index
        submit2.tStart = t  # local t and not account for scr refresh
        submit2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(submit2, 'tStartRefresh')  # time at next scr refresh
        submit2.setAutoDraw(True)
    
    # *reminder* updates
    if reminder.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        reminder.frameNStart = frameN  # exact frame index
        reminder.tStart = t  # local t and not account for scr refresh
        reminder.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(reminder, 'tStartRefresh')  # time at next scr refresh
        reminder.setAutoDraw(True)
    ptp_age = age_enter.text  # Set frame start values for ptp_age
    ptp_ageContainer.append(ptp_age)  # Save frame values
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Participant_ageComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Participant_age"-------
for thisComponent in Participant_ageComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('age_question.started', age_question.tStartRefresh)
thisExp.addData('age_question.stopped', age_question.tStopRefresh)
thisExp.addData('age_enter.text',age_enter.text)
thisExp.addData('age_enter.started', age_enter.tStartRefresh)
thisExp.addData('age_enter.stopped', age_enter.tStopRefresh)
# store data for thisExp (ExperimentHandler)
x, y = mouse2.getPos()
buttons = mouse2.getPressed()
if sum(buttons):
    # check if the mouse was inside our 'clickable' objects
    gotValidClick = False
    try:
        iter(button2)
        clickableList = button2
    except:
        clickableList = [button2]
    for obj in clickableList:
        if obj.contains(mouse2):
            gotValidClick = True
            mouse2.clicked_name.append(obj.name)
thisExp.addData('mouse2.x', x)
thisExp.addData('mouse2.y', y)
thisExp.addData('mouse2.leftButton', buttons[0])
thisExp.addData('mouse2.midButton', buttons[1])
thisExp.addData('mouse2.rightButton', buttons[2])
if len(mouse2.clicked_name):
    thisExp.addData('mouse2.clicked_name', mouse2.clicked_name[0])
thisExp.addData('mouse2.started', mouse2.tStart)
thisExp.addData('mouse2.stopped', mouse2.tStop)
thisExp.nextEntry()
thisExp.addData('button2.started', button2.tStartRefresh)
thisExp.addData('button2.stopped', button2.tStopRefresh)
thisExp.addData('submit2.started', submit2.tStartRefresh)
thisExp.addData('submit2.stopped', submit2.tStopRefresh)
thisExp.addData('reminder.started', reminder.tStartRefresh)
thisExp.addData('reminder.stopped', reminder.tStopRefresh)
thisExp.addData('ptp_age.routineEndVal', ptp_age)  # Save end routine value
thisExp.addData('ptp_age.frameStartVal', ptp_ageContainer[0])  # Save start frame value
# the Routine "Participant_age" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Participant_hometown"-------
continueRoutine = True
# update component parameters for each repeat
hometown_enter.reset()
hometown_enter.setText('')
# setup some python lists for storing info about the mouse3
mouse3.clicked_name = []
gotValidClick = False  # until a click is received
ptp_hometown = hometown_enter.text  # Set routine start values for ptp_hometown
# keep track of which components have finished
Participant_hometownComponents = [hometown_question, hometown_enter, mouse3, button3, submit3]
for thisComponent in Participant_hometownComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Participant_hometownClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Participant_hometown"-------
while continueRoutine:
    # get current time
    t = Participant_hometownClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Participant_hometownClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *hometown_question* updates
    if hometown_question.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        hometown_question.frameNStart = frameN  # exact frame index
        hometown_question.tStart = t  # local t and not account for scr refresh
        hometown_question.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(hometown_question, 'tStartRefresh')  # time at next scr refresh
        hometown_question.setAutoDraw(True)
    
    # *hometown_enter* updates
    if hometown_enter.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        hometown_enter.frameNStart = frameN  # exact frame index
        hometown_enter.tStart = t  # local t and not account for scr refresh
        hometown_enter.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(hometown_enter, 'tStartRefresh')  # time at next scr refresh
        hometown_enter.setAutoDraw(True)
    # *mouse3* updates
    if mouse3.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        mouse3.frameNStart = frameN  # exact frame index
        mouse3.tStart = t  # local t and not account for scr refresh
        mouse3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(mouse3, 'tStartRefresh')  # time at next scr refresh
        mouse3.status = STARTED
        mouse3.mouseClock.reset()
        prevButtonState = mouse3.getPressed()  # if button is down already this ISN'T a new click
    if mouse3.status == STARTED:  # only update if started and not finished!
        buttons = mouse3.getPressed()
        if buttons != prevButtonState:  # button state changed?
            prevButtonState = buttons
            if sum(buttons) > 0:  # state changed to a new click
                # check if the mouse was inside our 'clickable' objects
                gotValidClick = False
                try:
                    iter(button2)
                    clickableList = button2
                except:
                    clickableList = [button2]
                for obj in clickableList:
                    if obj.contains(mouse3):
                        gotValidClick = True
                        mouse3.clicked_name.append(obj.name)
                if gotValidClick:  # abort routine on response
                    continueRoutine = False
    
    # *button3* updates
    if button3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        button3.frameNStart = frameN  # exact frame index
        button3.tStart = t  # local t and not account for scr refresh
        button3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(button3, 'tStartRefresh')  # time at next scr refresh
        button3.setAutoDraw(True)
    
    # *submit3* updates
    if submit3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        submit3.frameNStart = frameN  # exact frame index
        submit3.tStart = t  # local t and not account for scr refresh
        submit3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(submit3, 'tStartRefresh')  # time at next scr refresh
        submit3.setAutoDraw(True)
    ptp_hometown = hometown_enter.text  # Set frame start values for ptp_hometown
    ptp_hometownContainer.append(ptp_hometown)  # Save frame values
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Participant_hometownComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Participant_hometown"-------
for thisComponent in Participant_hometownComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('hometown_question.started', hometown_question.tStartRefresh)
thisExp.addData('hometown_question.stopped', hometown_question.tStopRefresh)
thisExp.addData('hometown_enter.text',hometown_enter.text)
thisExp.addData('hometown_enter.started', hometown_enter.tStartRefresh)
thisExp.addData('hometown_enter.stopped', hometown_enter.tStopRefresh)
# store data for thisExp (ExperimentHandler)
x, y = mouse3.getPos()
buttons = mouse3.getPressed()
if sum(buttons):
    # check if the mouse was inside our 'clickable' objects
    gotValidClick = False
    try:
        iter(button2)
        clickableList = button2
    except:
        clickableList = [button2]
    for obj in clickableList:
        if obj.contains(mouse3):
            gotValidClick = True
            mouse3.clicked_name.append(obj.name)
thisExp.addData('mouse3.x', x)
thisExp.addData('mouse3.y', y)
thisExp.addData('mouse3.leftButton', buttons[0])
thisExp.addData('mouse3.midButton', buttons[1])
thisExp.addData('mouse3.rightButton', buttons[2])
if len(mouse3.clicked_name):
    thisExp.addData('mouse3.clicked_name', mouse3.clicked_name[0])
thisExp.addData('mouse3.started', mouse3.tStart)
thisExp.addData('mouse3.stopped', mouse3.tStop)
thisExp.nextEntry()
thisExp.addData('button3.started', button3.tStartRefresh)
thisExp.addData('button3.stopped', button3.tStopRefresh)
thisExp.addData('submit3.started', submit3.tStartRefresh)
thisExp.addData('submit3.stopped', submit3.tStopRefresh)
thisExp.addData('ptp_hometown.routineEndVal', ptp_hometown)  # Save end routine value
thisExp.addData('ptp_hometown.frameStartVal', ptp_hometownContainer[0])  # Save start frame value
if ptp_hometown.isalpha() and (ptp_hometown.islower() or (len(ptp_hometown) > 2 and ptp_hometown.isupper())):
    ptp_hometown = ptp_hometown.lower().capitalize()
# the Routine "Participant_hometown" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Participant_interest"-------
continueRoutine = True
# update component parameters for each repeat
interest_enter.reset()
interest_enter.setText('')
# setup some python lists for storing info about the mouse4
mouse4.clicked_name = []
gotValidClick = False  # until a click is received
ptp_interest = interest_enter.text  # Set routine start values for ptp_interest
# keep track of which components have finished
Participant_interestComponents = [interest_question, interest_enter, mouse4, button4, submit4]
for thisComponent in Participant_interestComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Participant_interestClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Participant_interest"-------
while continueRoutine:
    # get current time
    t = Participant_interestClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Participant_interestClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *interest_question* updates
    if interest_question.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        interest_question.frameNStart = frameN  # exact frame index
        interest_question.tStart = t  # local t and not account for scr refresh
        interest_question.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(interest_question, 'tStartRefresh')  # time at next scr refresh
        interest_question.setAutoDraw(True)
    
    # *interest_enter* updates
    if interest_enter.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        interest_enter.frameNStart = frameN  # exact frame index
        interest_enter.tStart = t  # local t and not account for scr refresh
        interest_enter.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(interest_enter, 'tStartRefresh')  # time at next scr refresh
        interest_enter.setAutoDraw(True)
    # *mouse4* updates
    if mouse4.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        mouse4.frameNStart = frameN  # exact frame index
        mouse4.tStart = t  # local t and not account for scr refresh
        mouse4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(mouse4, 'tStartRefresh')  # time at next scr refresh
        mouse4.status = STARTED
        mouse4.mouseClock.reset()
        prevButtonState = mouse4.getPressed()  # if button is down already this ISN'T a new click
    if mouse4.status == STARTED:  # only update if started and not finished!
        buttons = mouse4.getPressed()
        if buttons != prevButtonState:  # button state changed?
            prevButtonState = buttons
            if sum(buttons) > 0:  # state changed to a new click
                # check if the mouse was inside our 'clickable' objects
                gotValidClick = False
                try:
                    iter(button2)
                    clickableList = button2
                except:
                    clickableList = [button2]
                for obj in clickableList:
                    if obj.contains(mouse4):
                        gotValidClick = True
                        mouse4.clicked_name.append(obj.name)
                if gotValidClick:  # abort routine on response
                    continueRoutine = False
    
    # *button4* updates
    if button4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        button4.frameNStart = frameN  # exact frame index
        button4.tStart = t  # local t and not account for scr refresh
        button4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(button4, 'tStartRefresh')  # time at next scr refresh
        button4.setAutoDraw(True)
    
    # *submit4* updates
    if submit4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        submit4.frameNStart = frameN  # exact frame index
        submit4.tStart = t  # local t and not account for scr refresh
        submit4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(submit4, 'tStartRefresh')  # time at next scr refresh
        submit4.setAutoDraw(True)
    ptp_interest = interest_enter.text  # Set frame start values for ptp_interest
    ptp_interestContainer.append(ptp_interest)  # Save frame values
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Participant_interestComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Participant_interest"-------
for thisComponent in Participant_interestComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('interest_question.started', interest_question.tStartRefresh)
thisExp.addData('interest_question.stopped', interest_question.tStopRefresh)
thisExp.addData('interest_enter.text',interest_enter.text)
thisExp.addData('interest_enter.started', interest_enter.tStartRefresh)
thisExp.addData('interest_enter.stopped', interest_enter.tStopRefresh)
# store data for thisExp (ExperimentHandler)
x, y = mouse4.getPos()
buttons = mouse4.getPressed()
if sum(buttons):
    # check if the mouse was inside our 'clickable' objects
    gotValidClick = False
    try:
        iter(button2)
        clickableList = button2
    except:
        clickableList = [button2]
    for obj in clickableList:
        if obj.contains(mouse4):
            gotValidClick = True
            mouse4.clicked_name.append(obj.name)
thisExp.addData('mouse4.x', x)
thisExp.addData('mouse4.y', y)
thisExp.addData('mouse4.leftButton', buttons[0])
thisExp.addData('mouse4.midButton', buttons[1])
thisExp.addData('mouse4.rightButton', buttons[2])
if len(mouse4.clicked_name):
    thisExp.addData('mouse4.clicked_name', mouse4.clicked_name[0])
thisExp.addData('mouse4.started', mouse4.tStart)
thisExp.addData('mouse4.stopped', mouse4.tStop)
thisExp.nextEntry()
thisExp.addData('button4.started', button4.tStartRefresh)
thisExp.addData('button4.stopped', button4.tStopRefresh)
thisExp.addData('submit4.started', submit4.tStartRefresh)
thisExp.addData('submit4.stopped', submit4.tStopRefresh)
thisExp.addData('ptp_interest.routineEndVal', ptp_interest)  # Save end routine value
thisExp.addData('ptp_interest.frameStartVal', ptp_interestContainer[0])  # Save start frame value
# the Routine "Participant_interest" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Participant_profile"-------
continueRoutine = True
routineTimer.add(3.000000)
# update component parameters for each repeat
part_response.alignText = 'left'
part_prompts.alignText = 'left'
part_name.alignText = 'left'
part_name.bold = 'True'
# keep track of which components have finished
Participant_profileComponents = [image_4, border4, border, subject_image, part_response, part_prompts, part_name]
for thisComponent in Participant_profileComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Participant_profileClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Participant_profile"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = Participant_profileClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Participant_profileClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_4* updates
    if image_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_4.frameNStart = frameN  # exact frame index
        image_4.tStart = t  # local t and not account for scr refresh
        image_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_4, 'tStartRefresh')  # time at next scr refresh
        image_4.setAutoDraw(True)
    if image_4.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_4.tStartRefresh + 3.0-frameTolerance:
            # keep track of stop time/frame for later
            image_4.tStop = t  # not accounting for scr refresh
            image_4.frameNStop = frameN  # exact frame index
            win.timeOnFlip(image_4, 'tStopRefresh')  # time at next scr refresh
            image_4.setAutoDraw(False)
    
    # *border4* updates
    if border4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        border4.frameNStart = frameN  # exact frame index
        border4.tStart = t  # local t and not account for scr refresh
        border4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(border4, 'tStartRefresh')  # time at next scr refresh
        border4.setAutoDraw(True)
    if border4.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > border4.tStartRefresh + 3-frameTolerance:
            # keep track of stop time/frame for later
            border4.tStop = t  # not accounting for scr refresh
            border4.frameNStop = frameN  # exact frame index
            win.timeOnFlip(border4, 'tStopRefresh')  # time at next scr refresh
            border4.setAutoDraw(False)
    
    # *border* updates
    if border.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        border.frameNStart = frameN  # exact frame index
        border.tStart = t  # local t and not account for scr refresh
        border.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(border, 'tStartRefresh')  # time at next scr refresh
        border.setAutoDraw(True)
    if border.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > border.tStartRefresh + 3.0-frameTolerance:
            # keep track of stop time/frame for later
            border.tStop = t  # not accounting for scr refresh
            border.frameNStop = frameN  # exact frame index
            win.timeOnFlip(border, 'tStopRefresh')  # time at next scr refresh
            border.setAutoDraw(False)
    
    # *subject_image* updates
    if subject_image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        subject_image.frameNStart = frameN  # exact frame index
        subject_image.tStart = t  # local t and not account for scr refresh
        subject_image.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(subject_image, 'tStartRefresh')  # time at next scr refresh
        subject_image.setAutoDraw(True)
    if subject_image.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > subject_image.tStartRefresh + 3.0-frameTolerance:
            # keep track of stop time/frame for later
            subject_image.tStop = t  # not accounting for scr refresh
            subject_image.frameNStop = frameN  # exact frame index
            win.timeOnFlip(subject_image, 'tStopRefresh')  # time at next scr refresh
            subject_image.setAutoDraw(False)
    
    # *part_response* updates
    if part_response.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        part_response.frameNStart = frameN  # exact frame index
        part_response.tStart = t  # local t and not account for scr refresh
        part_response.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(part_response, 'tStartRefresh')  # time at next scr refresh
        part_response.setAutoDraw(True)
    if part_response.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > part_response.tStartRefresh + 3.0-frameTolerance:
            # keep track of stop time/frame for later
            part_response.tStop = t  # not accounting for scr refresh
            part_response.frameNStop = frameN  # exact frame index
            win.timeOnFlip(part_response, 'tStopRefresh')  # time at next scr refresh
            part_response.setAutoDraw(False)
    if part_response.status == STARTED:  # only update if drawing
        part_response.setText(ptp_age + '\n' + ptp_hometown + '\n' + ptp_interest, log=False)
    
    # *part_prompts* updates
    if part_prompts.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        part_prompts.frameNStart = frameN  # exact frame index
        part_prompts.tStart = t  # local t and not account for scr refresh
        part_prompts.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(part_prompts, 'tStartRefresh')  # time at next scr refresh
        part_prompts.setAutoDraw(True)
    if part_prompts.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > part_prompts.tStartRefresh + 3-frameTolerance:
            # keep track of stop time/frame for later
            part_prompts.tStop = t  # not accounting for scr refresh
            part_prompts.frameNStop = frameN  # exact frame index
            win.timeOnFlip(part_prompts, 'tStopRefresh')  # time at next scr refresh
            part_prompts.setAutoDraw(False)
    
    # *part_name* updates
    if part_name.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        part_name.frameNStart = frameN  # exact frame index
        part_name.tStart = t  # local t and not account for scr refresh
        part_name.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(part_name, 'tStartRefresh')  # time at next scr refresh
        part_name.setAutoDraw(True)
    if part_name.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > part_name.tStartRefresh + 3-frameTolerance:
            # keep track of stop time/frame for later
            part_name.tStop = t  # not accounting for scr refresh
            part_name.frameNStop = frameN  # exact frame index
            win.timeOnFlip(part_name, 'tStopRefresh')  # time at next scr refresh
            part_name.setAutoDraw(False)
    if part_name.status == STARTED:  # only update if drawing
        part_name.setText(ptp_name, log=False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Participant_profileComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Participant_profile"-------
for thisComponent in Participant_profileComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image_4.started', image_4.tStartRefresh)
thisExp.addData('image_4.stopped', image_4.tStopRefresh)
thisExp.addData('border4.started', border4.tStartRefresh)
thisExp.addData('border4.stopped', border4.tStopRefresh)
thisExp.addData('border.started', border.tStartRefresh)
thisExp.addData('border.stopped', border.tStopRefresh)
thisExp.addData('subject_image.started', subject_image.tStartRefresh)
thisExp.addData('subject_image.stopped', subject_image.tStopRefresh)
thisExp.addData('part_response.started', part_response.tStartRefresh)
thisExp.addData('part_response.stopped', part_response.tStopRefresh)
thisExp.addData('part_prompts.started', part_prompts.tStartRefresh)
thisExp.addData('part_prompts.stopped', part_prompts.tStopRefresh)
thisExp.addData('part_name.started', part_name.tStartRefresh)
thisExp.addData('part_name.stopped', part_name.tStopRefresh)

# ------Prepare to start Routine "Introduction_3"-------
continueRoutine = True
# update component parameters for each repeat
text_3.setText('Take a moment to learn about \nthe other players.\n\nPress any key to continue. ')
key_resp_3.keys = []
key_resp_3.rt = []
_key_resp_3_allKeys = []
# keep track of which components have finished
Introduction_3Components = [image_3, polygon, text_3, key_resp_3]
for thisComponent in Introduction_3Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Introduction_3Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Introduction_3"-------
while continueRoutine:
    # get current time
    t = Introduction_3Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Introduction_3Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_3* updates
    if image_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_3.frameNStart = frameN  # exact frame index
        image_3.tStart = t  # local t and not account for scr refresh
        image_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_3, 'tStartRefresh')  # time at next scr refresh
        image_3.setAutoDraw(True)
    
    # *polygon* updates
    if polygon.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        polygon.frameNStart = frameN  # exact frame index
        polygon.tStart = t  # local t and not account for scr refresh
        polygon.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(polygon, 'tStartRefresh')  # time at next scr refresh
        polygon.setAutoDraw(True)
    
    # *text_3* updates
    if text_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_3.frameNStart = frameN  # exact frame index
        text_3.tStart = t  # local t and not account for scr refresh
        text_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_3, 'tStartRefresh')  # time at next scr refresh
        text_3.setAutoDraw(True)
    
    # *key_resp_3* updates
    waitOnFlip = False
    if key_resp_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_3.frameNStart = frameN  # exact frame index
        key_resp_3.tStart = t  # local t and not account for scr refresh
        key_resp_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_3, 'tStartRefresh')  # time at next scr refresh
        key_resp_3.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_3.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_3.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_3.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_3.getKeys(keyList=None, waitRelease=False)
        _key_resp_3_allKeys.extend(theseKeys)
        if len(_key_resp_3_allKeys):
            key_resp_3.keys = _key_resp_3_allKeys[-1].name  # just the last key pressed
            key_resp_3.rt = _key_resp_3_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Introduction_3Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Introduction_3"-------
for thisComponent in Introduction_3Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image_3.started', image_3.tStartRefresh)
thisExp.addData('image_3.stopped', image_3.tStopRefresh)
thisExp.addData('polygon.started', polygon.tStartRefresh)
thisExp.addData('polygon.stopped', polygon.tStopRefresh)
thisExp.addData('text_3.started', text_3.tStartRefresh)
thisExp.addData('text_3.stopped', text_3.tStopRefresh)
# check responses
if key_resp_3.keys in ['', [], None]:  # No response was made
    key_resp_3.keys = None
thisExp.addData('key_resp_3.keys',key_resp_3.keys)
if key_resp_3.keys != None:  # we had a response
    thisExp.addData('key_resp_3.rt', key_resp_3.rt)
thisExp.addData('key_resp_3.started', key_resp_3.tStartRefresh)
thisExp.addData('key_resp_3.stopped', key_resp_3.tStopRefresh)
thisExp.nextEntry()
# the Routine "Introduction_3" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
coplayers = data.TrialHandler(nReps=1.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Trials.xlsx'),
    seed=None, name='coplayers')
thisExp.addLoop(coplayers)  # add the loop to the experiment
thisCoplayer = coplayers.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisCoplayer.rgb)
if thisCoplayer != None:
    for paramName in thisCoplayer:
        exec('{} = thisCoplayer[paramName]'.format(paramName))

for thisCoplayer in coplayers:
    currentLoop = coplayers
    # abbreviate parameter names if possible (e.g. rgb = thisCoplayer.rgb)
    if thisCoplayer != None:
        for paramName in thisCoplayer:
            exec('{} = thisCoplayer[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "Player_profiles_voting_style"-------
    continueRoutine = True
    # update component parameters for each repeat
    coplayer_image.setImage(cop_photo)
    cop_prompts.reset()
    cop_response.setText(cop_name + '\n' + str(cop_age) + '\n' + cop_hometown + '\n' + cop_interests)
    cop_response.alignText = 'left'
    cop_age_st = (str(cop_age))
    # setup some python lists for storing info about the mouse
    mouse.clicked_name = []
    gotValidClick = False  # until a click is received
    # keep track of which components have finished
    Player_profiles_voting_styleComponents = [border_2, coplayer_image, cop_prompts, cop_response, button_5, mouse, continue_button]
    for thisComponent in Player_profiles_voting_styleComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Player_profiles_voting_styleClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Player_profiles_voting_style"-------
    while continueRoutine:
        # get current time
        t = Player_profiles_voting_styleClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Player_profiles_voting_styleClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *border_2* updates
        if border_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            border_2.frameNStart = frameN  # exact frame index
            border_2.tStart = t  # local t and not account for scr refresh
            border_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(border_2, 'tStartRefresh')  # time at next scr refresh
            border_2.setAutoDraw(True)
        
        # *coplayer_image* updates
        if coplayer_image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            coplayer_image.frameNStart = frameN  # exact frame index
            coplayer_image.tStart = t  # local t and not account for scr refresh
            coplayer_image.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(coplayer_image, 'tStartRefresh')  # time at next scr refresh
            coplayer_image.setAutoDraw(True)
        
        # *cop_prompts* updates
        if cop_prompts.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            cop_prompts.frameNStart = frameN  # exact frame index
            cop_prompts.tStart = t  # local t and not account for scr refresh
            cop_prompts.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(cop_prompts, 'tStartRefresh')  # time at next scr refresh
            cop_prompts.setAutoDraw(True)
        
        # *cop_response* updates
        if cop_response.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            cop_response.frameNStart = frameN  # exact frame index
            cop_response.tStart = t  # local t and not account for scr refresh
            cop_response.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(cop_response, 'tStartRefresh')  # time at next scr refresh
            cop_response.setAutoDraw(True)
        
        # *button_5* updates
        if button_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            button_5.frameNStart = frameN  # exact frame index
            button_5.tStart = t  # local t and not account for scr refresh
            button_5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(button_5, 'tStartRefresh')  # time at next scr refresh
            button_5.setAutoDraw(True)
        # *mouse* updates
        if mouse.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            mouse.frameNStart = frameN  # exact frame index
            mouse.tStart = t  # local t and not account for scr refresh
            mouse.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(mouse, 'tStartRefresh')  # time at next scr refresh
            mouse.status = STARTED
            mouse.mouseClock.reset()
            prevButtonState = mouse.getPressed()  # if button is down already this ISN'T a new click
        if mouse.status == STARTED:  # only update if started and not finished!
            buttons = mouse.getPressed()
            if buttons != prevButtonState:  # button state changed?
                prevButtonState = buttons
                if sum(buttons) > 0:  # state changed to a new click
                    # check if the mouse was inside our 'clickable' objects
                    gotValidClick = False
                    try:
                        iter(button_5)
                        clickableList = button_5
                    except:
                        clickableList = [button_5]
                    for obj in clickableList:
                        if obj.contains(mouse):
                            gotValidClick = True
                            mouse.clicked_name.append(obj.name)
                    if gotValidClick:  # abort routine on response
                        continueRoutine = False
        
        # *continue_button* updates
        if continue_button.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            continue_button.frameNStart = frameN  # exact frame index
            continue_button.tStart = t  # local t and not account for scr refresh
            continue_button.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(continue_button, 'tStartRefresh')  # time at next scr refresh
            continue_button.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Player_profiles_voting_styleComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Player_profiles_voting_style"-------
    for thisComponent in Player_profiles_voting_styleComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    coplayers.addData('border_2.started', border_2.tStartRefresh)
    coplayers.addData('border_2.stopped', border_2.tStopRefresh)
    coplayers.addData('coplayer_image.started', coplayer_image.tStartRefresh)
    coplayers.addData('coplayer_image.stopped', coplayer_image.tStopRefresh)
    coplayers.addData('cop_prompts.started', cop_prompts.tStartRefresh)
    coplayers.addData('cop_prompts.stopped', cop_prompts.tStopRefresh)
    coplayers.addData('cop_response.started', cop_response.tStartRefresh)
    coplayers.addData('cop_response.stopped', cop_response.tStopRefresh)
    coplayers.addData('button_5.started', button_5.tStartRefresh)
    coplayers.addData('button_5.stopped', button_5.tStopRefresh)
    # store data for coplayers (TrialHandler)
    x, y = mouse.getPos()
    buttons = mouse.getPressed()
    if sum(buttons):
        # check if the mouse was inside our 'clickable' objects
        gotValidClick = False
        try:
            iter(button_5)
            clickableList = button_5
        except:
            clickableList = [button_5]
        for obj in clickableList:
            if obj.contains(mouse):
                gotValidClick = True
                mouse.clicked_name.append(obj.name)
    coplayers.addData('mouse.x', x)
    coplayers.addData('mouse.y', y)
    coplayers.addData('mouse.leftButton', buttons[0])
    coplayers.addData('mouse.midButton', buttons[1])
    coplayers.addData('mouse.rightButton', buttons[2])
    if len(mouse.clicked_name):
        coplayers.addData('mouse.clicked_name', mouse.clicked_name[0])
    coplayers.addData('mouse.started', mouse.tStart)
    coplayers.addData('mouse.stopped', mouse.tStop)
    coplayers.addData('continue_button.started', continue_button.tStartRefresh)
    coplayers.addData('continue_button.stopped', continue_button.tStopRefresh)
    # the Routine "Player_profiles_voting_style" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'coplayers'

del ptp_name
del ptp_age
del ptp_hometown
del ptp_interest
del response
del name_enter.text
del age_enter.text
del hometown_enter.text
del interest_enter.text

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
