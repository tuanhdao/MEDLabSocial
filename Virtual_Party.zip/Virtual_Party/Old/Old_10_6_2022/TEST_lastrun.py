﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2021.2.3),
    on October 06, 2022, at 10:06
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, parallel
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2021.2.3'
expName = 'TEST'  # from the Builder filename that created this script
expInfo = {'participant': '', 'session': '001'}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Dropbox\\Reprogrammed IG\\TEST_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=(1024, 768), fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Setup eyetracking
ioDevice = ioConfig = ioSession = ioServer = eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "Waiting_6"
Waiting_6Clock = core.Clock()
image_34 = visual.ImageStim(
    win=win,
    name='image_34', 
    image='images/round5.jpg', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
polygon_23 = visual.Rect(
    win=win, name='polygon_23',
    width=(1.5, 0.75)[0], height=(1.5, 0.75)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=0.8, depth=-1.0, interpolate=True)
text_19 = visual.TextStim(win=win, name='text_19',
    text='',
    font='Arial',
    pos=(0, 0.1), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
key_resp_15 = keyboard.Keyboard()
image_35 = visual.ImageStim(
    win=win,
    name='image_35', 
    image='images/load-icon-png-7945.png', mask=None,
    ori=0.0, pos=(0, -0.05), size=(0.25, 0.25),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-4.0)

# Initialize components for Routine "Result"
ResultClock = core.Clock()
party_pic = visual.ImageStim(
    win=win,
    name='party_pic', 
    image='sin', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
border_25 = visual.Rect(
    win=win, name='border_25',
    width=(1.5, 0.75)[0], height=(1.5, 0.75)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=0.9, depth=-1.0, interpolate=True)
border_26 = visual.Rect(
    win=win, name='border_26',
    width=(0.19, 0.28)[0], height=(0.19, 0.28)[1],
    ori=0.0, pos=(-0.5, 0.1),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='black', fillColor='black',
    opacity=None, depth=-2.0, interpolate=True)
next_result = keyboard.Keyboard()
border_27 = visual.Rect(
    win=win, name='border_27',
    width=(0.19, 0.28)[0], height=(0.19, 0.28)[1],
    ori=0.0, pos=(-0.3, 0.1),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='black', fillColor='black',
    opacity=None, depth=-4.0, interpolate=True)
border_28 = visual.Rect(
    win=win, name='border_28',
    width=(0.19, 0.28)[0], height=(0.19, 0.28)[1],
    ori=0.0, pos=(-0.1, 0.1),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='black', fillColor='black',
    opacity=None, depth=-5.0, interpolate=True)
border_29 = visual.Rect(
    win=win, name='border_29',
    width=(0.19, 0.28)[0], height=(0.19, 0.28)[1],
    ori=0.0, pos=(0.1, 0.1),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='black', fillColor='black',
    opacity=None, depth=-6.0, interpolate=True)
border_30 = visual.Rect(
    win=win, name='border_30',
    width=(0.19, 0.28)[0], height=(0.19, 0.28)[1],
    ori=0.0, pos=(0.3, 0.1),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='black', fillColor='black',
    opacity=None, depth=-7.0, interpolate=True)
border_31 = visual.Rect(
    win=win, name='border_31',
    width=(0.19, 0.28)[0], height=(0.19, 0.28)[1],
    ori=0.0, pos=(0.5, 0.1),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='black', fillColor='black',
    opacity=None, depth=-8.0, interpolate=True)
text_24 = visual.TextStim(win=win, name='text_24',
    text='CONGRATULATIONS!  You are invited!',
    font='Arial',
    pos=(0, -0.19), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-9.0);
res_trigger = parallel.ParallelPort(address='0xE010')

# Initialize components for Routine "trial"
trialClock = core.Clock()

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "Waiting_6"-------
continueRoutine = True
routineTimer.add(5.000000)
# update component parameters for each repeat
text_19.setText('Ok, the votes are in and it’s time to find out who is invited to the party… ')
key_resp_15.keys = []
key_resp_15.rt = []
_key_resp_15_allKeys = []
# keep track of which components have finished
Waiting_6Components = [image_34, polygon_23, text_19, key_resp_15, image_35]
for thisComponent in Waiting_6Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Waiting_6Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Waiting_6"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = Waiting_6Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Waiting_6Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_34* updates
    if image_34.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_34.frameNStart = frameN  # exact frame index
        image_34.tStart = t  # local t and not account for scr refresh
        image_34.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_34, 'tStartRefresh')  # time at next scr refresh
        image_34.setAutoDraw(True)
    if image_34.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_34.tStartRefresh + 5-frameTolerance:
            # keep track of stop time/frame for later
            image_34.tStop = t  # not accounting for scr refresh
            image_34.frameNStop = frameN  # exact frame index
            win.timeOnFlip(image_34, 'tStopRefresh')  # time at next scr refresh
            image_34.setAutoDraw(False)
    
    # *polygon_23* updates
    if polygon_23.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        polygon_23.frameNStart = frameN  # exact frame index
        polygon_23.tStart = t  # local t and not account for scr refresh
        polygon_23.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(polygon_23, 'tStartRefresh')  # time at next scr refresh
        polygon_23.setAutoDraw(True)
    if polygon_23.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > polygon_23.tStartRefresh + 5-frameTolerance:
            # keep track of stop time/frame for later
            polygon_23.tStop = t  # not accounting for scr refresh
            polygon_23.frameNStop = frameN  # exact frame index
            win.timeOnFlip(polygon_23, 'tStopRefresh')  # time at next scr refresh
            polygon_23.setAutoDraw(False)
    
    # *text_19* updates
    if text_19.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_19.frameNStart = frameN  # exact frame index
        text_19.tStart = t  # local t and not account for scr refresh
        text_19.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_19, 'tStartRefresh')  # time at next scr refresh
        text_19.setAutoDraw(True)
    if text_19.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > text_19.tStartRefresh + 5-frameTolerance:
            # keep track of stop time/frame for later
            text_19.tStop = t  # not accounting for scr refresh
            text_19.frameNStop = frameN  # exact frame index
            win.timeOnFlip(text_19, 'tStopRefresh')  # time at next scr refresh
            text_19.setAutoDraw(False)
    
    # *key_resp_15* updates
    waitOnFlip = False
    if key_resp_15.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_15.frameNStart = frameN  # exact frame index
        key_resp_15.tStart = t  # local t and not account for scr refresh
        key_resp_15.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_15, 'tStartRefresh')  # time at next scr refresh
        key_resp_15.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_15.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_15.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_15.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > key_resp_15.tStartRefresh + 5-frameTolerance:
            # keep track of stop time/frame for later
            key_resp_15.tStop = t  # not accounting for scr refresh
            key_resp_15.frameNStop = frameN  # exact frame index
            win.timeOnFlip(key_resp_15, 'tStopRefresh')  # time at next scr refresh
            key_resp_15.status = FINISHED
    if key_resp_15.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_15.getKeys(keyList=None, waitRelease=False)
        _key_resp_15_allKeys.extend(theseKeys)
        if len(_key_resp_15_allKeys):
            key_resp_15.keys = _key_resp_15_allKeys[-1].name  # just the last key pressed
            key_resp_15.rt = _key_resp_15_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *image_35* updates
    if image_35.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_35.frameNStart = frameN  # exact frame index
        image_35.tStart = t  # local t and not account for scr refresh
        image_35.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_35, 'tStartRefresh')  # time at next scr refresh
        image_35.setAutoDraw(True)
    if image_35.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_35.tStartRefresh + 5-frameTolerance:
            # keep track of stop time/frame for later
            image_35.tStop = t  # not accounting for scr refresh
            image_35.frameNStop = frameN  # exact frame index
            win.timeOnFlip(image_35, 'tStopRefresh')  # time at next scr refresh
            image_35.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Waiting_6Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Waiting_6"-------
for thisComponent in Waiting_6Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image_34.started', image_34.tStartRefresh)
thisExp.addData('image_34.stopped', image_34.tStopRefresh)
thisExp.addData('polygon_23.started', polygon_23.tStartRefresh)
thisExp.addData('polygon_23.stopped', polygon_23.tStopRefresh)
thisExp.addData('text_19.started', text_19.tStartRefresh)
thisExp.addData('text_19.stopped', text_19.tStopRefresh)
# check responses
if key_resp_15.keys in ['', [], None]:  # No response was made
    key_resp_15.keys = None
thisExp.addData('key_resp_15.keys',key_resp_15.keys)
if key_resp_15.keys != None:  # we had a response
    thisExp.addData('key_resp_15.rt', key_resp_15.rt)
thisExp.addData('key_resp_15.started', key_resp_15.tStartRefresh)
thisExp.addData('key_resp_15.stopped', key_resp_15.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('image_35.started', image_35.tStartRefresh)
thisExp.addData('image_35.stopped', image_35.tStopRefresh)

# ------Prepare to start Routine "Result"-------
continueRoutine = True
# update component parameters for each repeat
party_pic.setImage('images/background_party.jpg')
next_result.keys = []
next_result.rt = []
_next_result_allKeys = []
# keep track of which components have finished
ResultComponents = [party_pic, border_25, border_26, next_result, border_27, border_28, border_29, border_30, border_31, text_24, res_trigger]
for thisComponent in ResultComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
ResultClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Result"-------
while continueRoutine:
    # get current time
    t = ResultClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=ResultClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *party_pic* updates
    if party_pic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        party_pic.frameNStart = frameN  # exact frame index
        party_pic.tStart = t  # local t and not account for scr refresh
        party_pic.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(party_pic, 'tStartRefresh')  # time at next scr refresh
        party_pic.setAutoDraw(True)
    
    # *border_25* updates
    if border_25.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        border_25.frameNStart = frameN  # exact frame index
        border_25.tStart = t  # local t and not account for scr refresh
        border_25.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(border_25, 'tStartRefresh')  # time at next scr refresh
        border_25.setAutoDraw(True)
    
    # *border_26* updates
    if border_26.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        border_26.frameNStart = frameN  # exact frame index
        border_26.tStart = t  # local t and not account for scr refresh
        border_26.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(border_26, 'tStartRefresh')  # time at next scr refresh
        border_26.setAutoDraw(True)
    
    # *next_result* updates
    waitOnFlip = False
    if next_result.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        next_result.frameNStart = frameN  # exact frame index
        next_result.tStart = t  # local t and not account for scr refresh
        next_result.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(next_result, 'tStartRefresh')  # time at next scr refresh
        next_result.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(next_result.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(next_result.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if next_result.status == STARTED and not waitOnFlip:
        theseKeys = next_result.getKeys(keyList=['space'], waitRelease=False)
        _next_result_allKeys.extend(theseKeys)
        if len(_next_result_allKeys):
            next_result.keys = _next_result_allKeys[-1].name  # just the last key pressed
            next_result.rt = _next_result_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *border_27* updates
    if border_27.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        border_27.frameNStart = frameN  # exact frame index
        border_27.tStart = t  # local t and not account for scr refresh
        border_27.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(border_27, 'tStartRefresh')  # time at next scr refresh
        border_27.setAutoDraw(True)
    
    # *border_28* updates
    if border_28.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        border_28.frameNStart = frameN  # exact frame index
        border_28.tStart = t  # local t and not account for scr refresh
        border_28.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(border_28, 'tStartRefresh')  # time at next scr refresh
        border_28.setAutoDraw(True)
    
    # *border_29* updates
    if border_29.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        border_29.frameNStart = frameN  # exact frame index
        border_29.tStart = t  # local t and not account for scr refresh
        border_29.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(border_29, 'tStartRefresh')  # time at next scr refresh
        border_29.setAutoDraw(True)
    
    # *border_30* updates
    if border_30.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        border_30.frameNStart = frameN  # exact frame index
        border_30.tStart = t  # local t and not account for scr refresh
        border_30.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(border_30, 'tStartRefresh')  # time at next scr refresh
        border_30.setAutoDraw(True)
    
    # *border_31* updates
    if border_31.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        border_31.frameNStart = frameN  # exact frame index
        border_31.tStart = t  # local t and not account for scr refresh
        border_31.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(border_31, 'tStartRefresh')  # time at next scr refresh
        border_31.setAutoDraw(True)
    
    # *text_24* updates
    if text_24.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_24.frameNStart = frameN  # exact frame index
        text_24.tStart = t  # local t and not account for scr refresh
        text_24.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_24, 'tStartRefresh')  # time at next scr refresh
        text_24.setAutoDraw(True)
    # *res_trigger* updates
    if res_trigger.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        res_trigger.frameNStart = frameN  # exact frame index
        res_trigger.tStart = t  # local t and not account for scr refresh
        res_trigger.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(res_trigger, 'tStartRefresh')  # time at next scr refresh
        res_trigger.status = STARTED
        win.callOnFlip(res_trigger.setData, int())
    if res_trigger.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > res_trigger.tStartRefresh + 0.01-frameTolerance:
            # keep track of stop time/frame for later
            res_trigger.tStop = t  # not accounting for scr refresh
            res_trigger.frameNStop = frameN  # exact frame index
            win.timeOnFlip(res_trigger, 'tStopRefresh')  # time at next scr refresh
            res_trigger.status = FINISHED
            win.callOnFlip(res_trigger.setData, int(0))
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in ResultComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Result"-------
for thisComponent in ResultComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('party_pic.started', party_pic.tStartRefresh)
thisExp.addData('party_pic.stopped', party_pic.tStopRefresh)
thisExp.addData('border_25.started', border_25.tStartRefresh)
thisExp.addData('border_25.stopped', border_25.tStopRefresh)
thisExp.addData('border_26.started', border_26.tStartRefresh)
thisExp.addData('border_26.stopped', border_26.tStopRefresh)
# check responses
if next_result.keys in ['', [], None]:  # No response was made
    next_result.keys = None
thisExp.addData('next_result.keys',next_result.keys)
if next_result.keys != None:  # we had a response
    thisExp.addData('next_result.rt', next_result.rt)
thisExp.addData('next_result.started', next_result.tStartRefresh)
thisExp.addData('next_result.stopped', next_result.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('border_27.started', border_27.tStartRefresh)
thisExp.addData('border_27.stopped', border_27.tStopRefresh)
thisExp.addData('border_28.started', border_28.tStartRefresh)
thisExp.addData('border_28.stopped', border_28.tStopRefresh)
thisExp.addData('border_29.started', border_29.tStartRefresh)
thisExp.addData('border_29.stopped', border_29.tStopRefresh)
thisExp.addData('border_30.started', border_30.tStartRefresh)
thisExp.addData('border_30.stopped', border_30.tStopRefresh)
thisExp.addData('border_31.started', border_31.tStartRefresh)
thisExp.addData('border_31.stopped', border_31.tStopRefresh)
thisExp.addData('text_24.started', text_24.tStartRefresh)
thisExp.addData('text_24.stopped', text_24.tStopRefresh)
if res_trigger.status == STARTED:
    win.callOnFlip(res_trigger.setData, int(0))
thisExp.addData('res_trigger.started', res_trigger.tStart)
thisExp.addData('res_trigger.stopped', res_trigger.tStop)
# the Routine "Result" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "trial"-------
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
trialComponents = []
for thisComponent in trialComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
trialClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "trial"-------
while continueRoutine:
    # get current time
    t = trialClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=trialClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in trialComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "trial"-------
for thisComponent in trialComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "trial" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
