﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2021.2.3),
    on July 13, 2022, at 13:05
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2021.2.3'
expName = 'untitled'  # from the Builder filename that created this script
expInfo = {'participant': '', 'session': '001'}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\tuanh\\OneDrive - Vanderbilt\\Desktop\\Reprogrammed IG\\untitled_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=[1536, 864], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color='black', colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Setup eyetracking
ioDevice = ioConfig = ioSession = ioServer = eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "post_q1"
post_q1Clock = core.Clock()
header1 = visual.TextStim(win=win, name='header1',
    text='',
    font='Arial',
    pos=(0, 0.43), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
indicate = visual.TextStim(win=win, name='indicate',
    text='',
    font='Arial',
    pos=(0, 0.32), height=0.03, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
instructions1 = visual.TextStim(win=win, name='instructions1',
    text='Use the mouse to pick the option that represents how you feel, then press space to submit.',
    font='Arial',
    pos=(0, -0.4), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
interested_slider = visual.Slider(win=win, name='interested_slider',
    startValue=None, size=(1.0, 0.03), pos=(0, 0.15), units=None,
    labels=["Very slightly or not at all","A little","Moderately","Quite a bit","Extremely"], ticks=(1, 2, 3, 4, 5), granularity=1.0,
    style='rating', styleTweaks=(), opacity=None,
    color='white', fillColor='darkgreen', borderColor='white', colorSpace='rgb',
    font='arial', labelHeight=0.02,
    flip=False, depth=-3, readOnly=False)
distressed_slider = visual.Slider(win=win, name='distressed_slider',
    startValue=None, size=(1.0, 0.03), pos=(0, -0.03), units=None,
    labels=["Very slightly or not at all","A little","Moderately","Quite a bit","Extremely"], ticks=(1, 2, 3, 4, 5), granularity=1.0,
    style='rating', styleTweaks=(), opacity=None,
    color='white', fillColor='darkgreen', borderColor='white', colorSpace='rgb',
    font='arial', labelHeight=0.02,
    flip=False, depth=-4, readOnly=False)
excited_slider = visual.Slider(win=win, name='excited_slider',
    startValue=None, size=(1.0, 0.03), pos=(0, -0.21), units=None,
    labels=["Very slightly or not at all","A little","Moderately","Quite a bit","Extremely"], ticks=(1, 2, 3, 4, 5), granularity=1.0,
    style='rating', styleTweaks=(), opacity=None,
    color='white', fillColor='darkgreen', borderColor='white', colorSpace='rgb',
    font='arial', labelHeight=0.02,
    flip=False, depth=-5, readOnly=False)
interested = visual.TextStim(win=win, name='interested',
    text='Interested',
    font='Arial',
    pos=(0, 0.2), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);
distressed = visual.TextStim(win=win, name='distressed',
    text='Distressed',
    font='Arial',
    pos=(0, 0.02), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-7.0);
excited = visual.TextStim(win=win, name='excited',
    text='Excited',
    font='Arial',
    pos=(0, -0.16), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-8.0);
next_q1 = keyboard.Keyboard()
header1.bold = 'True'
instructions1.bold= 'True'
interested.bold = 'True'
distressed.bold = 'True'
excited.bold = 'True'

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "post_q1"-------
continueRoutine = True
# update component parameters for each repeat
header1.setText('Please answer the following questions about your experiences during the virtual party game. ')
indicate.setText('Indicate the way you felt playing this game:\n')
interested_slider.reset()
distressed_slider.reset()
excited_slider.reset()
next_q1.keys = []
next_q1.rt = []
_next_q1_allKeys = []
# keep track of which components have finished
post_q1Components = [header1, indicate, instructions1, interested_slider, distressed_slider, excited_slider, interested, distressed, excited, next_q1]
for thisComponent in post_q1Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
post_q1Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "post_q1"-------
while continueRoutine:
    # get current time
    t = post_q1Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=post_q1Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *header1* updates
    if header1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        header1.frameNStart = frameN  # exact frame index
        header1.tStart = t  # local t and not account for scr refresh
        header1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(header1, 'tStartRefresh')  # time at next scr refresh
        header1.setAutoDraw(True)
    
    # *indicate* updates
    if indicate.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        indicate.frameNStart = frameN  # exact frame index
        indicate.tStart = t  # local t and not account for scr refresh
        indicate.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(indicate, 'tStartRefresh')  # time at next scr refresh
        indicate.setAutoDraw(True)
    
    # *instructions1* updates
    if instructions1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructions1.frameNStart = frameN  # exact frame index
        instructions1.tStart = t  # local t and not account for scr refresh
        instructions1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructions1, 'tStartRefresh')  # time at next scr refresh
        instructions1.setAutoDraw(True)
    
    # *interested_slider* updates
    if interested_slider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        interested_slider.frameNStart = frameN  # exact frame index
        interested_slider.tStart = t  # local t and not account for scr refresh
        interested_slider.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(interested_slider, 'tStartRefresh')  # time at next scr refresh
        interested_slider.setAutoDraw(True)
    
    # *distressed_slider* updates
    if distressed_slider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        distressed_slider.frameNStart = frameN  # exact frame index
        distressed_slider.tStart = t  # local t and not account for scr refresh
        distressed_slider.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(distressed_slider, 'tStartRefresh')  # time at next scr refresh
        distressed_slider.setAutoDraw(True)
    
    # *excited_slider* updates
    if excited_slider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        excited_slider.frameNStart = frameN  # exact frame index
        excited_slider.tStart = t  # local t and not account for scr refresh
        excited_slider.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(excited_slider, 'tStartRefresh')  # time at next scr refresh
        excited_slider.setAutoDraw(True)
    
    # *interested* updates
    if interested.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        interested.frameNStart = frameN  # exact frame index
        interested.tStart = t  # local t and not account for scr refresh
        interested.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(interested, 'tStartRefresh')  # time at next scr refresh
        interested.setAutoDraw(True)
    
    # *distressed* updates
    if distressed.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        distressed.frameNStart = frameN  # exact frame index
        distressed.tStart = t  # local t and not account for scr refresh
        distressed.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(distressed, 'tStartRefresh')  # time at next scr refresh
        distressed.setAutoDraw(True)
    
    # *excited* updates
    if excited.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        excited.frameNStart = frameN  # exact frame index
        excited.tStart = t  # local t and not account for scr refresh
        excited.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(excited, 'tStartRefresh')  # time at next scr refresh
        excited.setAutoDraw(True)
    
    # *next_q1* updates
    waitOnFlip = False
    if next_q1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        next_q1.frameNStart = frameN  # exact frame index
        next_q1.tStart = t  # local t and not account for scr refresh
        next_q1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(next_q1, 'tStartRefresh')  # time at next scr refresh
        next_q1.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(next_q1.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(next_q1.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if next_q1.status == STARTED and not waitOnFlip:
        theseKeys = next_q1.getKeys(keyList=['space'], waitRelease=False)
        _next_q1_allKeys.extend(theseKeys)
        if len(_next_q1_allKeys):
            next_q1.keys = _next_q1_allKeys[-1].name  # just the last key pressed
            next_q1.rt = _next_q1_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in post_q1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "post_q1"-------
for thisComponent in post_q1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('header1.started', header1.tStartRefresh)
thisExp.addData('header1.stopped', header1.tStopRefresh)
thisExp.addData('indicate.started', indicate.tStartRefresh)
thisExp.addData('indicate.stopped', indicate.tStopRefresh)
thisExp.addData('instructions1.started', instructions1.tStartRefresh)
thisExp.addData('instructions1.stopped', instructions1.tStopRefresh)
thisExp.addData('interested_slider.response', interested_slider.getRating())
thisExp.addData('interested_slider.rt', interested_slider.getRT())
thisExp.addData('interested_slider.started', interested_slider.tStartRefresh)
thisExp.addData('interested_slider.stopped', interested_slider.tStopRefresh)
thisExp.addData('distressed_slider.response', distressed_slider.getRating())
thisExp.addData('distressed_slider.rt', distressed_slider.getRT())
thisExp.addData('distressed_slider.started', distressed_slider.tStartRefresh)
thisExp.addData('distressed_slider.stopped', distressed_slider.tStopRefresh)
thisExp.addData('excited_slider.response', excited_slider.getRating())
thisExp.addData('excited_slider.rt', excited_slider.getRT())
thisExp.addData('excited_slider.started', excited_slider.tStartRefresh)
thisExp.addData('excited_slider.stopped', excited_slider.tStopRefresh)
thisExp.addData('interested.started', interested.tStartRefresh)
thisExp.addData('interested.stopped', interested.tStopRefresh)
thisExp.addData('distressed.started', distressed.tStartRefresh)
thisExp.addData('distressed.stopped', distressed.tStopRefresh)
thisExp.addData('excited.started', excited.tStartRefresh)
thisExp.addData('excited.stopped', excited.tStopRefresh)
# check responses
if next_q1.keys in ['', [], None]:  # No response was made
    next_q1.keys = None
thisExp.addData('next_q1.keys',next_q1.keys)
if next_q1.keys != None:  # we had a response
    thisExp.addData('next_q1.rt', next_q1.rt)
thisExp.addData('next_q1.started', next_q1.tStartRefresh)
thisExp.addData('next_q1.stopped', next_q1.tStopRefresh)
thisExp.nextEntry()
# the Routine "post_q1" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
