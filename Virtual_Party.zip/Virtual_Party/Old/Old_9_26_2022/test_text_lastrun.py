﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2021.2.3),
    on August 18, 2022, at 15:39
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2021.2.3'
expName = 'test_text'  # from the Builder filename that created this script
expInfo = {'participant': '', 'session': '001'}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\tuanh\\OneDrive - Vanderbilt\\Desktop\\Reprogrammed IG\\test_text_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=(1024, 768), fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Setup eyetracking
ioDevice = ioConfig = ioSession = ioServer = eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "comment_final"
comment_finalClock = core.Clock()
image_party2 = visual.ImageStim(
    win=win,
    name='image_party2', 
    image='images/background_party.jpg', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
border_33 = visual.Rect(
    win=win, name='border_33',
    width=(2, 1.5)[0], height=(2, 1.5)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=0.9, depth=-1.0, interpolate=True)
caption = visual.TextStim(win=win, name='caption',
    text='See the chats below!',
    font='Arial',
    pos=(0, 0.3), height=0.07, wrapWidth=100.0, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
text_26 = visual.TextStim(win=win, name='text_26',
    text='',
    font='Arial',
    units='pix', pos=[0,0], height=50.0, wrapWidth=1000.0, ori=1.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);

# Initialize components for Routine "trial"
trialClock = core.Clock()

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "comment_final"-------
continueRoutine = True
routineTimer.add(20.000000)
# update component parameters for each repeat
text_26.alignText = 'Left'
caption.bold = 'True'
text_26.bold = 'True'
# keep track of which components have finished
comment_finalComponents = [image_party2, border_33, caption, text_26]
for thisComponent in comment_finalComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
comment_finalClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "comment_final"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = comment_finalClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=comment_finalClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_party2* updates
    if image_party2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_party2.frameNStart = frameN  # exact frame index
        image_party2.tStart = t  # local t and not account for scr refresh
        image_party2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_party2, 'tStartRefresh')  # time at next scr refresh
        image_party2.setAutoDraw(True)
    if image_party2.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_party2.tStartRefresh + 20-frameTolerance:
            # keep track of stop time/frame for later
            image_party2.tStop = t  # not accounting for scr refresh
            image_party2.frameNStop = frameN  # exact frame index
            win.timeOnFlip(image_party2, 'tStopRefresh')  # time at next scr refresh
            image_party2.setAutoDraw(False)
    
    # *border_33* updates
    if border_33.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        border_33.frameNStart = frameN  # exact frame index
        border_33.tStart = t  # local t and not account for scr refresh
        border_33.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(border_33, 'tStartRefresh')  # time at next scr refresh
        border_33.setAutoDraw(True)
    if border_33.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > border_33.tStartRefresh + 20-frameTolerance:
            # keep track of stop time/frame for later
            border_33.tStop = t  # not accounting for scr refresh
            border_33.frameNStop = frameN  # exact frame index
            win.timeOnFlip(border_33, 'tStopRefresh')  # time at next scr refresh
            border_33.setAutoDraw(False)
    
    # *caption* updates
    if caption.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        caption.frameNStart = frameN  # exact frame index
        caption.tStart = t  # local t and not account for scr refresh
        caption.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(caption, 'tStartRefresh')  # time at next scr refresh
        caption.setAutoDraw(True)
    if caption.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > caption.tStartRefresh + 20-frameTolerance:
            # keep track of stop time/frame for later
            caption.tStop = t  # not accounting for scr refresh
            caption.frameNStop = frameN  # exact frame index
            win.timeOnFlip(caption, 'tStopRefresh')  # time at next scr refresh
            caption.setAutoDraw(False)
    
    # *text_26* updates
    if text_26.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_26.frameNStart = frameN  # exact frame index
        text_26.tStart = t  # local t and not account for scr refresh
        text_26.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_26, 'tStartRefresh')  # time at next scr refresh
        text_26.setAutoDraw(True)
    if text_26.status == STARTED:
        # is it time to stop? (based on local clock)
        if tThisFlip > 30-frameTolerance:
            # keep track of stop time/frame for later
            text_26.tStop = t  # not accounting for scr refresh
            text_26.frameNStop = frameN  # exact frame index
            win.timeOnFlip(text_26, 'tStopRefresh')  # time at next scr refresh
            text_26.setAutoDraw(False)
    if text_26.status == STARTED:  # only update if drawing
        text_26.setPos([100, 5-frameN], log=False)
        text_26.setOri(0.0, log=False)
        text_26.setText('Anh' + ': ' + 'Yay'+'\n' + 'Dan' + ': ' + 'We did it, team!'+'\n' + 'Cam' + ': ' + 'I want those nachos'+'\n' + 'Hannah' + ': ' + 'Is this for real???'+'\n' + 'Ruby' + ': ' + 'Yay'+'\n' + 'Anh' + ': ' + 'A lot of emotions right now'
, log=False)
        text_26.setFlip('None', log=False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in comment_finalComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "comment_final"-------
for thisComponent in comment_finalComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image_party2.started', image_party2.tStartRefresh)
thisExp.addData('image_party2.stopped', image_party2.tStopRefresh)
thisExp.addData('border_33.started', border_33.tStartRefresh)
thisExp.addData('border_33.stopped', border_33.tStopRefresh)
thisExp.addData('caption.started', caption.tStartRefresh)
thisExp.addData('caption.stopped', caption.tStopRefresh)
thisExp.addData('text_26.started', text_26.tStartRefresh)
thisExp.addData('text_26.stopped', text_26.tStopRefresh)

# ------Prepare to start Routine "trial"-------
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
trialComponents = []
for thisComponent in trialComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
trialClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "trial"-------
while continueRoutine:
    # get current time
    t = trialClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=trialClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in trialComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "trial"-------
for thisComponent in trialComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "trial" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
