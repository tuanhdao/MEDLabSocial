﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2021.2.3),
    on October 06, 2022, at 16:38
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2021.2.3'
expName = 'tets'  # from the Builder filename that created this script
expInfo = {'participant': '', 'session': '001'}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\tuanh\\Dropbox\\Reprogrammed IG\\tets_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=(1024, 768), fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Setup eyetracking
ioDevice = ioConfig = ioSession = ioServer = eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "postq_8"
postq_8Clock = core.Clock()
header8 = visual.TextStim(win=win, name='header8',
    text='',
    font='Arial',
    pos=(0, 0.43), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
indicate_8 = visual.TextStim(win=win, name='indicate_8',
    text='',
    font='Arial',
    pos=(0, 0.32), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
instructions8 = visual.TextStim(win=win, name='instructions8',
    text='Use the mouse to pick the options that represent how you feel, then press space to submit.',
    font='Arial',
    pos=(0, -0.4), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
believe_slider_1 = visual.Slider(win=win, name='believe_slider_1',
    startValue=None, size=(1.0, 0.03), pos=(0, 0.15), units=None,
    labels=["Very slightly or not at all","A little","Moderately","Quite a bit","Extremely"], ticks=(1, 2, 3, 4, 5), granularity=1.0,
    style='rating', styleTweaks=(), opacity=None,
    color='white', fillColor='white', borderColor='white', colorSpace='rgb',
    font='Arial', labelHeight=0.02,
    flip=False, depth=-3, readOnly=False)
believe_slider_2 = visual.Slider(win=win, name='believe_slider_2',
    startValue=None, size=(1.0, 0.03), pos=(0, -0.03), units=None,
    labels=["Very slightly or not at all","A little","Moderately","Quite a bit","Extremely"], ticks=(1, 2, 3, 4, 5), granularity=1.0,
    style='rating', styleTweaks=(), opacity=None,
    color='white', fillColor='white', borderColor='white', colorSpace='rgb',
    font='Arial', labelHeight=0.02,
    flip=False, depth=-4, readOnly=False)
believe_1 = visual.TextStim(win=win, name='believe_1',
    text='I believed I was interacting with other teens/young adults.',
    font='Arial',
    pos=(0, 0.21), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-5.0);
believe_2 = visual.TextStim(win=win, name='believe_2',
    text='I thought the other players were real people my age.',
    font='Arial',
    pos=(0, 0.021), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);
next_8 = keyboard.Keyboard()
header8.bold = 'True'
instructions8.bold= 'True'
believe_1.bold = 'True'
believe_2.bold = 'True'


# Initialize components for Routine "trial"
trialClock = core.Clock()

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "postq_8"-------
continueRoutine = True
# update component parameters for each repeat
header8.setText('Please answer the following questions about your experiences during the virtual party game. ')
indicate_8.setText('Indicate the way you felt playing this game:\n')
believe_slider_1.reset()
believe_slider_2.reset()
next_8.keys = []
next_8.rt = []
_next_8_allKeys = []
# keep track of which components have finished
postq_8Components = [header8, indicate_8, instructions8, believe_slider_1, believe_slider_2, believe_1, believe_2, next_8]
for thisComponent in postq_8Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
postq_8Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "postq_8"-------
while continueRoutine:
    # get current time
    t = postq_8Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=postq_8Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *header8* updates
    if header8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        header8.frameNStart = frameN  # exact frame index
        header8.tStart = t  # local t and not account for scr refresh
        header8.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(header8, 'tStartRefresh')  # time at next scr refresh
        header8.setAutoDraw(True)
    
    # *indicate_8* updates
    if indicate_8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        indicate_8.frameNStart = frameN  # exact frame index
        indicate_8.tStart = t  # local t and not account for scr refresh
        indicate_8.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(indicate_8, 'tStartRefresh')  # time at next scr refresh
        indicate_8.setAutoDraw(True)
    
    # *instructions8* updates
    if instructions8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructions8.frameNStart = frameN  # exact frame index
        instructions8.tStart = t  # local t and not account for scr refresh
        instructions8.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructions8, 'tStartRefresh')  # time at next scr refresh
        instructions8.setAutoDraw(True)
    
    # *believe_slider_1* updates
    if believe_slider_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        believe_slider_1.frameNStart = frameN  # exact frame index
        believe_slider_1.tStart = t  # local t and not account for scr refresh
        believe_slider_1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(believe_slider_1, 'tStartRefresh')  # time at next scr refresh
        believe_slider_1.setAutoDraw(True)
    
    # *believe_slider_2* updates
    if believe_slider_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        believe_slider_2.frameNStart = frameN  # exact frame index
        believe_slider_2.tStart = t  # local t and not account for scr refresh
        believe_slider_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(believe_slider_2, 'tStartRefresh')  # time at next scr refresh
        believe_slider_2.setAutoDraw(True)
    
    # *believe_1* updates
    if believe_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        believe_1.frameNStart = frameN  # exact frame index
        believe_1.tStart = t  # local t and not account for scr refresh
        believe_1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(believe_1, 'tStartRefresh')  # time at next scr refresh
        believe_1.setAutoDraw(True)
    
    # *believe_2* updates
    if believe_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        believe_2.frameNStart = frameN  # exact frame index
        believe_2.tStart = t  # local t and not account for scr refresh
        believe_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(believe_2, 'tStartRefresh')  # time at next scr refresh
        believe_2.setAutoDraw(True)
    
    # *next_8* updates
    waitOnFlip = False
    if next_8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        next_8.frameNStart = frameN  # exact frame index
        next_8.tStart = t  # local t and not account for scr refresh
        next_8.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(next_8, 'tStartRefresh')  # time at next scr refresh
        next_8.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(next_8.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(next_8.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if next_8.status == STARTED and not waitOnFlip:
        theseKeys = next_8.getKeys(keyList=['space'], waitRelease=False)
        _next_8_allKeys.extend(theseKeys)
        if len(_next_8_allKeys):
            next_8.keys = _next_8_allKeys[-1].name  # just the last key pressed
            next_8.rt = _next_8_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in postq_8Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "postq_8"-------
for thisComponent in postq_8Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('header8.started', header8.tStartRefresh)
thisExp.addData('header8.stopped', header8.tStopRefresh)
thisExp.addData('indicate_8.started', indicate_8.tStartRefresh)
thisExp.addData('indicate_8.stopped', indicate_8.tStopRefresh)
thisExp.addData('instructions8.started', instructions8.tStartRefresh)
thisExp.addData('instructions8.stopped', instructions8.tStopRefresh)
thisExp.addData('believe_slider_1.response', believe_slider_1.getRating())
thisExp.addData('believe_slider_1.rt', believe_slider_1.getRT())
thisExp.addData('believe_slider_1.started', believe_slider_1.tStartRefresh)
thisExp.addData('believe_slider_1.stopped', believe_slider_1.tStopRefresh)
thisExp.addData('believe_slider_2.response', believe_slider_2.getRating())
thisExp.addData('believe_slider_2.rt', believe_slider_2.getRT())
thisExp.addData('believe_slider_2.started', believe_slider_2.tStartRefresh)
thisExp.addData('believe_slider_2.stopped', believe_slider_2.tStopRefresh)
thisExp.addData('believe_1.started', believe_1.tStartRefresh)
thisExp.addData('believe_1.stopped', believe_1.tStopRefresh)
thisExp.addData('believe_2.started', believe_2.tStartRefresh)
thisExp.addData('believe_2.stopped', believe_2.tStopRefresh)
# check responses
if next_8.keys in ['', [], None]:  # No response was made
    next_8.keys = None
thisExp.addData('next_8.keys',next_8.keys)
if next_8.keys != None:  # we had a response
    thisExp.addData('next_8.rt', next_8.rt)
thisExp.addData('next_8.started', next_8.tStartRefresh)
thisExp.addData('next_8.stopped', next_8.tStopRefresh)
thisExp.nextEntry()
# the Routine "postq_8" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "trial"-------
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
trialComponents = []
for thisComponent in trialComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
trialClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "trial"-------
while continueRoutine:
    # get current time
    t = trialClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=trialClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in trialComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "trial"-------
for thisComponent in trialComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "trial" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
