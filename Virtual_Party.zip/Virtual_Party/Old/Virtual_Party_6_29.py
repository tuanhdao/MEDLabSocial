﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2021.2.3),
    on July 07, 2022, at 14:30
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2021.2.3'
expName = 'Test_helen'  # from the Builder filename that created this script
expInfo = {'participant': ''}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\tuanh\\OneDrive - Vanderbilt\\Desktop\\Reprogrammed IG\\Virtual_Party_6_29.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=[1536, 864], fullscr=False, screen=0, 
    winType='pyglet', allowGUI=True, allowStencil=False,
    monitor='testMonitor', color='black', colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Setup eyetracking
ioDevice = ioConfig = ioSession = ioServer = eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "Welcome"
WelcomeClock = core.Clock()
background_image1 = visual.ImageStim(
    win=win,
    name='background_image1', 
    image='images/welcome.jpeg', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=1.0,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
background_polygon = visual.Rect(
    win=win, name='background_polygon',
    width=(1, 0.25)[0], height=(1, 0.25)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor=None, fillColor='white',
    opacity=0.9, depth=-1.0, interpolate=True)
Welcome_text = visual.TextStim(win=win, name='Welcome_text',
    text='Welcome!',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "Introduction_1"
Introduction_1Clock = core.Clock()
image = visual.ImageStim(
    win=win,
    name='image', 
    image='images/background_gen.jpeg', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
polygon_2 = visual.Rect(
    win=win, name='polygon_2',
    width=(1.5, 0.75)[0], height=(1.5, 0.75)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=0.8, depth=-1.0, interpolate=True)
text = visual.TextStim(win=win, name='text',
    text='',
    font='Arial',
    pos=(0, 0), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
key_resp = keyboard.Keyboard()
trialList=data.importConditions('Trials.xlsx')
next_intro1 = visual.TextStim(win=win, name='next_intro1',
    text='Press space to continue.',
    font='Arial',
    pos=(0, -0.30), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-10.0);

# Initialize components for Routine "Introduction_2"
Introduction_2Clock = core.Clock()
image_2 = visual.ImageStim(
    win=win,
    name='image_2', 
    image='images/background_gen.jpeg', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
polygon_3 = visual.Rect(
    win=win, name='polygon_3',
    width=(1.5, 0.75)[0], height=(1.5, 0.75)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=0.8, depth=-1.0, interpolate=True)
key_resp_2 = keyboard.Keyboard()
text_2 = visual.TextStim(win=win, name='text_2',
    text='The game includes 5 rounds where you will learn more and more about the other people playing the game. At the end, there will be a virtual party for the most-liked players. Players who get enough likes across the game \nwill be invited to the party, but people who are less liked will not be included.  First, let’s set up your profile so that the other players can learn about you...\n\n',
    font='Arial',
    pos=(0, 0), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);
next_intro2 = visual.TextStim(win=win, name='next_intro2',
    text='Press space to continue.',
    font='Arial',
    pos=(0, -0.30), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-10.0);

# Initialize components for Routine "Participant_name"
Participant_nameClock = core.Clock()
name_question = visual.TextStim(win=win, name='name_question',
    text='What is your name?',
    font='Arial',
    pos=(0, 0.2), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
name_enter = visual.TextBox2(
     win, text=None, font='Arial',
     pos=(0, 0),     letterHeight=0.05,
     size=(None, None), borderWidth=2.0,
     color='white', colorSpace='rgb',
     opacity=1.0,
     bold=False, italic=False,
     lineSpacing=1.0,
     padding=0.0,
     anchor='center',
     fillColor=None, borderColor=None,
     flipHoriz=False, flipVert=False,
     editable=True,
     name='name_enter',
     autoLog=True,
)
button1 = visual.Rect(
    win=win, name='button1',
    width=(0.5, 0.1)[0], height=(0.5, 0.1)[1],
    ori=0.0, pos=(0, -0.2),
    lineWidth=1.0,     colorSpace='rgb',  lineColor=None, fillColor='white',
    opacity=None, depth=-2.0, interpolate=True)
submit1 = visual.TextStim(win=win, name='submit1',
    text='Click here to submit',
    font='Arial',
    pos=(0, -0.2), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);
mouse1 = event.Mouse(win=win)
x, y = [None, None]
mouse1.mouseClock = core.Clock()
# Set experiment start values for variable component ptp_name
ptp_name = name_enter.text
ptp_nameContainer = []

# Initialize components for Routine "Participant_age"
Participant_ageClock = core.Clock()
age_question = visual.TextStim(win=win, name='age_question',
    text='How old are you? ',
    font='Arial',
    pos=(0, 0.2), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
age_enter = visual.TextBox2(
     win, text=None, font='Arial',
     pos=(0, 0),     letterHeight=0.05,
     size=(None, None), borderWidth=2.0,
     color='white', colorSpace='rgb',
     opacity=None,
     bold=False, italic=False,
     lineSpacing=1.0,
     padding=0.0,
     anchor='center',
     fillColor=None, borderColor=None,
     flipHoriz=False, flipVert=False,
     editable=True,
     name='age_enter',
     autoLog=True,
)
mouse2 = event.Mouse(win=win)
x, y = [None, None]
mouse2.mouseClock = core.Clock()
button2 = visual.Rect(
    win=win, name='button2',
    width=(0.5, 0.1)[0], height=(0.5, 0.1)[1],
    ori=0.0, pos=(0, -0.2),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-3.0, interpolate=True)
submit2 = visual.TextStim(win=win, name='submit2',
    text='Click here to submit',
    font='Arial',
    pos=(0, -0.2), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
reminder = visual.TextStim(win=win, name='reminder',
    text='Please only enter a number.',
    font='Arial',
    pos=(0, 0.1), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-5.0);
# Set experiment start values for variable component ptp_age
ptp_age = age_enter.text
ptp_ageContainer = []

# Initialize components for Routine "Participant_hometown"
Participant_hometownClock = core.Clock()
hometown_question = visual.TextStim(win=win, name='hometown_question',
    text='What is your hometown?',
    font='Arial',
    pos=(0, 0.2), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
hometown_enter = visual.TextBox2(
     win, text=None, font='Arial',
     pos=(0, 0),     letterHeight=0.05,
     size=(None, None), borderWidth=2.0,
     color='white', colorSpace='rgb',
     opacity=None,
     bold=False, italic=False,
     lineSpacing=1.0,
     padding=0.0,
     anchor='center',
     fillColor=None, borderColor=None,
     flipHoriz=False, flipVert=False,
     editable=True,
     name='hometown_enter',
     autoLog=True,
)
mouse3 = event.Mouse(win=win)
x, y = [None, None]
mouse3.mouseClock = core.Clock()
button3 = visual.Rect(
    win=win, name='button3',
    width=(0.5, 0.1)[0], height=(0.5, 0.1)[1],
    ori=0.0, pos=(0, -0.2),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-3.0, interpolate=True)
submit3 = visual.TextStim(win=win, name='submit3',
    text='Click here to submit',
    font='Arial',
    pos=(0, -0.2), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
# Set experiment start values for variable component ptp_hometown
ptp_hometown = hometown_enter.text
ptp_hometownContainer = []

# Initialize components for Routine "Participant_interest"
Participant_interestClock = core.Clock()
interest_question = visual.TextStim(win=win, name='interest_question',
    text='What are some things you are interested in?',
    font='Arial',
    pos=(0, 0.2), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
interest_enter = visual.TextBox2(
     win, text=None, font='Arial',
     pos=(0, 0),     letterHeight=0.05,
     size=(None, None), borderWidth=2.0,
     color='white', colorSpace='rgb',
     opacity=None,
     bold=False, italic=False,
     lineSpacing=1.0,
     padding=0.0,
     anchor='center',
     fillColor=None, borderColor=None,
     flipHoriz=False, flipVert=False,
     editable=True,
     name='interest_enter',
     autoLog=True,
)
mouse4 = event.Mouse(win=win)
x, y = [None, None]
mouse4.mouseClock = core.Clock()
button4 = visual.Rect(
    win=win, name='button4',
    width=(0.5, 0.1)[0], height=(0.5, 0.1)[1],
    ori=0.0, pos=(0, -0.2),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-3.0, interpolate=True)
submit4 = visual.TextStim(win=win, name='submit4',
    text='Click here to submit',
    font='Arial',
    pos=(0, -0.2), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
# Set experiment start values for variable component ptp_interest
ptp_interest = interest_enter.text
ptp_interestContainer = []

# Initialize components for Routine "Participant_profile"
Participant_profileClock = core.Clock()
image_4 = visual.ImageStim(
    win=win,
    name='image_4', 
    image='images/background_profiles.jpeg', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
border4 = visual.Rect(
    win=win, name='border4',
    width=(1.5, 0.75)[0], height=(1.5, 0.75)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=0.9, depth=-1.0, interpolate=True)
border = visual.Rect(
    win=win, name='border',
    width=(0.22, 0.32)[0], height=(0.22, 0.32)[1],
    ori=0.0, pos=(-0.5, 0.15),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='black',
    opacity=None, depth=-2.0, interpolate=True)
subject_image = visual.ImageStim(
    win=win,
    name='subject_image', 
    image='sin', mask=None,
    ori=0.0, pos=(-0.5, 0.15), size=(0.2, 0.3),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-3.0)
part_response = visual.TextStim(win=win, name='part_response',
    text='',
    font='Open Sans',
    pos=(0.1, -0.15), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
part_prompts = visual.TextStim(win=win, name='part_prompts',
    text='Age:\nHometown:\nInterests:',
    font='Arial',
    pos=(-0.11, -0.15), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);
part_name = visual.TextStim(win=win, name='part_name',
    text='',
    font='Arial',
    pos=(-0.11, -0.06), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-7.0);
next = keyboard.Keyboard()
next_text = visual.TextStim(win=win, name='next_text',
    text='Press space to continue.',
    font='Arial',
    pos=(0, -0.30), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-9.0);

# Initialize components for Routine "Waiting"
WaitingClock = core.Clock()
image_8 = visual.ImageStim(
    win=win,
    name='image_8', 
    image='images/background_gen.jpeg', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
polygon_6 = visual.Rect(
    win=win, name='polygon_6',
    width=(1.5, 0.75)[0], height=(1.5, 0.75)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=0.8, depth=-1.0, interpolate=True)
text_6 = visual.TextStim(win=win, name='text_6',
    text='',
    font='Arial',
    pos=(0, 0.1), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
key_resp_6 = keyboard.Keyboard()
image_9 = visual.ImageStim(
    win=win,
    name='image_9', 
    image='images/load-icon-png-7945.png', mask=None,
    ori=0.0, pos=(0, -0.05), size=(0.25, 0.25),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-4.0)

# Initialize components for Routine "Introduction_3"
Introduction_3Clock = core.Clock()
image_3 = visual.ImageStim(
    win=win,
    name='image_3', 
    image='images/background_gen.jpeg', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
polygon = visual.Rect(
    win=win, name='polygon',
    width=(1.5, 0.75)[0], height=(1.5, 0.75)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=0.8, depth=-1.0, interpolate=True)
text_3 = visual.TextStim(win=win, name='text_3',
    text='',
    font='Arial',
    pos=(0, 0), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
key_resp_3 = keyboard.Keyboard()
next_intro3 = visual.TextStim(win=win, name='next_intro3',
    text='Press space to continue.',
    font='Arial',
    pos=(0, -0.30), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-10.0);

# Initialize components for Routine "Coplayer_profile_loader"
Coplayer_profile_loaderClock = core.Clock()
# empty lists to hold stimuli
names = []
ages = []
hometowns = []
interests = []
photos = []
votes = []


# Initialize components for Routine "Coplayer_profile_shuffler"
Coplayer_profile_shufflerClock = core.Clock()

# Initialize components for Routine "Coplayer_profiles"
Coplayer_profilesClock = core.Clock()
image_5 = visual.ImageStim(
    win=win,
    name='image_5', 
    image='sin', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
border4_2 = visual.Rect(
    win=win, name='border4_2',
    width=(1.5, 0.75)[0], height=(1.5, 0.75)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=0.9, depth=-1.0, interpolate=True)
border_3 = visual.Rect(
    win=win, name='border_3',
    width=(0.22, 0.32)[0], height=(0.22, 0.32)[1],
    ori=0.0, pos=(-0.5, 0.15),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='black',
    opacity=None, depth=-2.0, interpolate=True)
cop_age_st = str()

curr_item = -1
cop_img = visual.ImageStim(
    win=win,
    name='cop_img', 
    image='sin', mask=None,
    ori=0.0, pos=(-0.5, 0.15), size=(0.2, 0.3),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-4.0)
cop_resp_show = visual.TextStim(win=win, name='cop_resp_show',
    text='',
    font='Open Sans',
    pos=(0.1, -0.15), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-5.0);
cop_prompts_show = visual.TextStim(win=win, name='cop_prompts_show',
    text='',
    font='Arial',
    pos=(-0.11, -0.15), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);
cop_vote_show = visual.TextStim(win=win, name='cop_vote_show',
    text='',
    font='Open Sans',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='0.0000, 0.0000, 0.0000', colorSpace='rgb', opacity=0.0, 
    languageStyle='LTR',
    depth=-7.0);
cop_name_show = visual.TextStim(win=win, name='cop_name_show',
    text='',
    font='Arial',
    pos=(-0.11, -0.06), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-8.0);
next_2 = keyboard.Keyboard()
next_text_2 = visual.TextStim(win=win, name='next_text_2',
    text='Press space to continue.',
    font='Arial',
    pos=(0, -0.30), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-10.0);

# Initialize components for Routine "Vote_store"
Vote_storeClock = core.Clock()

# Initialize components for Routine "Introduction_4"
Introduction_4Clock = core.Clock()
image_6 = visual.ImageStim(
    win=win,
    name='image_6', 
    image='images/background_gen.jpeg', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
polygon_4 = visual.Rect(
    win=win, name='polygon_4',
    width=(1.5, 0.75)[0], height=(1.5, 0.75)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=0.8, depth=-1.0, interpolate=True)
text_4 = visual.TextStim(win=win, name='text_4',
    text='',
    font='Arial',
    pos=(0, 0), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
key_resp_4 = keyboard.Keyboard()
next_intro4 = visual.TextStim(win=win, name='next_intro4',
    text='Press space to continue.',
    font='Arial',
    pos=(0, -0.30), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-10.0);

# Initialize components for Routine "Introduction_5"
Introduction_5Clock = core.Clock()
image_7 = visual.ImageStim(
    win=win,
    name='image_7', 
    image='images/background_gen.jpeg', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
polygon_5 = visual.Rect(
    win=win, name='polygon_5',
    width=(1.5, 0.75)[0], height=(1.5, 0.75)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=0.8, depth=-1.0, interpolate=True)
text_5 = visual.TextStim(win=win, name='text_5',
    text='',
    font='Arial',
    pos=(0, 0.2), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
key_resp_5 = keyboard.Keyboard()
thumbs_up = visual.ImageStim(
    win=win,
    name='thumbs_up', 
    image='images/thumbs-up.png', mask=None,
    ori=0.0, pos=(-0.3, 0.0), size=(0.2, 0.25),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-4.0)
thumbs_down = visual.ImageStim(
    win=win,
    name='thumbs_down', 
    image='images/thumbs-down.png', mask=None,
    ori=0.0, pos=(0.3, 0.0), size=(0.20, 0.25),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-5.0)
feedback_like = visual.TextStim(win=win, name='feedback_like',
    text='Great news!\nThis means the person liked you.',
    font='Arial',
    pos=(-.29, -0.2), height=0.03, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);
feedback_dislike = visual.TextStim(win=win, name='feedback_dislike',
    text='Oh no!\nThis means the person disliked you.',
    font='Open Sans',
    pos=(.29, -0.2), height=0.03, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-7.0);
next_3 = visual.TextStim(win=win, name='next_3',
    text='Press space to continue. ',
    font='Arial',
    pos=(0, -0.30), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-8.0);

# Initialize components for Routine "Introduction_6"
Introduction_6Clock = core.Clock()
image_13 = visual.ImageStim(
    win=win,
    name='image_13', 
    image='images/background_gen.jpeg', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
polygon_10 = visual.Rect(
    win=win, name='polygon_10',
    width=(1.5, 0.75)[0], height=(1.5, 0.75)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=0.8, depth=-1.0, interpolate=True)
text_10 = visual.TextStim(win=win, name='text_10',
    text='',
    font='Arial',
    pos=(0, 0), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
key_resp_10 = keyboard.Keyboard()
next_intro6 = visual.TextStim(win=win, name='next_intro6',
    text='Press space to continue.',
    font='Arial',
    pos=(0, -0.30), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-10.0);

# Initialize components for Routine "Practice_1a"
Practice_1aClock = core.Clock()
border_5 = visual.Rect(
    win=win, name='border_5',
    width=(0.21, 0.31)[0], height=(0.21, 0.31)[1],
    ori=0.0, pos=(-0.4, 0.2),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=0.0, interpolate=True)
prac_image_2 = visual.ImageStim(
    win=win,
    name='prac_image_2', 
    image='sin', mask=None,
    ori=0.0, pos=(-0.4, 0.2), size=(0.2, 0.3),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)
like_button_2 = visual.Rect(
    win=win, name='like_button_2',
    width=(0.21, 0.07)[0], height=(0.21, 0.07)[1],
    ori=0.0, pos=(-0.4, -0.3),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-2.0, interpolate=True)
like_text_2 = visual.TextStim(win=win, name='like_text_2',
    text='Like ',
    font='Arial',
    pos=(-0.4, -0.3), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);
like_click_2 = event.Mouse(win=win)
x, y = [None, None]
like_click_2.mouseClock = core.Clock()
dislike_button_2 = visual.Rect(
    win=win, name='dislike_button_2',
    width=(0.21, 0.07)[0], height=(0.21, 0.07)[1],
    ori=0.0, pos=(0.39, -0.3),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-5.0, interpolate=True)
dislike_text_2 = visual.TextStim(win=win, name='dislike_text_2',
    text='Dislike ',
    font='Arial',
    pos=(0.4, -0.3), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);
Dislike_click_2 = event.Mouse(win=win)
x, y = [None, None]
Dislike_click_2.mouseClock = core.Clock()
player1_2 = visual.TextStim(win=win, name='player1_2',
    text='',
    font='Arial',
    pos=(-0.2, 0.34), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-8.0);
vote_question_2 = visual.TextStim(win=win, name='vote_question_2',
    text='Do you like or dislike Player 1? ',
    font='Open Sans',
    pos=(0, -.20), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-10.0);

# Initialize components for Routine "Practice_1b"
Practice_1bClock = core.Clock()
wait = visual.TextStim(win=win, name='wait',
    text='+',
    font='Open Sans',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "Practice_1c"
Practice_1cClock = core.Clock()
like_prac = visual.ImageStim(
    win=win,
    name='like_prac', 
    image='images/thumbs-up.png', mask=None,
    ori=0.0, pos=(0, 0), size=(0.2, 0.25),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)

# Initialize components for Routine "Practice_1d"
Practice_1dClock = core.Clock()
wait_2 = visual.TextStim(win=win, name='wait_2',
    text='+',
    font='Open Sans',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "Practice_2a"
Practice_2aClock = core.Clock()
border_7 = visual.Rect(
    win=win, name='border_7',
    width=(0.21, 0.31)[0], height=(0.21, 0.31)[1],
    ori=0.0, pos=(-0.4, 0.2),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=0.0, interpolate=True)
prac_image_4 = visual.ImageStim(
    win=win,
    name='prac_image_4', 
    image='sin', mask=None,
    ori=0.0, pos=(-0.4, 0.2), size=(0.2, 0.3),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)
like_button = visual.Rect(
    win=win, name='like_button',
    width=(0.21, 0.07)[0], height=(0.21, 0.07)[1],
    ori=0.0, pos=(-0.4, -0.3),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-2.0, interpolate=True)
like_text = visual.TextStim(win=win, name='like_text',
    text='Like ',
    font='Arial',
    pos=(-0.4, -0.3), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);
like_click = event.Mouse(win=win)
x, y = [None, None]
like_click.mouseClock = core.Clock()
dislike_button = visual.Rect(
    win=win, name='dislike_button',
    width=(0.21, 0.07)[0], height=(0.21, 0.07)[1],
    ori=0.0, pos=(0.39, -0.3),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-5.0, interpolate=True)
dislike_text = visual.TextStim(win=win, name='dislike_text',
    text='Dislike ',
    font='Arial',
    pos=(0.4, -0.3), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);
Dislike_click = event.Mouse(win=win)
x, y = [None, None]
Dislike_click.mouseClock = core.Clock()
player2 = visual.TextStim(win=win, name='player2',
    text='',
    font='Arial',
    pos=(-0.2, 0.34), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-8.0);
vote_question = visual.TextStim(win=win, name='vote_question',
    text='Do you like or dislike Player 1? ',
    font='Open Sans',
    pos=(0, -.20), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-10.0);

# Initialize components for Routine "Practice_2b"
Practice_2bClock = core.Clock()
wait_3 = visual.TextStim(win=win, name='wait_3',
    text='+',
    font='Open Sans',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "Practice_2c"
Practice_2cClock = core.Clock()
dislike_prac = visual.ImageStim(
    win=win,
    name='dislike_prac', 
    image='images/thumbs-down.png', mask=None,
    ori=0.0, pos=(0, 0), size=(0.2, 0.25),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)

# Initialize components for Routine "Practice_2d"
Practice_2dClock = core.Clock()
wait_4 = visual.TextStim(win=win, name='wait_4',
    text='+',
    font='Open Sans',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "Introduction_7"
Introduction_7Clock = core.Clock()
image_12 = visual.ImageStim(
    win=win,
    name='image_12', 
    image='images/background_gen.jpeg', mask=None,
    ori=0.0, pos=(0, 0), size=(2, 1.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
polygon_9 = visual.Rect(
    win=win, name='polygon_9',
    width=(1.5, 0.75)[0], height=(1.5, 0.75)[1],
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=0.8, depth=-1.0, interpolate=True)
text_9 = visual.TextStim(win=win, name='text_9',
    text='',
    font='Arial',
    pos=(0, 0), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
key_resp_9 = keyboard.Keyboard()
next_intro7 = visual.TextStim(win=win, name='next_intro7',
    text='Press space to continue.',
    font='Arial',
    pos=(0, -0.30), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-10.0);

# Initialize components for Routine "Player_profiles_voting_style"
Player_profiles_voting_styleClock = core.Clock()
border_2 = visual.Rect(
    win=win, name='border_2',
    width=(0.21, 0.31)[0], height=(0.21, 0.31)[1],
    ori=0.0, pos=(-0.4, 0.2),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=0.0, interpolate=True)
cop_age_st = str()

# set i to -1
i = -1

coplayer_image_2 = visual.ImageStim(
    win=win,
    name='coplayer_image_2', 
    image='sin', mask=None,
    ori=0.0, pos=(-0.4, 0.2), size=(0.2, 0.3),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)
cop_prompts = visual.TextBox2(
     win, text='Name:\nAge:\nHometown:\nInterests:', font='Arial',
     pos=(-0.15, 0.29),     letterHeight=0.03,
     size=(None, None), borderWidth=2.0,
     color='white', colorSpace='rgb',
     opacity=None,
     bold=True, italic=False,
     lineSpacing=1.0,
     padding=0.0,
     anchor='center',
     fillColor=None, borderColor=None,
     flipHoriz=False, flipVert=False,
     editable=False,
     name='cop_prompts',
     autoLog=True,
)
cop_response = visual.TextStim(win=win, name='cop_response',
    text='',
    font='Open Sans',
    pos=(0.45, 0.29), height=0.03, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
like_button_3 = visual.Rect(
    win=win, name='like_button_3',
    width=(0.21, 0.07)[0], height=(0.21, 0.07)[1],
    ori=0.0, pos=(-0.4, -0.3),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-5.0, interpolate=True)
like_text_3 = visual.TextStim(win=win, name='like_text_3',
    text='Like ',
    font='Arial',
    pos=(-0.4, -0.3), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);
like_click_3 = event.Mouse(win=win)
x, y = [None, None]
like_click_3.mouseClock = core.Clock()
dislike_button_3 = visual.Rect(
    win=win, name='dislike_button_3',
    width=(0.21, 0.07)[0], height=(0.21, 0.07)[1],
    ori=0.0, pos=(0.39, -0.3),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-8.0, interpolate=True)
dislike_text_3 = visual.TextStim(win=win, name='dislike_text_3',
    text='Dislike ',
    font='Arial',
    pos=(0.4, -0.3), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-9.0);
vote_question_3 = visual.TextStim(win=win, name='vote_question_3',
    text='',
    font='Open Sans',
    pos=(0, -.20), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-10.0);
dislike_click_3 = event.Mouse(win=win)
x, y = [None, None]
dislike_click_3.mouseClock = core.Clock()

# Initialize components for Routine "Waiting_vote"
Waiting_voteClock = core.Clock()
wait_5 = visual.TextStim(win=win, name='wait_5',
    text='',
    font='Open Sans',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "Cop_vote"
Cop_voteClock = core.Clock()
vote_image = visual.ImageStim(
    win=win,
    name='vote_image', 
    image='sin', mask=None,
    ori=0.0, pos=(0, 0), size=(0.2, 0.25),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)

# Initialize components for Routine "Waiting_vote"
Waiting_voteClock = core.Clock()
wait_5 = visual.TextStim(win=win, name='wait_5',
    text='',
    font='Open Sans',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "Welcome"-------
continueRoutine = True
routineTimer.add(2.000000)
# update component parameters for each repeat
# keep track of which components have finished
WelcomeComponents = [background_image1, background_polygon, Welcome_text]
for thisComponent in WelcomeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
WelcomeClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Welcome"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = WelcomeClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=WelcomeClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *background_image1* updates
    if background_image1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        background_image1.frameNStart = frameN  # exact frame index
        background_image1.tStart = t  # local t and not account for scr refresh
        background_image1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(background_image1, 'tStartRefresh')  # time at next scr refresh
        background_image1.setAutoDraw(True)
    if background_image1.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > background_image1.tStartRefresh + 2.0-frameTolerance:
            # keep track of stop time/frame for later
            background_image1.tStop = t  # not accounting for scr refresh
            background_image1.frameNStop = frameN  # exact frame index
            win.timeOnFlip(background_image1, 'tStopRefresh')  # time at next scr refresh
            background_image1.setAutoDraw(False)
    
    # *background_polygon* updates
    if background_polygon.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        background_polygon.frameNStart = frameN  # exact frame index
        background_polygon.tStart = t  # local t and not account for scr refresh
        background_polygon.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(background_polygon, 'tStartRefresh')  # time at next scr refresh
        background_polygon.setAutoDraw(True)
    if background_polygon.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > background_polygon.tStartRefresh + 2.0-frameTolerance:
            # keep track of stop time/frame for later
            background_polygon.tStop = t  # not accounting for scr refresh
            background_polygon.frameNStop = frameN  # exact frame index
            win.timeOnFlip(background_polygon, 'tStopRefresh')  # time at next scr refresh
            background_polygon.setAutoDraw(False)
    
    # *Welcome_text* updates
    if Welcome_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        Welcome_text.frameNStart = frameN  # exact frame index
        Welcome_text.tStart = t  # local t and not account for scr refresh
        Welcome_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(Welcome_text, 'tStartRefresh')  # time at next scr refresh
        Welcome_text.setAutoDraw(True)
    if Welcome_text.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > Welcome_text.tStartRefresh + 2.0-frameTolerance:
            # keep track of stop time/frame for later
            Welcome_text.tStop = t  # not accounting for scr refresh
            Welcome_text.frameNStop = frameN  # exact frame index
            win.timeOnFlip(Welcome_text, 'tStopRefresh')  # time at next scr refresh
            Welcome_text.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in WelcomeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Welcome"-------
for thisComponent in WelcomeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('background_image1.started', background_image1.tStartRefresh)
thisExp.addData('background_image1.stopped', background_image1.tStopRefresh)
thisExp.addData('background_polygon.started', background_polygon.tStartRefresh)
thisExp.addData('background_polygon.stopped', background_polygon.tStopRefresh)
thisExp.addData('Welcome_text.started', Welcome_text.tStartRefresh)
thisExp.addData('Welcome_text.stopped', Welcome_text.tStopRefresh)

# ------Prepare to start Routine "Introduction_1"-------
continueRoutine = True
# update component parameters for each repeat
text.setText('For this game, you will be connecting to a research social media platform used for studies of how teens/young adults make decisions about their peers.  You will be playing a game with other teens/young adults participating in research studies where you get to know each other and make decisions about who you like and don’t like. You will also see how the other players voted for you. \n\n')
key_resp.keys = []
key_resp.rt = []
_key_resp_allKeys = []
next_intro1.bold = 'True'
# keep track of which components have finished
Introduction_1Components = [image, polygon_2, text, key_resp, next_intro1]
for thisComponent in Introduction_1Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Introduction_1Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Introduction_1"-------
while continueRoutine:
    # get current time
    t = Introduction_1Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Introduction_1Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image* updates
    if image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image.frameNStart = frameN  # exact frame index
        image.tStart = t  # local t and not account for scr refresh
        image.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image, 'tStartRefresh')  # time at next scr refresh
        image.setAutoDraw(True)
    
    # *polygon_2* updates
    if polygon_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        polygon_2.frameNStart = frameN  # exact frame index
        polygon_2.tStart = t  # local t and not account for scr refresh
        polygon_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(polygon_2, 'tStartRefresh')  # time at next scr refresh
        polygon_2.setAutoDraw(True)
    
    # *text* updates
    if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text.frameNStart = frameN  # exact frame index
        text.tStart = t  # local t and not account for scr refresh
        text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
        text.setAutoDraw(True)
    
    # *key_resp* updates
    waitOnFlip = False
    if key_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp.frameNStart = frameN  # exact frame index
        key_resp.tStart = t  # local t and not account for scr refresh
        key_resp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
        key_resp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp.status == STARTED and not waitOnFlip:
        theseKeys = key_resp.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_allKeys.extend(theseKeys)
        if len(_key_resp_allKeys):
            key_resp.keys = _key_resp_allKeys[-1].name  # just the last key pressed
            key_resp.rt = _key_resp_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *next_intro1* updates
    if next_intro1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        next_intro1.frameNStart = frameN  # exact frame index
        next_intro1.tStart = t  # local t and not account for scr refresh
        next_intro1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(next_intro1, 'tStartRefresh')  # time at next scr refresh
        next_intro1.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Introduction_1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Introduction_1"-------
for thisComponent in Introduction_1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image.started', image.tStartRefresh)
thisExp.addData('image.stopped', image.tStopRefresh)
thisExp.addData('polygon_2.started', polygon_2.tStartRefresh)
thisExp.addData('polygon_2.stopped', polygon_2.tStopRefresh)
thisExp.addData('text.started', text.tStartRefresh)
thisExp.addData('text.stopped', text.tStopRefresh)
# check responses
if key_resp.keys in ['', [], None]:  # No response was made
    key_resp.keys = None
thisExp.addData('key_resp.keys',key_resp.keys)
if key_resp.keys != None:  # we had a response
    thisExp.addData('key_resp.rt', key_resp.rt)
thisExp.addData('key_resp.started', key_resp.tStartRefresh)
thisExp.addData('key_resp.stopped', key_resp.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('next_intro1.started', next_intro1.tStartRefresh)
thisExp.addData('next_intro1.stopped', next_intro1.tStopRefresh)
# the Routine "Introduction_1" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Introduction_2"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_2.keys = []
key_resp_2.rt = []
_key_resp_2_allKeys = []
next_intro2.bold = 'True'
# keep track of which components have finished
Introduction_2Components = [image_2, polygon_3, key_resp_2, text_2, next_intro2]
for thisComponent in Introduction_2Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Introduction_2Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Introduction_2"-------
while continueRoutine:
    # get current time
    t = Introduction_2Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Introduction_2Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_2* updates
    if image_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_2.frameNStart = frameN  # exact frame index
        image_2.tStart = t  # local t and not account for scr refresh
        image_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_2, 'tStartRefresh')  # time at next scr refresh
        image_2.setAutoDraw(True)
    
    # *polygon_3* updates
    if polygon_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        polygon_3.frameNStart = frameN  # exact frame index
        polygon_3.tStart = t  # local t and not account for scr refresh
        polygon_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(polygon_3, 'tStartRefresh')  # time at next scr refresh
        polygon_3.setAutoDraw(True)
    
    # *key_resp_2* updates
    waitOnFlip = False
    if key_resp_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_2.frameNStart = frameN  # exact frame index
        key_resp_2.tStart = t  # local t and not account for scr refresh
        key_resp_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_2, 'tStartRefresh')  # time at next scr refresh
        key_resp_2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_2.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_2.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_2_allKeys.extend(theseKeys)
        if len(_key_resp_2_allKeys):
            key_resp_2.keys = _key_resp_2_allKeys[-1].name  # just the last key pressed
            key_resp_2.rt = _key_resp_2_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *text_2* updates
    if text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_2.frameNStart = frameN  # exact frame index
        text_2.tStart = t  # local t and not account for scr refresh
        text_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_2, 'tStartRefresh')  # time at next scr refresh
        text_2.setAutoDraw(True)
    
    # *next_intro2* updates
    if next_intro2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        next_intro2.frameNStart = frameN  # exact frame index
        next_intro2.tStart = t  # local t and not account for scr refresh
        next_intro2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(next_intro2, 'tStartRefresh')  # time at next scr refresh
        next_intro2.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Introduction_2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Introduction_2"-------
for thisComponent in Introduction_2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image_2.started', image_2.tStartRefresh)
thisExp.addData('image_2.stopped', image_2.tStopRefresh)
thisExp.addData('polygon_3.started', polygon_3.tStartRefresh)
thisExp.addData('polygon_3.stopped', polygon_3.tStopRefresh)
# check responses
if key_resp_2.keys in ['', [], None]:  # No response was made
    key_resp_2.keys = None
thisExp.addData('key_resp_2.keys',key_resp_2.keys)
if key_resp_2.keys != None:  # we had a response
    thisExp.addData('key_resp_2.rt', key_resp_2.rt)
thisExp.addData('key_resp_2.started', key_resp_2.tStartRefresh)
thisExp.addData('key_resp_2.stopped', key_resp_2.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('text_2.started', text_2.tStartRefresh)
thisExp.addData('text_2.stopped', text_2.tStopRefresh)
thisExp.addData('next_intro2.started', next_intro2.tStartRefresh)
thisExp.addData('next_intro2.stopped', next_intro2.tStopRefresh)
# the Routine "Introduction_2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Participant_name"-------
continueRoutine = True
# update component parameters for each repeat
name_enter.reset()
name_enter.setText('')
# setup some python lists for storing info about the mouse1
mouse1.clicked_name = []
gotValidClick = False  # until a click is received
ptp_name = name_enter.text  # Set routine start values for ptp_name
thisExp.addData('ptp_name.routineStartVal', ptp_name)  # Save exp start value
# keep track of which components have finished
Participant_nameComponents = [name_question, name_enter, button1, submit1, mouse1]
for thisComponent in Participant_nameComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Participant_nameClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Participant_name"-------
while continueRoutine:
    # get current time
    t = Participant_nameClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Participant_nameClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *name_question* updates
    if name_question.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        name_question.frameNStart = frameN  # exact frame index
        name_question.tStart = t  # local t and not account for scr refresh
        name_question.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(name_question, 'tStartRefresh')  # time at next scr refresh
        name_question.setAutoDraw(True)
    
    # *name_enter* updates
    if name_enter.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        name_enter.frameNStart = frameN  # exact frame index
        name_enter.tStart = t  # local t and not account for scr refresh
        name_enter.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(name_enter, 'tStartRefresh')  # time at next scr refresh
        name_enter.setAutoDraw(True)
    
    # *button1* updates
    if button1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        button1.frameNStart = frameN  # exact frame index
        button1.tStart = t  # local t and not account for scr refresh
        button1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(button1, 'tStartRefresh')  # time at next scr refresh
        button1.setAutoDraw(True)
    
    # *submit1* updates
    if submit1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        submit1.frameNStart = frameN  # exact frame index
        submit1.tStart = t  # local t and not account for scr refresh
        submit1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(submit1, 'tStartRefresh')  # time at next scr refresh
        submit1.setAutoDraw(True)
    # *mouse1* updates
    if mouse1.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        mouse1.frameNStart = frameN  # exact frame index
        mouse1.tStart = t  # local t and not account for scr refresh
        mouse1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(mouse1, 'tStartRefresh')  # time at next scr refresh
        mouse1.status = STARTED
        mouse1.mouseClock.reset()
        prevButtonState = mouse1.getPressed()  # if button is down already this ISN'T a new click
    if mouse1.status == STARTED:  # only update if started and not finished!
        buttons = mouse1.getPressed()
        if buttons != prevButtonState:  # button state changed?
            prevButtonState = buttons
            if sum(buttons) > 0:  # state changed to a new click
                # check if the mouse was inside our 'clickable' objects
                gotValidClick = False
                try:
                    iter(button1)
                    clickableList = button1
                except:
                    clickableList = [button1]
                for obj in clickableList:
                    if obj.contains(mouse1):
                        gotValidClick = True
                        mouse1.clicked_name.append(obj.name)
                if gotValidClick:  # abort routine on response
                    continueRoutine = False
    ptp_name = name_enter.text  # Set frame start values for ptp_name
    ptp_nameContainer.append(ptp_name)  # Save frame values
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Participant_nameComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Participant_name"-------
for thisComponent in Participant_nameComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('name_question.started', name_question.tStartRefresh)
thisExp.addData('name_question.stopped', name_question.tStopRefresh)
thisExp.addData('name_enter.text',name_enter.text)
thisExp.addData('name_enter.started', name_enter.tStartRefresh)
thisExp.addData('name_enter.stopped', name_enter.tStopRefresh)
thisExp.addData('button1.started', button1.tStartRefresh)
thisExp.addData('button1.stopped', button1.tStopRefresh)
thisExp.addData('submit1.started', submit1.tStartRefresh)
thisExp.addData('submit1.stopped', submit1.tStopRefresh)
# store data for thisExp (ExperimentHandler)
x, y = mouse1.getPos()
buttons = mouse1.getPressed()
if sum(buttons):
    # check if the mouse was inside our 'clickable' objects
    gotValidClick = False
    try:
        iter(button1)
        clickableList = button1
    except:
        clickableList = [button1]
    for obj in clickableList:
        if obj.contains(mouse1):
            gotValidClick = True
            mouse1.clicked_name.append(obj.name)
thisExp.addData('mouse1.x', x)
thisExp.addData('mouse1.y', y)
thisExp.addData('mouse1.leftButton', buttons[0])
thisExp.addData('mouse1.midButton', buttons[1])
thisExp.addData('mouse1.rightButton', buttons[2])
if len(mouse1.clicked_name):
    thisExp.addData('mouse1.clicked_name', mouse1.clicked_name[0])
thisExp.addData('mouse1.started', mouse1.tStart)
thisExp.addData('mouse1.stopped', mouse1.tStop)
thisExp.nextEntry()
thisExp.addData('ptp_name.expStartVal', name_enter.text)  # Save exp start value
thisExp.addData('ptp_name.routineEndVal', ptp_name)  # Save end routine value
thisExp.addData('ptp_name.frameStartVal', ptp_nameContainer[0])  # Save start frame value
if ptp_name.isalpha() and (ptp_name.islower() or (len(ptp_name) > 2 and ptp_name.isupper())):
    ptp_name = ptp_name.lower().capitalize()
ptp_name.strip()
# the Routine "Participant_name" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Participant_age"-------
continueRoutine = True
# update component parameters for each repeat
age_enter.reset()
age_enter.setText('')
# setup some python lists for storing info about the mouse2
mouse2.clicked_name = []
gotValidClick = False  # until a click is received
ptp_age = age_enter.text  # Set routine start values for ptp_age
# keep track of which components have finished
Participant_ageComponents = [age_question, age_enter, mouse2, button2, submit2, reminder]
for thisComponent in Participant_ageComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Participant_ageClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Participant_age"-------
while continueRoutine:
    # get current time
    t = Participant_ageClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Participant_ageClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *age_question* updates
    if age_question.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        age_question.frameNStart = frameN  # exact frame index
        age_question.tStart = t  # local t and not account for scr refresh
        age_question.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(age_question, 'tStartRefresh')  # time at next scr refresh
        age_question.setAutoDraw(True)
    
    # *age_enter* updates
    if age_enter.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        age_enter.frameNStart = frameN  # exact frame index
        age_enter.tStart = t  # local t and not account for scr refresh
        age_enter.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(age_enter, 'tStartRefresh')  # time at next scr refresh
        age_enter.setAutoDraw(True)
    # *mouse2* updates
    if mouse2.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        mouse2.frameNStart = frameN  # exact frame index
        mouse2.tStart = t  # local t and not account for scr refresh
        mouse2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(mouse2, 'tStartRefresh')  # time at next scr refresh
        mouse2.status = STARTED
        mouse2.mouseClock.reset()
        prevButtonState = mouse2.getPressed()  # if button is down already this ISN'T a new click
    if mouse2.status == STARTED:  # only update if started and not finished!
        buttons = mouse2.getPressed()
        if buttons != prevButtonState:  # button state changed?
            prevButtonState = buttons
            if sum(buttons) > 0:  # state changed to a new click
                # check if the mouse was inside our 'clickable' objects
                gotValidClick = False
                try:
                    iter(button2)
                    clickableList = button2
                except:
                    clickableList = [button2]
                for obj in clickableList:
                    if obj.contains(mouse2):
                        gotValidClick = True
                        mouse2.clicked_name.append(obj.name)
                if gotValidClick:  # abort routine on response
                    continueRoutine = False
    
    # *button2* updates
    if button2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        button2.frameNStart = frameN  # exact frame index
        button2.tStart = t  # local t and not account for scr refresh
        button2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(button2, 'tStartRefresh')  # time at next scr refresh
        button2.setAutoDraw(True)
    
    # *submit2* updates
    if submit2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        submit2.frameNStart = frameN  # exact frame index
        submit2.tStart = t  # local t and not account for scr refresh
        submit2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(submit2, 'tStartRefresh')  # time at next scr refresh
        submit2.setAutoDraw(True)
    
    # *reminder* updates
    if reminder.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        reminder.frameNStart = frameN  # exact frame index
        reminder.tStart = t  # local t and not account for scr refresh
        reminder.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(reminder, 'tStartRefresh')  # time at next scr refresh
        reminder.setAutoDraw(True)
    ptp_age = age_enter.text  # Set frame start values for ptp_age
    ptp_ageContainer.append(ptp_age)  # Save frame values
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Participant_ageComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Participant_age"-------
for thisComponent in Participant_ageComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('age_question.started', age_question.tStartRefresh)
thisExp.addData('age_question.stopped', age_question.tStopRefresh)
thisExp.addData('age_enter.text',age_enter.text)
thisExp.addData('age_enter.started', age_enter.tStartRefresh)
thisExp.addData('age_enter.stopped', age_enter.tStopRefresh)
# store data for thisExp (ExperimentHandler)
x, y = mouse2.getPos()
buttons = mouse2.getPressed()
if sum(buttons):
    # check if the mouse was inside our 'clickable' objects
    gotValidClick = False
    try:
        iter(button2)
        clickableList = button2
    except:
        clickableList = [button2]
    for obj in clickableList:
        if obj.contains(mouse2):
            gotValidClick = True
            mouse2.clicked_name.append(obj.name)
thisExp.addData('mouse2.x', x)
thisExp.addData('mouse2.y', y)
thisExp.addData('mouse2.leftButton', buttons[0])
thisExp.addData('mouse2.midButton', buttons[1])
thisExp.addData('mouse2.rightButton', buttons[2])
if len(mouse2.clicked_name):
    thisExp.addData('mouse2.clicked_name', mouse2.clicked_name[0])
thisExp.addData('mouse2.started', mouse2.tStart)
thisExp.addData('mouse2.stopped', mouse2.tStop)
thisExp.nextEntry()
thisExp.addData('button2.started', button2.tStartRefresh)
thisExp.addData('button2.stopped', button2.tStopRefresh)
thisExp.addData('submit2.started', submit2.tStartRefresh)
thisExp.addData('submit2.stopped', submit2.tStopRefresh)
thisExp.addData('reminder.started', reminder.tStartRefresh)
thisExp.addData('reminder.stopped', reminder.tStopRefresh)
thisExp.addData('ptp_age.routineEndVal', ptp_age)  # Save end routine value
thisExp.addData('ptp_age.frameStartVal', ptp_ageContainer[0])  # Save start frame value
# the Routine "Participant_age" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Participant_hometown"-------
continueRoutine = True
# update component parameters for each repeat
hometown_enter.reset()
hometown_enter.setText('')
# setup some python lists for storing info about the mouse3
mouse3.clicked_name = []
gotValidClick = False  # until a click is received
ptp_hometown = hometown_enter.text  # Set routine start values for ptp_hometown
# keep track of which components have finished
Participant_hometownComponents = [hometown_question, hometown_enter, mouse3, button3, submit3]
for thisComponent in Participant_hometownComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Participant_hometownClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Participant_hometown"-------
while continueRoutine:
    # get current time
    t = Participant_hometownClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Participant_hometownClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *hometown_question* updates
    if hometown_question.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        hometown_question.frameNStart = frameN  # exact frame index
        hometown_question.tStart = t  # local t and not account for scr refresh
        hometown_question.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(hometown_question, 'tStartRefresh')  # time at next scr refresh
        hometown_question.setAutoDraw(True)
    
    # *hometown_enter* updates
    if hometown_enter.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        hometown_enter.frameNStart = frameN  # exact frame index
        hometown_enter.tStart = t  # local t and not account for scr refresh
        hometown_enter.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(hometown_enter, 'tStartRefresh')  # time at next scr refresh
        hometown_enter.setAutoDraw(True)
    # *mouse3* updates
    if mouse3.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        mouse3.frameNStart = frameN  # exact frame index
        mouse3.tStart = t  # local t and not account for scr refresh
        mouse3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(mouse3, 'tStartRefresh')  # time at next scr refresh
        mouse3.status = STARTED
        mouse3.mouseClock.reset()
        prevButtonState = mouse3.getPressed()  # if button is down already this ISN'T a new click
    if mouse3.status == STARTED:  # only update if started and not finished!
        buttons = mouse3.getPressed()
        if buttons != prevButtonState:  # button state changed?
            prevButtonState = buttons
            if sum(buttons) > 0:  # state changed to a new click
                # check if the mouse was inside our 'clickable' objects
                gotValidClick = False
                try:
                    iter(button2)
                    clickableList = button2
                except:
                    clickableList = [button2]
                for obj in clickableList:
                    if obj.contains(mouse3):
                        gotValidClick = True
                        mouse3.clicked_name.append(obj.name)
                if gotValidClick:  # abort routine on response
                    continueRoutine = False
    
    # *button3* updates
    if button3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        button3.frameNStart = frameN  # exact frame index
        button3.tStart = t  # local t and not account for scr refresh
        button3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(button3, 'tStartRefresh')  # time at next scr refresh
        button3.setAutoDraw(True)
    
    # *submit3* updates
    if submit3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        submit3.frameNStart = frameN  # exact frame index
        submit3.tStart = t  # local t and not account for scr refresh
        submit3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(submit3, 'tStartRefresh')  # time at next scr refresh
        submit3.setAutoDraw(True)
    ptp_hometown = hometown_enter.text  # Set frame start values for ptp_hometown
    ptp_hometownContainer.append(ptp_hometown)  # Save frame values
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Participant_hometownComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Participant_hometown"-------
for thisComponent in Participant_hometownComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('hometown_question.started', hometown_question.tStartRefresh)
thisExp.addData('hometown_question.stopped', hometown_question.tStopRefresh)
thisExp.addData('hometown_enter.text',hometown_enter.text)
thisExp.addData('hometown_enter.started', hometown_enter.tStartRefresh)
thisExp.addData('hometown_enter.stopped', hometown_enter.tStopRefresh)
# store data for thisExp (ExperimentHandler)
x, y = mouse3.getPos()
buttons = mouse3.getPressed()
if sum(buttons):
    # check if the mouse was inside our 'clickable' objects
    gotValidClick = False
    try:
        iter(button2)
        clickableList = button2
    except:
        clickableList = [button2]
    for obj in clickableList:
        if obj.contains(mouse3):
            gotValidClick = True
            mouse3.clicked_name.append(obj.name)
thisExp.addData('mouse3.x', x)
thisExp.addData('mouse3.y', y)
thisExp.addData('mouse3.leftButton', buttons[0])
thisExp.addData('mouse3.midButton', buttons[1])
thisExp.addData('mouse3.rightButton', buttons[2])
if len(mouse3.clicked_name):
    thisExp.addData('mouse3.clicked_name', mouse3.clicked_name[0])
thisExp.addData('mouse3.started', mouse3.tStart)
thisExp.addData('mouse3.stopped', mouse3.tStop)
thisExp.nextEntry()
thisExp.addData('button3.started', button3.tStartRefresh)
thisExp.addData('button3.stopped', button3.tStopRefresh)
thisExp.addData('submit3.started', submit3.tStartRefresh)
thisExp.addData('submit3.stopped', submit3.tStopRefresh)
thisExp.addData('ptp_hometown.routineEndVal', ptp_hometown)  # Save end routine value
thisExp.addData('ptp_hometown.frameStartVal', ptp_hometownContainer[0])  # Save start frame value
if ptp_hometown.isalpha() and (ptp_hometown.islower() or (len(ptp_hometown) > 2 and ptp_hometown.isupper())):
    ptp_hometown = ptp_hometown.lower().capitalize()
# the Routine "Participant_hometown" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Participant_interest"-------
continueRoutine = True
# update component parameters for each repeat
interest_enter.reset()
interest_enter.setText('')
# setup some python lists for storing info about the mouse4
mouse4.clicked_name = []
gotValidClick = False  # until a click is received
ptp_interest = interest_enter.text  # Set routine start values for ptp_interest
# keep track of which components have finished
Participant_interestComponents = [interest_question, interest_enter, mouse4, button4, submit4]
for thisComponent in Participant_interestComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Participant_interestClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Participant_interest"-------
while continueRoutine:
    # get current time
    t = Participant_interestClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Participant_interestClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *interest_question* updates
    if interest_question.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        interest_question.frameNStart = frameN  # exact frame index
        interest_question.tStart = t  # local t and not account for scr refresh
        interest_question.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(interest_question, 'tStartRefresh')  # time at next scr refresh
        interest_question.setAutoDraw(True)
    
    # *interest_enter* updates
    if interest_enter.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        interest_enter.frameNStart = frameN  # exact frame index
        interest_enter.tStart = t  # local t and not account for scr refresh
        interest_enter.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(interest_enter, 'tStartRefresh')  # time at next scr refresh
        interest_enter.setAutoDraw(True)
    # *mouse4* updates
    if mouse4.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        mouse4.frameNStart = frameN  # exact frame index
        mouse4.tStart = t  # local t and not account for scr refresh
        mouse4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(mouse4, 'tStartRefresh')  # time at next scr refresh
        mouse4.status = STARTED
        mouse4.mouseClock.reset()
        prevButtonState = mouse4.getPressed()  # if button is down already this ISN'T a new click
    if mouse4.status == STARTED:  # only update if started and not finished!
        buttons = mouse4.getPressed()
        if buttons != prevButtonState:  # button state changed?
            prevButtonState = buttons
            if sum(buttons) > 0:  # state changed to a new click
                # check if the mouse was inside our 'clickable' objects
                gotValidClick = False
                try:
                    iter(button2)
                    clickableList = button2
                except:
                    clickableList = [button2]
                for obj in clickableList:
                    if obj.contains(mouse4):
                        gotValidClick = True
                        mouse4.clicked_name.append(obj.name)
                if gotValidClick:  # abort routine on response
                    continueRoutine = False
    
    # *button4* updates
    if button4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        button4.frameNStart = frameN  # exact frame index
        button4.tStart = t  # local t and not account for scr refresh
        button4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(button4, 'tStartRefresh')  # time at next scr refresh
        button4.setAutoDraw(True)
    
    # *submit4* updates
    if submit4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        submit4.frameNStart = frameN  # exact frame index
        submit4.tStart = t  # local t and not account for scr refresh
        submit4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(submit4, 'tStartRefresh')  # time at next scr refresh
        submit4.setAutoDraw(True)
    ptp_interest = interest_enter.text  # Set frame start values for ptp_interest
    ptp_interestContainer.append(ptp_interest)  # Save frame values
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Participant_interestComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Participant_interest"-------
for thisComponent in Participant_interestComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('interest_question.started', interest_question.tStartRefresh)
thisExp.addData('interest_question.stopped', interest_question.tStopRefresh)
thisExp.addData('interest_enter.text',interest_enter.text)
thisExp.addData('interest_enter.started', interest_enter.tStartRefresh)
thisExp.addData('interest_enter.stopped', interest_enter.tStopRefresh)
# store data for thisExp (ExperimentHandler)
x, y = mouse4.getPos()
buttons = mouse4.getPressed()
if sum(buttons):
    # check if the mouse was inside our 'clickable' objects
    gotValidClick = False
    try:
        iter(button2)
        clickableList = button2
    except:
        clickableList = [button2]
    for obj in clickableList:
        if obj.contains(mouse4):
            gotValidClick = True
            mouse4.clicked_name.append(obj.name)
thisExp.addData('mouse4.x', x)
thisExp.addData('mouse4.y', y)
thisExp.addData('mouse4.leftButton', buttons[0])
thisExp.addData('mouse4.midButton', buttons[1])
thisExp.addData('mouse4.rightButton', buttons[2])
if len(mouse4.clicked_name):
    thisExp.addData('mouse4.clicked_name', mouse4.clicked_name[0])
thisExp.addData('mouse4.started', mouse4.tStart)
thisExp.addData('mouse4.stopped', mouse4.tStop)
thisExp.nextEntry()
thisExp.addData('button4.started', button4.tStartRefresh)
thisExp.addData('button4.stopped', button4.tStopRefresh)
thisExp.addData('submit4.started', submit4.tStartRefresh)
thisExp.addData('submit4.stopped', submit4.tStopRefresh)
thisExp.addData('ptp_interest.routineEndVal', ptp_interest)  # Save end routine value
thisExp.addData('ptp_interest.frameStartVal', ptp_interestContainer[0])  # Save start frame value
# the Routine "Participant_interest" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Participant_profile"-------
continueRoutine = True
# update component parameters for each repeat
subject_image.setImage('subject.jpg')
part_response.alignText = 'left'
part_prompts.alignText = 'left'
part_name.alignText = 'left'
part_name.bold = 'True'
next_text.bold = 'True'
next.keys = []
next.rt = []
_next_allKeys = []
# keep track of which components have finished
Participant_profileComponents = [image_4, border4, border, subject_image, part_response, part_prompts, part_name, next, next_text]
for thisComponent in Participant_profileComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Participant_profileClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Participant_profile"-------
while continueRoutine:
    # get current time
    t = Participant_profileClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Participant_profileClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_4* updates
    if image_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_4.frameNStart = frameN  # exact frame index
        image_4.tStart = t  # local t and not account for scr refresh
        image_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_4, 'tStartRefresh')  # time at next scr refresh
        image_4.setAutoDraw(True)
    
    # *border4* updates
    if border4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        border4.frameNStart = frameN  # exact frame index
        border4.tStart = t  # local t and not account for scr refresh
        border4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(border4, 'tStartRefresh')  # time at next scr refresh
        border4.setAutoDraw(True)
    
    # *border* updates
    if border.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        border.frameNStart = frameN  # exact frame index
        border.tStart = t  # local t and not account for scr refresh
        border.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(border, 'tStartRefresh')  # time at next scr refresh
        border.setAutoDraw(True)
    
    # *subject_image* updates
    if subject_image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        subject_image.frameNStart = frameN  # exact frame index
        subject_image.tStart = t  # local t and not account for scr refresh
        subject_image.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(subject_image, 'tStartRefresh')  # time at next scr refresh
        subject_image.setAutoDraw(True)
    
    # *part_response* updates
    if part_response.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        part_response.frameNStart = frameN  # exact frame index
        part_response.tStart = t  # local t and not account for scr refresh
        part_response.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(part_response, 'tStartRefresh')  # time at next scr refresh
        part_response.setAutoDraw(True)
    if part_response.status == STARTED:  # only update if drawing
        part_response.setText(ptp_age + '\n' + ptp_hometown + '\n' + ptp_interest, log=False)
    
    # *part_prompts* updates
    if part_prompts.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        part_prompts.frameNStart = frameN  # exact frame index
        part_prompts.tStart = t  # local t and not account for scr refresh
        part_prompts.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(part_prompts, 'tStartRefresh')  # time at next scr refresh
        part_prompts.setAutoDraw(True)
    
    # *part_name* updates
    if part_name.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        part_name.frameNStart = frameN  # exact frame index
        part_name.tStart = t  # local t and not account for scr refresh
        part_name.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(part_name, 'tStartRefresh')  # time at next scr refresh
        part_name.setAutoDraw(True)
    if part_name.status == STARTED:  # only update if drawing
        part_name.setText(ptp_name, log=False)
    
    # *next* updates
    waitOnFlip = False
    if next.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        next.frameNStart = frameN  # exact frame index
        next.tStart = t  # local t and not account for scr refresh
        next.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(next, 'tStartRefresh')  # time at next scr refresh
        next.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(next.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(next.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if next.status == STARTED and not waitOnFlip:
        theseKeys = next.getKeys(keyList=['space'], waitRelease=False)
        _next_allKeys.extend(theseKeys)
        if len(_next_allKeys):
            next.keys = _next_allKeys[-1].name  # just the last key pressed
            next.rt = _next_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *next_text* updates
    if next_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        next_text.frameNStart = frameN  # exact frame index
        next_text.tStart = t  # local t and not account for scr refresh
        next_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(next_text, 'tStartRefresh')  # time at next scr refresh
        next_text.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Participant_profileComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Participant_profile"-------
for thisComponent in Participant_profileComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image_4.started', image_4.tStartRefresh)
thisExp.addData('image_4.stopped', image_4.tStopRefresh)
thisExp.addData('border4.started', border4.tStartRefresh)
thisExp.addData('border4.stopped', border4.tStopRefresh)
thisExp.addData('border.started', border.tStartRefresh)
thisExp.addData('border.stopped', border.tStopRefresh)
thisExp.addData('subject_image.started', subject_image.tStartRefresh)
thisExp.addData('subject_image.stopped', subject_image.tStopRefresh)
thisExp.addData('part_response.started', part_response.tStartRefresh)
thisExp.addData('part_response.stopped', part_response.tStopRefresh)
thisExp.addData('part_prompts.started', part_prompts.tStartRefresh)
thisExp.addData('part_prompts.stopped', part_prompts.tStopRefresh)
thisExp.addData('part_name.started', part_name.tStartRefresh)
thisExp.addData('part_name.stopped', part_name.tStopRefresh)
# check responses
if next.keys in ['', [], None]:  # No response was made
    next.keys = None
thisExp.addData('next.keys',next.keys)
if next.keys != None:  # we had a response
    thisExp.addData('next.rt', next.rt)
thisExp.addData('next.started', next.tStartRefresh)
thisExp.addData('next.stopped', next.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('next_text.started', next_text.tStartRefresh)
thisExp.addData('next_text.stopped', next_text.tStopRefresh)
# the Routine "Participant_profile" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Waiting"-------
continueRoutine = True
routineTimer.add(5.000000)
# update component parameters for each repeat
text_6.setText('Waiting for others to connect to the social media platform...')
key_resp_6.keys = []
key_resp_6.rt = []
_key_resp_6_allKeys = []
# keep track of which components have finished
WaitingComponents = [image_8, polygon_6, text_6, key_resp_6, image_9]
for thisComponent in WaitingComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
WaitingClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Waiting"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = WaitingClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=WaitingClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_8* updates
    if image_8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_8.frameNStart = frameN  # exact frame index
        image_8.tStart = t  # local t and not account for scr refresh
        image_8.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_8, 'tStartRefresh')  # time at next scr refresh
        image_8.setAutoDraw(True)
    if image_8.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_8.tStartRefresh + 5-frameTolerance:
            # keep track of stop time/frame for later
            image_8.tStop = t  # not accounting for scr refresh
            image_8.frameNStop = frameN  # exact frame index
            win.timeOnFlip(image_8, 'tStopRefresh')  # time at next scr refresh
            image_8.setAutoDraw(False)
    
    # *polygon_6* updates
    if polygon_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        polygon_6.frameNStart = frameN  # exact frame index
        polygon_6.tStart = t  # local t and not account for scr refresh
        polygon_6.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(polygon_6, 'tStartRefresh')  # time at next scr refresh
        polygon_6.setAutoDraw(True)
    if polygon_6.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > polygon_6.tStartRefresh + 5-frameTolerance:
            # keep track of stop time/frame for later
            polygon_6.tStop = t  # not accounting for scr refresh
            polygon_6.frameNStop = frameN  # exact frame index
            win.timeOnFlip(polygon_6, 'tStopRefresh')  # time at next scr refresh
            polygon_6.setAutoDraw(False)
    
    # *text_6* updates
    if text_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_6.frameNStart = frameN  # exact frame index
        text_6.tStart = t  # local t and not account for scr refresh
        text_6.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_6, 'tStartRefresh')  # time at next scr refresh
        text_6.setAutoDraw(True)
    if text_6.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > text_6.tStartRefresh + 5-frameTolerance:
            # keep track of stop time/frame for later
            text_6.tStop = t  # not accounting for scr refresh
            text_6.frameNStop = frameN  # exact frame index
            win.timeOnFlip(text_6, 'tStopRefresh')  # time at next scr refresh
            text_6.setAutoDraw(False)
    
    # *key_resp_6* updates
    waitOnFlip = False
    if key_resp_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_6.frameNStart = frameN  # exact frame index
        key_resp_6.tStart = t  # local t and not account for scr refresh
        key_resp_6.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_6, 'tStartRefresh')  # time at next scr refresh
        key_resp_6.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_6.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_6.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_6.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > key_resp_6.tStartRefresh + 5-frameTolerance:
            # keep track of stop time/frame for later
            key_resp_6.tStop = t  # not accounting for scr refresh
            key_resp_6.frameNStop = frameN  # exact frame index
            win.timeOnFlip(key_resp_6, 'tStopRefresh')  # time at next scr refresh
            key_resp_6.status = FINISHED
    if key_resp_6.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_6.getKeys(keyList=None, waitRelease=False)
        _key_resp_6_allKeys.extend(theseKeys)
        if len(_key_resp_6_allKeys):
            key_resp_6.keys = _key_resp_6_allKeys[-1].name  # just the last key pressed
            key_resp_6.rt = _key_resp_6_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *image_9* updates
    if image_9.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_9.frameNStart = frameN  # exact frame index
        image_9.tStart = t  # local t and not account for scr refresh
        image_9.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_9, 'tStartRefresh')  # time at next scr refresh
        image_9.setAutoDraw(True)
    if image_9.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_9.tStartRefresh + 5-frameTolerance:
            # keep track of stop time/frame for later
            image_9.tStop = t  # not accounting for scr refresh
            image_9.frameNStop = frameN  # exact frame index
            win.timeOnFlip(image_9, 'tStopRefresh')  # time at next scr refresh
            image_9.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in WaitingComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Waiting"-------
for thisComponent in WaitingComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image_8.started', image_8.tStartRefresh)
thisExp.addData('image_8.stopped', image_8.tStopRefresh)
thisExp.addData('polygon_6.started', polygon_6.tStartRefresh)
thisExp.addData('polygon_6.stopped', polygon_6.tStopRefresh)
thisExp.addData('text_6.started', text_6.tStartRefresh)
thisExp.addData('text_6.stopped', text_6.tStopRefresh)
# check responses
if key_resp_6.keys in ['', [], None]:  # No response was made
    key_resp_6.keys = None
thisExp.addData('key_resp_6.keys',key_resp_6.keys)
if key_resp_6.keys != None:  # we had a response
    thisExp.addData('key_resp_6.rt', key_resp_6.rt)
thisExp.addData('key_resp_6.started', key_resp_6.tStartRefresh)
thisExp.addData('key_resp_6.stopped', key_resp_6.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('image_9.started', image_9.tStartRefresh)
thisExp.addData('image_9.stopped', image_9.tStopRefresh)

# ------Prepare to start Routine "Introduction_3"-------
continueRoutine = True
# update component parameters for each repeat
text_3.setText('All players are connected now. Take some time to get to know the other people playing the game with you.\n')
key_resp_3.keys = []
key_resp_3.rt = []
_key_resp_3_allKeys = []
next_intro3.bold = 'True'
# keep track of which components have finished
Introduction_3Components = [image_3, polygon, text_3, key_resp_3, next_intro3]
for thisComponent in Introduction_3Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Introduction_3Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Introduction_3"-------
while continueRoutine:
    # get current time
    t = Introduction_3Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Introduction_3Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_3* updates
    if image_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_3.frameNStart = frameN  # exact frame index
        image_3.tStart = t  # local t and not account for scr refresh
        image_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_3, 'tStartRefresh')  # time at next scr refresh
        image_3.setAutoDraw(True)
    
    # *polygon* updates
    if polygon.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        polygon.frameNStart = frameN  # exact frame index
        polygon.tStart = t  # local t and not account for scr refresh
        polygon.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(polygon, 'tStartRefresh')  # time at next scr refresh
        polygon.setAutoDraw(True)
    
    # *text_3* updates
    if text_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_3.frameNStart = frameN  # exact frame index
        text_3.tStart = t  # local t and not account for scr refresh
        text_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_3, 'tStartRefresh')  # time at next scr refresh
        text_3.setAutoDraw(True)
    
    # *key_resp_3* updates
    waitOnFlip = False
    if key_resp_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_3.frameNStart = frameN  # exact frame index
        key_resp_3.tStart = t  # local t and not account for scr refresh
        key_resp_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_3, 'tStartRefresh')  # time at next scr refresh
        key_resp_3.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_3.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_3.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_3.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_3.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_3_allKeys.extend(theseKeys)
        if len(_key_resp_3_allKeys):
            key_resp_3.keys = _key_resp_3_allKeys[-1].name  # just the last key pressed
            key_resp_3.rt = _key_resp_3_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *next_intro3* updates
    if next_intro3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        next_intro3.frameNStart = frameN  # exact frame index
        next_intro3.tStart = t  # local t and not account for scr refresh
        next_intro3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(next_intro3, 'tStartRefresh')  # time at next scr refresh
        next_intro3.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Introduction_3Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Introduction_3"-------
for thisComponent in Introduction_3Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image_3.started', image_3.tStartRefresh)
thisExp.addData('image_3.stopped', image_3.tStopRefresh)
thisExp.addData('polygon.started', polygon.tStartRefresh)
thisExp.addData('polygon.stopped', polygon.tStopRefresh)
thisExp.addData('text_3.started', text_3.tStartRefresh)
thisExp.addData('text_3.stopped', text_3.tStopRefresh)
# check responses
if key_resp_3.keys in ['', [], None]:  # No response was made
    key_resp_3.keys = None
thisExp.addData('key_resp_3.keys',key_resp_3.keys)
if key_resp_3.keys != None:  # we had a response
    thisExp.addData('key_resp_3.rt', key_resp_3.rt)
thisExp.addData('key_resp_3.started', key_resp_3.tStartRefresh)
thisExp.addData('key_resp_3.stopped', key_resp_3.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('next_intro3.started', next_intro3.tStartRefresh)
thisExp.addData('next_intro3.stopped', next_intro3.tStopRefresh)
# the Routine "Introduction_3" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
loader_loop = data.TrialHandler(nReps=1.0, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Trials.xlsx'),
    seed=None, name='loader_loop')
thisExp.addLoop(loader_loop)  # add the loop to the experiment
thisLoader_loop = loader_loop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisLoader_loop.rgb)
if thisLoader_loop != None:
    for paramName in thisLoader_loop:
        exec('{} = thisLoader_loop[paramName]'.format(paramName))

for thisLoader_loop in loader_loop:
    currentLoop = loader_loop
    # abbreviate parameter names if possible (e.g. rgb = thisLoader_loop.rgb)
    if thisLoader_loop != None:
        for paramName in thisLoader_loop:
            exec('{} = thisLoader_loop[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "Coplayer_profile_loader"-------
    continueRoutine = True
    # update component parameters for each repeat
    # add information into lists
    names.append(cop_name)
    ages.append(cop_age)
    hometowns.append(cop_hometown)
    interests.append(cop_interests)
    photos.append(cop_photo)
    votes.append(cop_vote)
    
    # keep track of which components have finished
    Coplayer_profile_loaderComponents = []
    for thisComponent in Coplayer_profile_loaderComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Coplayer_profile_loaderClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Coplayer_profile_loader"-------
    while continueRoutine:
        # get current time
        t = Coplayer_profile_loaderClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Coplayer_profile_loaderClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Coplayer_profile_loaderComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Coplayer_profile_loader"-------
    for thisComponent in Coplayer_profile_loaderComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "Coplayer_profile_loader" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
# completed 1.0 repeats of 'loader_loop'


# ------Prepare to start Routine "Coplayer_profile_shuffler"-------
continueRoutine = True
# update component parameters for each repeat
shuffle(names)
shuffle(ages)
shuffle(hometowns)
shuffle(interests)
shuffle(photos)
shuffle(votes)
# keep track of which components have finished
Coplayer_profile_shufflerComponents = []
for thisComponent in Coplayer_profile_shufflerComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Coplayer_profile_shufflerClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Coplayer_profile_shuffler"-------
while continueRoutine:
    # get current time
    t = Coplayer_profile_shufflerClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Coplayer_profile_shufflerClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Coplayer_profile_shufflerComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Coplayer_profile_shuffler"-------
for thisComponent in Coplayer_profile_shufflerComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "Coplayer_profile_shuffler" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
coplayers_show = data.TrialHandler(nReps=1.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Trials.xlsx'),
    seed=None, name='coplayers_show')
thisExp.addLoop(coplayers_show)  # add the loop to the experiment
thisCoplayers_show = coplayers_show.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisCoplayers_show.rgb)
if thisCoplayers_show != None:
    for paramName in thisCoplayers_show:
        exec('{} = thisCoplayers_show[paramName]'.format(paramName))

for thisCoplayers_show in coplayers_show:
    currentLoop = coplayers_show
    # abbreviate parameter names if possible (e.g. rgb = thisCoplayers_show.rgb)
    if thisCoplayers_show != None:
        for paramName in thisCoplayers_show:
            exec('{} = thisCoplayers_show[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "Coplayer_profiles"-------
    continueRoutine = True
    # update component parameters for each repeat
    image_5.setImage('images/background_profiles.jpeg')
    cop_resp_show.alignText = 'left'
    cop_prompts_show.alignText = 'left'
    cop_name_show.alignText = 'left'
    cop_name_show.bold = 'True'
    next_text_2.bold = 'True'
    
    curr_item += 1
    
    # assign current profiles
    cop_name = names[curr_item]
    cop_age = ages[curr_item]
    cop_hometown = hometowns[curr_item]
    cop_interests = interests[curr_item]
    cop_photo = photos[curr_item]
    
    print(cop_name)
    print(cop_age)
    print(cop_hometown)
    print(cop_interests)
    cop_img.setImage(cop_photo)
    cop_resp_show.setText(str(cop_age) + '\n' + cop_hometown + '\n' + cop_interests)
    cop_prompts_show.setText('Age:\nHometown:\nInterests:')
    cop_vote_show.setText(cop_vote)
    cop_name_show.setText(cop_name)
    next_2.keys = []
    next_2.rt = []
    _next_2_allKeys = []
    # keep track of which components have finished
    Coplayer_profilesComponents = [image_5, border4_2, border_3, cop_img, cop_resp_show, cop_prompts_show, cop_vote_show, cop_name_show, next_2, next_text_2]
    for thisComponent in Coplayer_profilesComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Coplayer_profilesClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Coplayer_profiles"-------
    while continueRoutine:
        # get current time
        t = Coplayer_profilesClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Coplayer_profilesClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *image_5* updates
        if image_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            image_5.frameNStart = frameN  # exact frame index
            image_5.tStart = t  # local t and not account for scr refresh
            image_5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image_5, 'tStartRefresh')  # time at next scr refresh
            image_5.setAutoDraw(True)
        
        # *border4_2* updates
        if border4_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            border4_2.frameNStart = frameN  # exact frame index
            border4_2.tStart = t  # local t and not account for scr refresh
            border4_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(border4_2, 'tStartRefresh')  # time at next scr refresh
            border4_2.setAutoDraw(True)
        
        # *border_3* updates
        if border_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            border_3.frameNStart = frameN  # exact frame index
            border_3.tStart = t  # local t and not account for scr refresh
            border_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(border_3, 'tStartRefresh')  # time at next scr refresh
            border_3.setAutoDraw(True)
        
        # *cop_img* updates
        if cop_img.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            cop_img.frameNStart = frameN  # exact frame index
            cop_img.tStart = t  # local t and not account for scr refresh
            cop_img.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(cop_img, 'tStartRefresh')  # time at next scr refresh
            cop_img.setAutoDraw(True)
        
        # *cop_resp_show* updates
        if cop_resp_show.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            cop_resp_show.frameNStart = frameN  # exact frame index
            cop_resp_show.tStart = t  # local t and not account for scr refresh
            cop_resp_show.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(cop_resp_show, 'tStartRefresh')  # time at next scr refresh
            cop_resp_show.setAutoDraw(True)
        
        # *cop_prompts_show* updates
        if cop_prompts_show.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            cop_prompts_show.frameNStart = frameN  # exact frame index
            cop_prompts_show.tStart = t  # local t and not account for scr refresh
            cop_prompts_show.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(cop_prompts_show, 'tStartRefresh')  # time at next scr refresh
            cop_prompts_show.setAutoDraw(True)
        
        # *cop_vote_show* updates
        if cop_vote_show.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            cop_vote_show.frameNStart = frameN  # exact frame index
            cop_vote_show.tStart = t  # local t and not account for scr refresh
            cop_vote_show.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(cop_vote_show, 'tStartRefresh')  # time at next scr refresh
            cop_vote_show.setAutoDraw(True)
        
        # *cop_name_show* updates
        if cop_name_show.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            cop_name_show.frameNStart = frameN  # exact frame index
            cop_name_show.tStart = t  # local t and not account for scr refresh
            cop_name_show.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(cop_name_show, 'tStartRefresh')  # time at next scr refresh
            cop_name_show.setAutoDraw(True)
        
        # *next_2* updates
        waitOnFlip = False
        if next_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            next_2.frameNStart = frameN  # exact frame index
            next_2.tStart = t  # local t and not account for scr refresh
            next_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(next_2, 'tStartRefresh')  # time at next scr refresh
            next_2.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(next_2.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(next_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if next_2.status == STARTED and not waitOnFlip:
            theseKeys = next_2.getKeys(keyList=['space'], waitRelease=False)
            _next_2_allKeys.extend(theseKeys)
            if len(_next_2_allKeys):
                next_2.keys = _next_2_allKeys[-1].name  # just the last key pressed
                next_2.rt = _next_2_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # *next_text_2* updates
        if next_text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            next_text_2.frameNStart = frameN  # exact frame index
            next_text_2.tStart = t  # local t and not account for scr refresh
            next_text_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(next_text_2, 'tStartRefresh')  # time at next scr refresh
            next_text_2.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Coplayer_profilesComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Coplayer_profiles"-------
    for thisComponent in Coplayer_profilesComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    coplayers_show.addData('image_5.started', image_5.tStartRefresh)
    coplayers_show.addData('image_5.stopped', image_5.tStopRefresh)
    coplayers_show.addData('border4_2.started', border4_2.tStartRefresh)
    coplayers_show.addData('border4_2.stopped', border4_2.tStopRefresh)
    coplayers_show.addData('border_3.started', border_3.tStartRefresh)
    coplayers_show.addData('border_3.stopped', border_3.tStopRefresh)
    print(photos)
    print(names)
    print(interests)
    print(hometowns)
    coplayers_show.addData('cop_img.started', cop_img.tStartRefresh)
    coplayers_show.addData('cop_img.stopped', cop_img.tStopRefresh)
    coplayers_show.addData('cop_resp_show.started', cop_resp_show.tStartRefresh)
    coplayers_show.addData('cop_resp_show.stopped', cop_resp_show.tStopRefresh)
    coplayers_show.addData('cop_prompts_show.started', cop_prompts_show.tStartRefresh)
    coplayers_show.addData('cop_prompts_show.stopped', cop_prompts_show.tStopRefresh)
    coplayers_show.addData('cop_vote_show.started', cop_vote_show.tStartRefresh)
    coplayers_show.addData('cop_vote_show.stopped', cop_vote_show.tStopRefresh)
    coplayers_show.addData('cop_name_show.started', cop_name_show.tStartRefresh)
    coplayers_show.addData('cop_name_show.stopped', cop_name_show.tStopRefresh)
    # check responses
    if next_2.keys in ['', [], None]:  # No response was made
        next_2.keys = None
    coplayers_show.addData('next_2.keys',next_2.keys)
    if next_2.keys != None:  # we had a response
        coplayers_show.addData('next_2.rt', next_2.rt)
    coplayers_show.addData('next_2.started', next_2.tStartRefresh)
    coplayers_show.addData('next_2.stopped', next_2.tStopRefresh)
    coplayers_show.addData('next_text_2.started', next_text_2.tStartRefresh)
    coplayers_show.addData('next_text_2.stopped', next_text_2.tStopRefresh)
    # the Routine "Coplayer_profiles" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'coplayers_show'


# ------Prepare to start Routine "Vote_store"-------
continueRoutine = True
# update component parameters for each repeat

#already have assigned lists
vote_cop1 = votes[0]
vote_cop2 = votes[1]
vote_cop3 = votes[2]
vote_cop4 = votes[3]
vote_cop5 = votes[4]
vote_cop6 = votes[5]
vote_cop7 = votes[6]
vote_cop8 = votes[7]
vote_cop9 = votes[8]
vote_cop10 = votes[9]
vote_cop11 = votes[10]

# seperate by ','
vote_split_cop1 = vote_cop1.split(',')
vote_split_cop2 = vote_cop2.split(',')
vote_split_cop3 = vote_cop3.split(',')
vote_split_cop4 = vote_cop4.split(',')
vote_split_cop5 = vote_cop5.split(',')
vote_split_cop6 = vote_cop6.split(',')
vote_split_cop7 = vote_cop7.split(',')
vote_split_cop8 = vote_cop8.split(',')
vote_split_cop9 = vote_cop9.split(',')
vote_split_cop10 = vote_cop10.split(',')
vote_split_cop11 = vote_cop11.split(',')

# shuffle vote patterns
shuffle(vote_split_cop1)
shuffle(vote_split_cop2)
shuffle(vote_split_cop3)
shuffle(vote_split_cop4)
shuffle(vote_split_cop5)
shuffle(vote_split_cop6)
shuffle(vote_split_cop7)
shuffle(vote_split_cop8)
shuffle(vote_split_cop9)
shuffle(vote_split_cop10)
shuffle(vote_split_cop11)

# create a new empty list
vote_all = []

#append lists to new list
vote_all.append(vote_split_cop1)
vote_all.append(vote_split_cop2)
vote_all.append(vote_split_cop3)
vote_all.append(vote_split_cop4)
vote_all.append(vote_split_cop5)
vote_all.append(vote_split_cop6)
vote_all.append(vote_split_cop7)
vote_all.append(vote_split_cop8)
vote_all.append(vote_split_cop9)
vote_all.append(vote_split_cop10)
vote_all.append(vote_split_cop11)

# got vote pattern lists for every coplayer
print(vote_split_cop1)
print(vote_split_cop2)
print(vote_split_cop3)
print(vote_split_cop4)
print(vote_split_cop5)
print(vote_split_cop6)
print(vote_split_cop7)
print(vote_split_cop8)
print(vote_split_cop9)
print(vote_split_cop10)
print(vote_split_cop11)

# check final vote_all
print(vote_all)
# keep track of which components have finished
Vote_storeComponents = []
for thisComponent in Vote_storeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Vote_storeClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Vote_store"-------
while continueRoutine:
    # get current time
    t = Vote_storeClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Vote_storeClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Vote_storeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Vote_store"-------
for thisComponent in Vote_storeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "Vote_store" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Introduction_4"-------
continueRoutine = True
# update component parameters for each repeat
text_4.setText("Now, we want to hear from YOU about which players you like and which players you dislike, based on the information you have so far.  You will see each player’s profile again and this time click 'Like' if you like that person and 'Dislike' if you dislike that person. \n\n")
key_resp_4.keys = []
key_resp_4.rt = []
_key_resp_4_allKeys = []
next_intro4.bold = 'True'
# keep track of which components have finished
Introduction_4Components = [image_6, polygon_4, text_4, key_resp_4, next_intro4]
for thisComponent in Introduction_4Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Introduction_4Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Introduction_4"-------
while continueRoutine:
    # get current time
    t = Introduction_4Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Introduction_4Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_6* updates
    if image_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_6.frameNStart = frameN  # exact frame index
        image_6.tStart = t  # local t and not account for scr refresh
        image_6.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_6, 'tStartRefresh')  # time at next scr refresh
        image_6.setAutoDraw(True)
    
    # *polygon_4* updates
    if polygon_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        polygon_4.frameNStart = frameN  # exact frame index
        polygon_4.tStart = t  # local t and not account for scr refresh
        polygon_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(polygon_4, 'tStartRefresh')  # time at next scr refresh
        polygon_4.setAutoDraw(True)
    
    # *text_4* updates
    if text_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_4.frameNStart = frameN  # exact frame index
        text_4.tStart = t  # local t and not account for scr refresh
        text_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_4, 'tStartRefresh')  # time at next scr refresh
        text_4.setAutoDraw(True)
    
    # *key_resp_4* updates
    waitOnFlip = False
    if key_resp_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_4.frameNStart = frameN  # exact frame index
        key_resp_4.tStart = t  # local t and not account for scr refresh
        key_resp_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_4, 'tStartRefresh')  # time at next scr refresh
        key_resp_4.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_4.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_4.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_4.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_4.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_4_allKeys.extend(theseKeys)
        if len(_key_resp_4_allKeys):
            key_resp_4.keys = _key_resp_4_allKeys[-1].name  # just the last key pressed
            key_resp_4.rt = _key_resp_4_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *next_intro4* updates
    if next_intro4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        next_intro4.frameNStart = frameN  # exact frame index
        next_intro4.tStart = t  # local t and not account for scr refresh
        next_intro4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(next_intro4, 'tStartRefresh')  # time at next scr refresh
        next_intro4.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Introduction_4Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Introduction_4"-------
for thisComponent in Introduction_4Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image_6.started', image_6.tStartRefresh)
thisExp.addData('image_6.stopped', image_6.tStopRefresh)
thisExp.addData('polygon_4.started', polygon_4.tStartRefresh)
thisExp.addData('polygon_4.stopped', polygon_4.tStopRefresh)
thisExp.addData('text_4.started', text_4.tStartRefresh)
thisExp.addData('text_4.stopped', text_4.tStopRefresh)
# check responses
if key_resp_4.keys in ['', [], None]:  # No response was made
    key_resp_4.keys = None
thisExp.addData('key_resp_4.keys',key_resp_4.keys)
if key_resp_4.keys != None:  # we had a response
    thisExp.addData('key_resp_4.rt', key_resp_4.rt)
thisExp.addData('key_resp_4.started', key_resp_4.tStartRefresh)
thisExp.addData('key_resp_4.stopped', key_resp_4.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('next_intro4.started', next_intro4.tStartRefresh)
thisExp.addData('next_intro4.stopped', next_intro4.tStopRefresh)
# the Routine "Introduction_4" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Introduction_5"-------
continueRoutine = True
# update component parameters for each repeat
text_5.setText('While you are voting on each player, the same person is also voting on you. After you both make your selections, you will find out how they voted for you. The feedback will look like this:\n\n')
key_resp_5.keys = []
key_resp_5.rt = []
_key_resp_5_allKeys = []
next_3.bold = 'True'
# keep track of which components have finished
Introduction_5Components = [image_7, polygon_5, text_5, key_resp_5, thumbs_up, thumbs_down, feedback_like, feedback_dislike, next_3]
for thisComponent in Introduction_5Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Introduction_5Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Introduction_5"-------
while continueRoutine:
    # get current time
    t = Introduction_5Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Introduction_5Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_7* updates
    if image_7.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_7.frameNStart = frameN  # exact frame index
        image_7.tStart = t  # local t and not account for scr refresh
        image_7.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_7, 'tStartRefresh')  # time at next scr refresh
        image_7.setAutoDraw(True)
    
    # *polygon_5* updates
    if polygon_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        polygon_5.frameNStart = frameN  # exact frame index
        polygon_5.tStart = t  # local t and not account for scr refresh
        polygon_5.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(polygon_5, 'tStartRefresh')  # time at next scr refresh
        polygon_5.setAutoDraw(True)
    
    # *text_5* updates
    if text_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_5.frameNStart = frameN  # exact frame index
        text_5.tStart = t  # local t and not account for scr refresh
        text_5.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_5, 'tStartRefresh')  # time at next scr refresh
        text_5.setAutoDraw(True)
    
    # *key_resp_5* updates
    waitOnFlip = False
    if key_resp_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_5.frameNStart = frameN  # exact frame index
        key_resp_5.tStart = t  # local t and not account for scr refresh
        key_resp_5.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_5, 'tStartRefresh')  # time at next scr refresh
        key_resp_5.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_5.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_5.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_5.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_5.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_5_allKeys.extend(theseKeys)
        if len(_key_resp_5_allKeys):
            key_resp_5.keys = _key_resp_5_allKeys[-1].name  # just the last key pressed
            key_resp_5.rt = _key_resp_5_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *thumbs_up* updates
    if thumbs_up.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        thumbs_up.frameNStart = frameN  # exact frame index
        thumbs_up.tStart = t  # local t and not account for scr refresh
        thumbs_up.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(thumbs_up, 'tStartRefresh')  # time at next scr refresh
        thumbs_up.setAutoDraw(True)
    
    # *thumbs_down* updates
    if thumbs_down.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        thumbs_down.frameNStart = frameN  # exact frame index
        thumbs_down.tStart = t  # local t and not account for scr refresh
        thumbs_down.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(thumbs_down, 'tStartRefresh')  # time at next scr refresh
        thumbs_down.setAutoDraw(True)
    
    # *feedback_like* updates
    if feedback_like.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        feedback_like.frameNStart = frameN  # exact frame index
        feedback_like.tStart = t  # local t and not account for scr refresh
        feedback_like.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(feedback_like, 'tStartRefresh')  # time at next scr refresh
        feedback_like.setAutoDraw(True)
    
    # *feedback_dislike* updates
    if feedback_dislike.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        feedback_dislike.frameNStart = frameN  # exact frame index
        feedback_dislike.tStart = t  # local t and not account for scr refresh
        feedback_dislike.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(feedback_dislike, 'tStartRefresh')  # time at next scr refresh
        feedback_dislike.setAutoDraw(True)
    
    # *next_3* updates
    if next_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        next_3.frameNStart = frameN  # exact frame index
        next_3.tStart = t  # local t and not account for scr refresh
        next_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(next_3, 'tStartRefresh')  # time at next scr refresh
        next_3.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Introduction_5Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Introduction_5"-------
for thisComponent in Introduction_5Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image_7.started', image_7.tStartRefresh)
thisExp.addData('image_7.stopped', image_7.tStopRefresh)
thisExp.addData('polygon_5.started', polygon_5.tStartRefresh)
thisExp.addData('polygon_5.stopped', polygon_5.tStopRefresh)
thisExp.addData('text_5.started', text_5.tStartRefresh)
thisExp.addData('text_5.stopped', text_5.tStopRefresh)
# check responses
if key_resp_5.keys in ['', [], None]:  # No response was made
    key_resp_5.keys = None
thisExp.addData('key_resp_5.keys',key_resp_5.keys)
if key_resp_5.keys != None:  # we had a response
    thisExp.addData('key_resp_5.rt', key_resp_5.rt)
thisExp.addData('key_resp_5.started', key_resp_5.tStartRefresh)
thisExp.addData('key_resp_5.stopped', key_resp_5.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('thumbs_up.started', thumbs_up.tStartRefresh)
thisExp.addData('thumbs_up.stopped', thumbs_up.tStopRefresh)
thisExp.addData('thumbs_down.started', thumbs_down.tStartRefresh)
thisExp.addData('thumbs_down.stopped', thumbs_down.tStopRefresh)
thisExp.addData('feedback_like.started', feedback_like.tStartRefresh)
thisExp.addData('feedback_like.stopped', feedback_like.tStopRefresh)
thisExp.addData('feedback_dislike.started', feedback_dislike.tStartRefresh)
thisExp.addData('feedback_dislike.stopped', feedback_dislike.tStopRefresh)
thisExp.addData('next_3.started', next_3.tStartRefresh)
thisExp.addData('next_3.stopped', next_3.tStopRefresh)
# the Routine "Introduction_5" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Introduction_6"-------
continueRoutine = True
# update component parameters for each repeat
text_10.setText('Remember there will be 5 rounds so you can change your votes for other in future rounds and you may find that other players change their votes for you as well.\n\nFirst, let’s do some practice trials to make sure it’s clear how voting works.\n\n')
key_resp_10.keys = []
key_resp_10.rt = []
_key_resp_10_allKeys = []
next_intro6.bold = 'True'
# keep track of which components have finished
Introduction_6Components = [image_13, polygon_10, text_10, key_resp_10, next_intro6]
for thisComponent in Introduction_6Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Introduction_6Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Introduction_6"-------
while continueRoutine:
    # get current time
    t = Introduction_6Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Introduction_6Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_13* updates
    if image_13.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_13.frameNStart = frameN  # exact frame index
        image_13.tStart = t  # local t and not account for scr refresh
        image_13.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_13, 'tStartRefresh')  # time at next scr refresh
        image_13.setAutoDraw(True)
    
    # *polygon_10* updates
    if polygon_10.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        polygon_10.frameNStart = frameN  # exact frame index
        polygon_10.tStart = t  # local t and not account for scr refresh
        polygon_10.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(polygon_10, 'tStartRefresh')  # time at next scr refresh
        polygon_10.setAutoDraw(True)
    
    # *text_10* updates
    if text_10.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_10.frameNStart = frameN  # exact frame index
        text_10.tStart = t  # local t and not account for scr refresh
        text_10.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_10, 'tStartRefresh')  # time at next scr refresh
        text_10.setAutoDraw(True)
    
    # *key_resp_10* updates
    waitOnFlip = False
    if key_resp_10.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_10.frameNStart = frameN  # exact frame index
        key_resp_10.tStart = t  # local t and not account for scr refresh
        key_resp_10.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_10, 'tStartRefresh')  # time at next scr refresh
        key_resp_10.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_10.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_10.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_10.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_10.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_10_allKeys.extend(theseKeys)
        if len(_key_resp_10_allKeys):
            key_resp_10.keys = _key_resp_10_allKeys[-1].name  # just the last key pressed
            key_resp_10.rt = _key_resp_10_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *next_intro6* updates
    if next_intro6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        next_intro6.frameNStart = frameN  # exact frame index
        next_intro6.tStart = t  # local t and not account for scr refresh
        next_intro6.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(next_intro6, 'tStartRefresh')  # time at next scr refresh
        next_intro6.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Introduction_6Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Introduction_6"-------
for thisComponent in Introduction_6Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image_13.started', image_13.tStartRefresh)
thisExp.addData('image_13.stopped', image_13.tStopRefresh)
thisExp.addData('polygon_10.started', polygon_10.tStartRefresh)
thisExp.addData('polygon_10.stopped', polygon_10.tStopRefresh)
thisExp.addData('text_10.started', text_10.tStartRefresh)
thisExp.addData('text_10.stopped', text_10.tStopRefresh)
# check responses
if key_resp_10.keys in ['', [], None]:  # No response was made
    key_resp_10.keys = None
thisExp.addData('key_resp_10.keys',key_resp_10.keys)
if key_resp_10.keys != None:  # we had a response
    thisExp.addData('key_resp_10.rt', key_resp_10.rt)
thisExp.addData('key_resp_10.started', key_resp_10.tStartRefresh)
thisExp.addData('key_resp_10.stopped', key_resp_10.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('next_intro6.started', next_intro6.tStartRefresh)
thisExp.addData('next_intro6.stopped', next_intro6.tStopRefresh)
# the Routine "Introduction_6" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Practice_1a"-------
continueRoutine = True
# update component parameters for each repeat
prac_image_2.setImage('images/example-male.png')
# setup some python lists for storing info about the like_click_2
gotValidClick = False  # until a click is received
# setup some python lists for storing info about the Dislike_click_2
gotValidClick = False  # until a click is received
player1_2.setText('Player 1')
player1_2.bold = 'True'
vote_question_2.bold = 'True'
# keep track of which components have finished
Practice_1aComponents = [border_5, prac_image_2, like_button_2, like_text_2, like_click_2, dislike_button_2, dislike_text_2, Dislike_click_2, player1_2, vote_question_2]
for thisComponent in Practice_1aComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Practice_1aClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Practice_1a"-------
while continueRoutine:
    # get current time
    t = Practice_1aClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Practice_1aClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *border_5* updates
    if border_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        border_5.frameNStart = frameN  # exact frame index
        border_5.tStart = t  # local t and not account for scr refresh
        border_5.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(border_5, 'tStartRefresh')  # time at next scr refresh
        border_5.setAutoDraw(True)
    
    # *prac_image_2* updates
    if prac_image_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        prac_image_2.frameNStart = frameN  # exact frame index
        prac_image_2.tStart = t  # local t and not account for scr refresh
        prac_image_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(prac_image_2, 'tStartRefresh')  # time at next scr refresh
        prac_image_2.setAutoDraw(True)
    
    # *like_button_2* updates
    if like_button_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        like_button_2.frameNStart = frameN  # exact frame index
        like_button_2.tStart = t  # local t and not account for scr refresh
        like_button_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(like_button_2, 'tStartRefresh')  # time at next scr refresh
        like_button_2.setAutoDraw(True)
    
    # *like_text_2* updates
    if like_text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        like_text_2.frameNStart = frameN  # exact frame index
        like_text_2.tStart = t  # local t and not account for scr refresh
        like_text_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(like_text_2, 'tStartRefresh')  # time at next scr refresh
        like_text_2.setAutoDraw(True)
    # *like_click_2* updates
    if like_click_2.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        like_click_2.frameNStart = frameN  # exact frame index
        like_click_2.tStart = t  # local t and not account for scr refresh
        like_click_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(like_click_2, 'tStartRefresh')  # time at next scr refresh
        like_click_2.status = STARTED
        like_click_2.mouseClock.reset()
        prevButtonState = like_click_2.getPressed()  # if button is down already this ISN'T a new click
    if like_click_2.status == STARTED:  # only update if started and not finished!
        buttons = like_click_2.getPressed()
        if buttons != prevButtonState:  # button state changed?
            prevButtonState = buttons
            if sum(buttons) > 0:  # state changed to a new click
                # abort routine on response
                continueRoutine = False
    
    # *dislike_button_2* updates
    if dislike_button_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        dislike_button_2.frameNStart = frameN  # exact frame index
        dislike_button_2.tStart = t  # local t and not account for scr refresh
        dislike_button_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(dislike_button_2, 'tStartRefresh')  # time at next scr refresh
        dislike_button_2.setAutoDraw(True)
    
    # *dislike_text_2* updates
    if dislike_text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        dislike_text_2.frameNStart = frameN  # exact frame index
        dislike_text_2.tStart = t  # local t and not account for scr refresh
        dislike_text_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(dislike_text_2, 'tStartRefresh')  # time at next scr refresh
        dislike_text_2.setAutoDraw(True)
    # *Dislike_click_2* updates
    if Dislike_click_2.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        Dislike_click_2.frameNStart = frameN  # exact frame index
        Dislike_click_2.tStart = t  # local t and not account for scr refresh
        Dislike_click_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(Dislike_click_2, 'tStartRefresh')  # time at next scr refresh
        Dislike_click_2.status = STARTED
        Dislike_click_2.mouseClock.reset()
        prevButtonState = Dislike_click_2.getPressed()  # if button is down already this ISN'T a new click
    if Dislike_click_2.status == STARTED:  # only update if started and not finished!
        buttons = Dislike_click_2.getPressed()
        if buttons != prevButtonState:  # button state changed?
            prevButtonState = buttons
            if sum(buttons) > 0:  # state changed to a new click
                # abort routine on response
                continueRoutine = False
    
    # *player1_2* updates
    if player1_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        player1_2.frameNStart = frameN  # exact frame index
        player1_2.tStart = t  # local t and not account for scr refresh
        player1_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(player1_2, 'tStartRefresh')  # time at next scr refresh
        player1_2.setAutoDraw(True)
    
    # *vote_question_2* updates
    if vote_question_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        vote_question_2.frameNStart = frameN  # exact frame index
        vote_question_2.tStart = t  # local t and not account for scr refresh
        vote_question_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(vote_question_2, 'tStartRefresh')  # time at next scr refresh
        vote_question_2.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Practice_1aComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Practice_1a"-------
for thisComponent in Practice_1aComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('border_5.started', border_5.tStartRefresh)
thisExp.addData('border_5.stopped', border_5.tStopRefresh)
thisExp.addData('prac_image_2.started', prac_image_2.tStartRefresh)
thisExp.addData('prac_image_2.stopped', prac_image_2.tStopRefresh)
thisExp.addData('like_button_2.started', like_button_2.tStartRefresh)
thisExp.addData('like_button_2.stopped', like_button_2.tStopRefresh)
thisExp.addData('like_text_2.started', like_text_2.tStartRefresh)
thisExp.addData('like_text_2.stopped', like_text_2.tStopRefresh)
# store data for thisExp (ExperimentHandler)
x, y = like_click_2.getPos()
buttons = like_click_2.getPressed()
thisExp.addData('like_click_2.x', x)
thisExp.addData('like_click_2.y', y)
thisExp.addData('like_click_2.leftButton', buttons[0])
thisExp.addData('like_click_2.midButton', buttons[1])
thisExp.addData('like_click_2.rightButton', buttons[2])
thisExp.addData('like_click_2.started', like_click_2.tStart)
thisExp.addData('like_click_2.stopped', like_click_2.tStop)
thisExp.nextEntry()
thisExp.addData('dislike_button_2.started', dislike_button_2.tStartRefresh)
thisExp.addData('dislike_button_2.stopped', dislike_button_2.tStopRefresh)
thisExp.addData('dislike_text_2.started', dislike_text_2.tStartRefresh)
thisExp.addData('dislike_text_2.stopped', dislike_text_2.tStopRefresh)
# store data for thisExp (ExperimentHandler)
x, y = Dislike_click_2.getPos()
buttons = Dislike_click_2.getPressed()
thisExp.addData('Dislike_click_2.x', x)
thisExp.addData('Dislike_click_2.y', y)
thisExp.addData('Dislike_click_2.leftButton', buttons[0])
thisExp.addData('Dislike_click_2.midButton', buttons[1])
thisExp.addData('Dislike_click_2.rightButton', buttons[2])
thisExp.addData('Dislike_click_2.started', Dislike_click_2.tStart)
thisExp.addData('Dislike_click_2.stopped', Dislike_click_2.tStop)
thisExp.nextEntry()
thisExp.addData('player1_2.started', player1_2.tStartRefresh)
thisExp.addData('player1_2.stopped', player1_2.tStopRefresh)
thisExp.addData('vote_question_2.started', vote_question_2.tStartRefresh)
thisExp.addData('vote_question_2.stopped', vote_question_2.tStopRefresh)
# the Routine "Practice_1a" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Practice_1b"-------
continueRoutine = True
routineTimer.add(2.000000)
# update component parameters for each repeat
# keep track of which components have finished
Practice_1bComponents = [wait]
for thisComponent in Practice_1bComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Practice_1bClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Practice_1b"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = Practice_1bClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Practice_1bClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *wait* updates
    if wait.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        wait.frameNStart = frameN  # exact frame index
        wait.tStart = t  # local t and not account for scr refresh
        wait.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(wait, 'tStartRefresh')  # time at next scr refresh
        wait.setAutoDraw(True)
    if wait.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > wait.tStartRefresh + 2-frameTolerance:
            # keep track of stop time/frame for later
            wait.tStop = t  # not accounting for scr refresh
            wait.frameNStop = frameN  # exact frame index
            win.timeOnFlip(wait, 'tStopRefresh')  # time at next scr refresh
            wait.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Practice_1bComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Practice_1b"-------
for thisComponent in Practice_1bComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('wait.started', wait.tStartRefresh)
thisExp.addData('wait.stopped', wait.tStopRefresh)

# ------Prepare to start Routine "Practice_1c"-------
continueRoutine = True
routineTimer.add(2.000000)
# update component parameters for each repeat
# keep track of which components have finished
Practice_1cComponents = [like_prac]
for thisComponent in Practice_1cComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Practice_1cClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Practice_1c"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = Practice_1cClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Practice_1cClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *like_prac* updates
    if like_prac.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        like_prac.frameNStart = frameN  # exact frame index
        like_prac.tStart = t  # local t and not account for scr refresh
        like_prac.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(like_prac, 'tStartRefresh')  # time at next scr refresh
        like_prac.setAutoDraw(True)
    if like_prac.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > like_prac.tStartRefresh + 2.0-frameTolerance:
            # keep track of stop time/frame for later
            like_prac.tStop = t  # not accounting for scr refresh
            like_prac.frameNStop = frameN  # exact frame index
            win.timeOnFlip(like_prac, 'tStopRefresh')  # time at next scr refresh
            like_prac.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Practice_1cComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Practice_1c"-------
for thisComponent in Practice_1cComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('like_prac.started', like_prac.tStartRefresh)
thisExp.addData('like_prac.stopped', like_prac.tStopRefresh)

# ------Prepare to start Routine "Practice_1d"-------
continueRoutine = True
routineTimer.add(2.000000)
# update component parameters for each repeat
# keep track of which components have finished
Practice_1dComponents = [wait_2]
for thisComponent in Practice_1dComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Practice_1dClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Practice_1d"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = Practice_1dClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Practice_1dClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *wait_2* updates
    if wait_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        wait_2.frameNStart = frameN  # exact frame index
        wait_2.tStart = t  # local t and not account for scr refresh
        wait_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(wait_2, 'tStartRefresh')  # time at next scr refresh
        wait_2.setAutoDraw(True)
    if wait_2.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > wait_2.tStartRefresh + 2-frameTolerance:
            # keep track of stop time/frame for later
            wait_2.tStop = t  # not accounting for scr refresh
            wait_2.frameNStop = frameN  # exact frame index
            win.timeOnFlip(wait_2, 'tStopRefresh')  # time at next scr refresh
            wait_2.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Practice_1dComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Practice_1d"-------
for thisComponent in Practice_1dComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('wait_2.started', wait_2.tStartRefresh)
thisExp.addData('wait_2.stopped', wait_2.tStopRefresh)

# ------Prepare to start Routine "Practice_2a"-------
continueRoutine = True
# update component parameters for each repeat
prac_image_4.setImage('images/example-female.png')
# setup some python lists for storing info about the like_click
gotValidClick = False  # until a click is received
# setup some python lists for storing info about the Dislike_click
gotValidClick = False  # until a click is received
player2.setText('Player 1')
player2.bold = 'True'
vote_question.bold = 'True'
# keep track of which components have finished
Practice_2aComponents = [border_7, prac_image_4, like_button, like_text, like_click, dislike_button, dislike_text, Dislike_click, player2, vote_question]
for thisComponent in Practice_2aComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Practice_2aClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Practice_2a"-------
while continueRoutine:
    # get current time
    t = Practice_2aClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Practice_2aClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *border_7* updates
    if border_7.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        border_7.frameNStart = frameN  # exact frame index
        border_7.tStart = t  # local t and not account for scr refresh
        border_7.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(border_7, 'tStartRefresh')  # time at next scr refresh
        border_7.setAutoDraw(True)
    
    # *prac_image_4* updates
    if prac_image_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        prac_image_4.frameNStart = frameN  # exact frame index
        prac_image_4.tStart = t  # local t and not account for scr refresh
        prac_image_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(prac_image_4, 'tStartRefresh')  # time at next scr refresh
        prac_image_4.setAutoDraw(True)
    
    # *like_button* updates
    if like_button.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        like_button.frameNStart = frameN  # exact frame index
        like_button.tStart = t  # local t and not account for scr refresh
        like_button.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(like_button, 'tStartRefresh')  # time at next scr refresh
        like_button.setAutoDraw(True)
    
    # *like_text* updates
    if like_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        like_text.frameNStart = frameN  # exact frame index
        like_text.tStart = t  # local t and not account for scr refresh
        like_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(like_text, 'tStartRefresh')  # time at next scr refresh
        like_text.setAutoDraw(True)
    # *like_click* updates
    if like_click.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        like_click.frameNStart = frameN  # exact frame index
        like_click.tStart = t  # local t and not account for scr refresh
        like_click.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(like_click, 'tStartRefresh')  # time at next scr refresh
        like_click.status = STARTED
        like_click.mouseClock.reset()
        prevButtonState = like_click.getPressed()  # if button is down already this ISN'T a new click
    if like_click.status == STARTED:  # only update if started and not finished!
        buttons = like_click.getPressed()
        if buttons != prevButtonState:  # button state changed?
            prevButtonState = buttons
            if sum(buttons) > 0:  # state changed to a new click
                # abort routine on response
                continueRoutine = False
    
    # *dislike_button* updates
    if dislike_button.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        dislike_button.frameNStart = frameN  # exact frame index
        dislike_button.tStart = t  # local t and not account for scr refresh
        dislike_button.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(dislike_button, 'tStartRefresh')  # time at next scr refresh
        dislike_button.setAutoDraw(True)
    
    # *dislike_text* updates
    if dislike_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        dislike_text.frameNStart = frameN  # exact frame index
        dislike_text.tStart = t  # local t and not account for scr refresh
        dislike_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(dislike_text, 'tStartRefresh')  # time at next scr refresh
        dislike_text.setAutoDraw(True)
    # *Dislike_click* updates
    if Dislike_click.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        Dislike_click.frameNStart = frameN  # exact frame index
        Dislike_click.tStart = t  # local t and not account for scr refresh
        Dislike_click.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(Dislike_click, 'tStartRefresh')  # time at next scr refresh
        Dislike_click.status = STARTED
        Dislike_click.mouseClock.reset()
        prevButtonState = Dislike_click.getPressed()  # if button is down already this ISN'T a new click
    if Dislike_click.status == STARTED:  # only update if started and not finished!
        buttons = Dislike_click.getPressed()
        if buttons != prevButtonState:  # button state changed?
            prevButtonState = buttons
            if sum(buttons) > 0:  # state changed to a new click
                # abort routine on response
                continueRoutine = False
    
    # *player2* updates
    if player2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        player2.frameNStart = frameN  # exact frame index
        player2.tStart = t  # local t and not account for scr refresh
        player2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(player2, 'tStartRefresh')  # time at next scr refresh
        player2.setAutoDraw(True)
    
    # *vote_question* updates
    if vote_question.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        vote_question.frameNStart = frameN  # exact frame index
        vote_question.tStart = t  # local t and not account for scr refresh
        vote_question.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(vote_question, 'tStartRefresh')  # time at next scr refresh
        vote_question.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Practice_2aComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Practice_2a"-------
for thisComponent in Practice_2aComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('border_7.started', border_7.tStartRefresh)
thisExp.addData('border_7.stopped', border_7.tStopRefresh)
thisExp.addData('prac_image_4.started', prac_image_4.tStartRefresh)
thisExp.addData('prac_image_4.stopped', prac_image_4.tStopRefresh)
thisExp.addData('like_button.started', like_button.tStartRefresh)
thisExp.addData('like_button.stopped', like_button.tStopRefresh)
thisExp.addData('like_text.started', like_text.tStartRefresh)
thisExp.addData('like_text.stopped', like_text.tStopRefresh)
# store data for thisExp (ExperimentHandler)
x, y = like_click.getPos()
buttons = like_click.getPressed()
thisExp.addData('like_click.x', x)
thisExp.addData('like_click.y', y)
thisExp.addData('like_click.leftButton', buttons[0])
thisExp.addData('like_click.midButton', buttons[1])
thisExp.addData('like_click.rightButton', buttons[2])
thisExp.addData('like_click.started', like_click.tStart)
thisExp.addData('like_click.stopped', like_click.tStop)
thisExp.nextEntry()
thisExp.addData('dislike_button.started', dislike_button.tStartRefresh)
thisExp.addData('dislike_button.stopped', dislike_button.tStopRefresh)
thisExp.addData('dislike_text.started', dislike_text.tStartRefresh)
thisExp.addData('dislike_text.stopped', dislike_text.tStopRefresh)
# store data for thisExp (ExperimentHandler)
x, y = Dislike_click.getPos()
buttons = Dislike_click.getPressed()
thisExp.addData('Dislike_click.x', x)
thisExp.addData('Dislike_click.y', y)
thisExp.addData('Dislike_click.leftButton', buttons[0])
thisExp.addData('Dislike_click.midButton', buttons[1])
thisExp.addData('Dislike_click.rightButton', buttons[2])
thisExp.addData('Dislike_click.started', Dislike_click.tStart)
thisExp.addData('Dislike_click.stopped', Dislike_click.tStop)
thisExp.nextEntry()
thisExp.addData('player2.started', player2.tStartRefresh)
thisExp.addData('player2.stopped', player2.tStopRefresh)
thisExp.addData('vote_question.started', vote_question.tStartRefresh)
thisExp.addData('vote_question.stopped', vote_question.tStopRefresh)
# the Routine "Practice_2a" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Practice_2b"-------
continueRoutine = True
routineTimer.add(2.000000)
# update component parameters for each repeat
# keep track of which components have finished
Practice_2bComponents = [wait_3]
for thisComponent in Practice_2bComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Practice_2bClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Practice_2b"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = Practice_2bClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Practice_2bClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *wait_3* updates
    if wait_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        wait_3.frameNStart = frameN  # exact frame index
        wait_3.tStart = t  # local t and not account for scr refresh
        wait_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(wait_3, 'tStartRefresh')  # time at next scr refresh
        wait_3.setAutoDraw(True)
    if wait_3.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > wait_3.tStartRefresh + 2-frameTolerance:
            # keep track of stop time/frame for later
            wait_3.tStop = t  # not accounting for scr refresh
            wait_3.frameNStop = frameN  # exact frame index
            win.timeOnFlip(wait_3, 'tStopRefresh')  # time at next scr refresh
            wait_3.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Practice_2bComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Practice_2b"-------
for thisComponent in Practice_2bComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('wait_3.started', wait_3.tStartRefresh)
thisExp.addData('wait_3.stopped', wait_3.tStopRefresh)

# ------Prepare to start Routine "Practice_2c"-------
continueRoutine = True
routineTimer.add(2.000000)
# update component parameters for each repeat
# keep track of which components have finished
Practice_2cComponents = [dislike_prac]
for thisComponent in Practice_2cComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Practice_2cClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Practice_2c"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = Practice_2cClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Practice_2cClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *dislike_prac* updates
    if dislike_prac.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        dislike_prac.frameNStart = frameN  # exact frame index
        dislike_prac.tStart = t  # local t and not account for scr refresh
        dislike_prac.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(dislike_prac, 'tStartRefresh')  # time at next scr refresh
        dislike_prac.setAutoDraw(True)
    if dislike_prac.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > dislike_prac.tStartRefresh + 2.0-frameTolerance:
            # keep track of stop time/frame for later
            dislike_prac.tStop = t  # not accounting for scr refresh
            dislike_prac.frameNStop = frameN  # exact frame index
            win.timeOnFlip(dislike_prac, 'tStopRefresh')  # time at next scr refresh
            dislike_prac.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Practice_2cComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Practice_2c"-------
for thisComponent in Practice_2cComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('dislike_prac.started', dislike_prac.tStartRefresh)
thisExp.addData('dislike_prac.stopped', dislike_prac.tStopRefresh)

# ------Prepare to start Routine "Practice_2d"-------
continueRoutine = True
routineTimer.add(2.000000)
# update component parameters for each repeat
# keep track of which components have finished
Practice_2dComponents = [wait_4]
for thisComponent in Practice_2dComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Practice_2dClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Practice_2d"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = Practice_2dClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Practice_2dClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *wait_4* updates
    if wait_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        wait_4.frameNStart = frameN  # exact frame index
        wait_4.tStart = t  # local t and not account for scr refresh
        wait_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(wait_4, 'tStartRefresh')  # time at next scr refresh
        wait_4.setAutoDraw(True)
    if wait_4.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > wait_4.tStartRefresh + 2-frameTolerance:
            # keep track of stop time/frame for later
            wait_4.tStop = t  # not accounting for scr refresh
            wait_4.frameNStop = frameN  # exact frame index
            win.timeOnFlip(wait_4, 'tStopRefresh')  # time at next scr refresh
            wait_4.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Practice_2dComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Practice_2d"-------
for thisComponent in Practice_2dComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('wait_4.started', wait_4.tStartRefresh)
thisExp.addData('wait_4.stopped', wait_4.tStopRefresh)

# ------Prepare to start Routine "Introduction_7"-------
continueRoutine = True
# update component parameters for each repeat
text_9.setText('Now it’s time to vote for real.')
key_resp_9.keys = []
key_resp_9.rt = []
_key_resp_9_allKeys = []
next_intro7.bold = 'True'
# keep track of which components have finished
Introduction_7Components = [image_12, polygon_9, text_9, key_resp_9, next_intro7]
for thisComponent in Introduction_7Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Introduction_7Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Introduction_7"-------
while continueRoutine:
    # get current time
    t = Introduction_7Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Introduction_7Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_12* updates
    if image_12.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_12.frameNStart = frameN  # exact frame index
        image_12.tStart = t  # local t and not account for scr refresh
        image_12.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_12, 'tStartRefresh')  # time at next scr refresh
        image_12.setAutoDraw(True)
    
    # *polygon_9* updates
    if polygon_9.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        polygon_9.frameNStart = frameN  # exact frame index
        polygon_9.tStart = t  # local t and not account for scr refresh
        polygon_9.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(polygon_9, 'tStartRefresh')  # time at next scr refresh
        polygon_9.setAutoDraw(True)
    
    # *text_9* updates
    if text_9.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_9.frameNStart = frameN  # exact frame index
        text_9.tStart = t  # local t and not account for scr refresh
        text_9.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_9, 'tStartRefresh')  # time at next scr refresh
        text_9.setAutoDraw(True)
    
    # *key_resp_9* updates
    waitOnFlip = False
    if key_resp_9.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_9.frameNStart = frameN  # exact frame index
        key_resp_9.tStart = t  # local t and not account for scr refresh
        key_resp_9.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_9, 'tStartRefresh')  # time at next scr refresh
        key_resp_9.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_9.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_9.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_9.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_9.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_9_allKeys.extend(theseKeys)
        if len(_key_resp_9_allKeys):
            key_resp_9.keys = _key_resp_9_allKeys[-1].name  # just the last key pressed
            key_resp_9.rt = _key_resp_9_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *next_intro7* updates
    if next_intro7.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        next_intro7.frameNStart = frameN  # exact frame index
        next_intro7.tStart = t  # local t and not account for scr refresh
        next_intro7.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(next_intro7, 'tStartRefresh')  # time at next scr refresh
        next_intro7.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Introduction_7Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Introduction_7"-------
for thisComponent in Introduction_7Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image_12.started', image_12.tStartRefresh)
thisExp.addData('image_12.stopped', image_12.tStopRefresh)
thisExp.addData('polygon_9.started', polygon_9.tStartRefresh)
thisExp.addData('polygon_9.stopped', polygon_9.tStopRefresh)
thisExp.addData('text_9.started', text_9.tStartRefresh)
thisExp.addData('text_9.stopped', text_9.tStopRefresh)
# check responses
if key_resp_9.keys in ['', [], None]:  # No response was made
    key_resp_9.keys = None
thisExp.addData('key_resp_9.keys',key_resp_9.keys)
if key_resp_9.keys != None:  # we had a response
    thisExp.addData('key_resp_9.rt', key_resp_9.rt)
thisExp.addData('key_resp_9.started', key_resp_9.tStartRefresh)
thisExp.addData('key_resp_9.stopped', key_resp_9.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('next_intro7.started', next_intro7.tStartRefresh)
thisExp.addData('next_intro7.stopped', next_intro7.tStopRefresh)
# the Routine "Introduction_7" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
coplayers = data.TrialHandler(nReps=1.0, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Trials.xlsx'),
    seed=None, name='coplayers')
thisExp.addLoop(coplayers)  # add the loop to the experiment
thisCoplayer = coplayers.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisCoplayer.rgb)
if thisCoplayer != None:
    for paramName in thisCoplayer:
        exec('{} = thisCoplayer[paramName]'.format(paramName))

for thisCoplayer in coplayers:
    currentLoop = coplayers
    # abbreviate parameter names if possible (e.g. rgb = thisCoplayer.rgb)
    if thisCoplayer != None:
        for paramName in thisCoplayer:
            exec('{} = thisCoplayer[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "Player_profiles_voting_style"-------
    continueRoutine = True
    # update component parameters for each repeat
    cop_response.alignText = 'left'
    cop_age_st = (str(cop_age))
    
    # increment i for each loop
    i = i + 1
    cop_prompts.alignText = 'left'
    coplayer_image_2.setImage(photos[i])
    cop_prompts.reset()
    cop_response.setText(names[i] + '\n' + str(ages[i]) + '\n' + hometowns[i] + '\n' + interests[i])
    # setup some python lists for storing info about the like_click_3
    gotValidClick = False  # until a click is received
    vote_question_3.setText('Do you like or dislike ' + names[i] + '?')
    # setup some python lists for storing info about the dislike_click_3
    gotValidClick = False  # until a click is received
    # keep track of which components have finished
    Player_profiles_voting_styleComponents = [border_2, coplayer_image_2, cop_prompts, cop_response, like_button_3, like_text_3, like_click_3, dislike_button_3, dislike_text_3, vote_question_3, dislike_click_3]
    for thisComponent in Player_profiles_voting_styleComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Player_profiles_voting_styleClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Player_profiles_voting_style"-------
    while continueRoutine:
        # get current time
        t = Player_profiles_voting_styleClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Player_profiles_voting_styleClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *border_2* updates
        if border_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            border_2.frameNStart = frameN  # exact frame index
            border_2.tStart = t  # local t and not account for scr refresh
            border_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(border_2, 'tStartRefresh')  # time at next scr refresh
            border_2.setAutoDraw(True)
        
        # *coplayer_image_2* updates
        if coplayer_image_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            coplayer_image_2.frameNStart = frameN  # exact frame index
            coplayer_image_2.tStart = t  # local t and not account for scr refresh
            coplayer_image_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(coplayer_image_2, 'tStartRefresh')  # time at next scr refresh
            coplayer_image_2.setAutoDraw(True)
        
        # *cop_prompts* updates
        if cop_prompts.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            cop_prompts.frameNStart = frameN  # exact frame index
            cop_prompts.tStart = t  # local t and not account for scr refresh
            cop_prompts.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(cop_prompts, 'tStartRefresh')  # time at next scr refresh
            cop_prompts.setAutoDraw(True)
        
        # *cop_response* updates
        if cop_response.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            cop_response.frameNStart = frameN  # exact frame index
            cop_response.tStart = t  # local t and not account for scr refresh
            cop_response.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(cop_response, 'tStartRefresh')  # time at next scr refresh
            cop_response.setAutoDraw(True)
        
        # *like_button_3* updates
        if like_button_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            like_button_3.frameNStart = frameN  # exact frame index
            like_button_3.tStart = t  # local t and not account for scr refresh
            like_button_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(like_button_3, 'tStartRefresh')  # time at next scr refresh
            like_button_3.setAutoDraw(True)
        
        # *like_text_3* updates
        if like_text_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            like_text_3.frameNStart = frameN  # exact frame index
            like_text_3.tStart = t  # local t and not account for scr refresh
            like_text_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(like_text_3, 'tStartRefresh')  # time at next scr refresh
            like_text_3.setAutoDraw(True)
        # *like_click_3* updates
        if like_click_3.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            like_click_3.frameNStart = frameN  # exact frame index
            like_click_3.tStart = t  # local t and not account for scr refresh
            like_click_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(like_click_3, 'tStartRefresh')  # time at next scr refresh
            like_click_3.status = STARTED
            like_click_3.mouseClock.reset()
            prevButtonState = like_click_3.getPressed()  # if button is down already this ISN'T a new click
        if like_click_3.status == STARTED:  # only update if started and not finished!
            buttons = like_click_3.getPressed()
            if buttons != prevButtonState:  # button state changed?
                prevButtonState = buttons
                if sum(buttons) > 0:  # state changed to a new click
                    # abort routine on response
                    continueRoutine = False
        
        # *dislike_button_3* updates
        if dislike_button_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            dislike_button_3.frameNStart = frameN  # exact frame index
            dislike_button_3.tStart = t  # local t and not account for scr refresh
            dislike_button_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(dislike_button_3, 'tStartRefresh')  # time at next scr refresh
            dislike_button_3.setAutoDraw(True)
        
        # *dislike_text_3* updates
        if dislike_text_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            dislike_text_3.frameNStart = frameN  # exact frame index
            dislike_text_3.tStart = t  # local t and not account for scr refresh
            dislike_text_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(dislike_text_3, 'tStartRefresh')  # time at next scr refresh
            dislike_text_3.setAutoDraw(True)
        
        # *vote_question_3* updates
        if vote_question_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            vote_question_3.frameNStart = frameN  # exact frame index
            vote_question_3.tStart = t  # local t and not account for scr refresh
            vote_question_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(vote_question_3, 'tStartRefresh')  # time at next scr refresh
            vote_question_3.setAutoDraw(True)
        # *dislike_click_3* updates
        if dislike_click_3.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            dislike_click_3.frameNStart = frameN  # exact frame index
            dislike_click_3.tStart = t  # local t and not account for scr refresh
            dislike_click_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(dislike_click_3, 'tStartRefresh')  # time at next scr refresh
            dislike_click_3.status = STARTED
            dislike_click_3.mouseClock.reset()
            prevButtonState = dislike_click_3.getPressed()  # if button is down already this ISN'T a new click
        if dislike_click_3.status == STARTED:  # only update if started and not finished!
            buttons = dislike_click_3.getPressed()
            if buttons != prevButtonState:  # button state changed?
                prevButtonState = buttons
                if sum(buttons) > 0:  # state changed to a new click
                    # abort routine on response
                    continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Player_profiles_voting_styleComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Player_profiles_voting_style"-------
    for thisComponent in Player_profiles_voting_styleComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    coplayers.addData('border_2.started', border_2.tStartRefresh)
    coplayers.addData('border_2.stopped', border_2.tStopRefresh)
    coplayers.addData('coplayer_image_2.started', coplayer_image_2.tStartRefresh)
    coplayers.addData('coplayer_image_2.stopped', coplayer_image_2.tStopRefresh)
    coplayers.addData('cop_prompts.started', cop_prompts.tStartRefresh)
    coplayers.addData('cop_prompts.stopped', cop_prompts.tStopRefresh)
    coplayers.addData('cop_response.started', cop_response.tStartRefresh)
    coplayers.addData('cop_response.stopped', cop_response.tStopRefresh)
    coplayers.addData('like_button_3.started', like_button_3.tStartRefresh)
    coplayers.addData('like_button_3.stopped', like_button_3.tStopRefresh)
    coplayers.addData('like_text_3.started', like_text_3.tStartRefresh)
    coplayers.addData('like_text_3.stopped', like_text_3.tStopRefresh)
    # store data for coplayers (TrialHandler)
    x, y = like_click_3.getPos()
    buttons = like_click_3.getPressed()
    coplayers.addData('like_click_3.x', x)
    coplayers.addData('like_click_3.y', y)
    coplayers.addData('like_click_3.leftButton', buttons[0])
    coplayers.addData('like_click_3.midButton', buttons[1])
    coplayers.addData('like_click_3.rightButton', buttons[2])
    coplayers.addData('like_click_3.started', like_click_3.tStart)
    coplayers.addData('like_click_3.stopped', like_click_3.tStop)
    coplayers.addData('dislike_button_3.started', dislike_button_3.tStartRefresh)
    coplayers.addData('dislike_button_3.stopped', dislike_button_3.tStopRefresh)
    coplayers.addData('dislike_text_3.started', dislike_text_3.tStartRefresh)
    coplayers.addData('dislike_text_3.stopped', dislike_text_3.tStopRefresh)
    coplayers.addData('vote_question_3.started', vote_question_3.tStartRefresh)
    coplayers.addData('vote_question_3.stopped', vote_question_3.tStopRefresh)
    # store data for coplayers (TrialHandler)
    x, y = dislike_click_3.getPos()
    buttons = dislike_click_3.getPressed()
    coplayers.addData('dislike_click_3.x', x)
    coplayers.addData('dislike_click_3.y', y)
    coplayers.addData('dislike_click_3.leftButton', buttons[0])
    coplayers.addData('dislike_click_3.midButton', buttons[1])
    coplayers.addData('dislike_click_3.rightButton', buttons[2])
    coplayers.addData('dislike_click_3.started', dislike_click_3.tStart)
    coplayers.addData('dislike_click_3.stopped', dislike_click_3.tStop)
    # the Routine "Player_profiles_voting_style" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "Waiting_vote"-------
    continueRoutine = True
    routineTimer.add(2.000000)
    # update component parameters for each repeat
    wait_5.setText('+')
    # keep track of which components have finished
    Waiting_voteComponents = [wait_5]
    for thisComponent in Waiting_voteComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Waiting_voteClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Waiting_vote"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = Waiting_voteClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Waiting_voteClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *wait_5* updates
        if wait_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            wait_5.frameNStart = frameN  # exact frame index
            wait_5.tStart = t  # local t and not account for scr refresh
            wait_5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(wait_5, 'tStartRefresh')  # time at next scr refresh
            wait_5.setAutoDraw(True)
        if wait_5.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > wait_5.tStartRefresh + 2-frameTolerance:
                # keep track of stop time/frame for later
                wait_5.tStop = t  # not accounting for scr refresh
                wait_5.frameNStop = frameN  # exact frame index
                win.timeOnFlip(wait_5, 'tStopRefresh')  # time at next scr refresh
                wait_5.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Waiting_voteComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Waiting_vote"-------
    for thisComponent in Waiting_voteComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    coplayers.addData('wait_5.started', wait_5.tStartRefresh)
    coplayers.addData('wait_5.stopped', wait_5.tStopRefresh)
    
    # ------Prepare to start Routine "Cop_vote"-------
    continueRoutine = True
    routineTimer.add(2.000000)
    # update component parameters for each repeat
    vote_image.setImage(image_thumb)
    # keep track of which components have finished
    Cop_voteComponents = [vote_image]
    for thisComponent in Cop_voteComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Cop_voteClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Cop_vote"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = Cop_voteClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Cop_voteClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *vote_image* updates
        if vote_image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            vote_image.frameNStart = frameN  # exact frame index
            vote_image.tStart = t  # local t and not account for scr refresh
            vote_image.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(vote_image, 'tStartRefresh')  # time at next scr refresh
            vote_image.setAutoDraw(True)
        if vote_image.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > vote_image.tStartRefresh + 2.0-frameTolerance:
                # keep track of stop time/frame for later
                vote_image.tStop = t  # not accounting for scr refresh
                vote_image.frameNStop = frameN  # exact frame index
                win.timeOnFlip(vote_image, 'tStopRefresh')  # time at next scr refresh
                vote_image.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Cop_voteComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Cop_vote"-------
    for thisComponent in Cop_voteComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    coplayers.addData('vote_image.started', vote_image.tStartRefresh)
    coplayers.addData('vote_image.stopped', vote_image.tStopRefresh)
    
    # ------Prepare to start Routine "Waiting_vote"-------
    continueRoutine = True
    routineTimer.add(2.000000)
    # update component parameters for each repeat
    wait_5.setText('+')
    # keep track of which components have finished
    Waiting_voteComponents = [wait_5]
    for thisComponent in Waiting_voteComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Waiting_voteClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Waiting_vote"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = Waiting_voteClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Waiting_voteClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *wait_5* updates
        if wait_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            wait_5.frameNStart = frameN  # exact frame index
            wait_5.tStart = t  # local t and not account for scr refresh
            wait_5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(wait_5, 'tStartRefresh')  # time at next scr refresh
            wait_5.setAutoDraw(True)
        if wait_5.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > wait_5.tStartRefresh + 2-frameTolerance:
                # keep track of stop time/frame for later
                wait_5.tStop = t  # not accounting for scr refresh
                wait_5.frameNStop = frameN  # exact frame index
                win.timeOnFlip(wait_5, 'tStopRefresh')  # time at next scr refresh
                wait_5.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Waiting_voteComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Waiting_vote"-------
    for thisComponent in Waiting_voteComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    coplayers.addData('wait_5.started', wait_5.tStartRefresh)
    coplayers.addData('wait_5.stopped', wait_5.tStopRefresh)
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'coplayers'

del ptp_name
del ptp_age
del ptp_hometown
del ptp_interest
del response
del name_enter.text
del age_enter.text
del hometown_enter.text
del interest_enter.text
del ptp_name
del ptp_age
del ptp_hometown
del ptp_interest
del response
del name_enter.text
del age_enter.text
del hometown_enter.text
del interest_enter.text

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
